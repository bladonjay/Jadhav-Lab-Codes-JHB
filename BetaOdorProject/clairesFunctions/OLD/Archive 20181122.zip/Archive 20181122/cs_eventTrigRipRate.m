function [countAll, ripRate, ripTimes] = cs_eventTrigRipRate(prefix, days, epochs, stim, timewin)

%load stim times file, for each stim time, get time win of certain length.
%load ripple file, find all ripples within that time window. count number
%of ripples, calculate ripple per second rate, and give times of each
%ripple. 

dir = ['E:\Data\OdorPlaceAssociation\', prefix, '_direct\'];
cd(dir)

tetinfofile = load([prefix,'tetinfo.mat']);
    tetinfo = tetinfofile.tetinfo;

countAll = []; ripTimes = [];
for d = 1:length(days)
    day = days(d);
    if (day<10)
        daystring = ['0',num2str(day)];
    else
        daystring = num2str(day);
    end
    
    ripfile = load([prefix,'ripples', daystring, '.mat']);
        rippleslist = ripfile.ripples;
        
    for ep=1:length(epochs)
        
        epoch = epochs(ep);
        if (epoch<10)
            epstring = ['0',num2str(epoch)];
        else
            epstring = num2str(epoch);
        end
        
        

        [ripples] = sj_getripples_tetinfo([day epoch], rippleslist, tetinfo, 'tetfilter', 'isequal($descrip, ''riptet'')', 'minrip', 2 );
        
        switch stim
            case 'odor'
                trigfile = load(['OdorTriggers', daystring, '-', epstring, '.mat']);
                triggers = trigfile.OdorTriggers_all;
            case 'reward'
                rewardfile = load(['RewardTimes', daystring, '-', epstring, '.mat']);
                triggers = rewardfile.RewardTimes;
        end
        
        for tr = 1:length(triggers)
            trig = triggers(tr);
            
            trigWinStart = (trig - timewin(1));
            trigWinEnd = (trig + timewin(2));
            trigRipsInds = find((ripples(:,1) > trigWinStart) & (ripples(:,1) < trigWinEnd));
            
            ripTime = ripples(trigRipsInds);
            countTrigRips = length(trigRipsInds);
            
                for r = 1:countTrigRips,
                    
                ripTimes(end+1,1) = ripTime(r);
                end
            countAll(end+1,1) = countTrigRips;
        end
    end 
end
avgRipCount = mean(countAll);
timeWinLength = timewin(2)-timewin(1);

ripRate = (avgRipCount/timeWinLength);
                