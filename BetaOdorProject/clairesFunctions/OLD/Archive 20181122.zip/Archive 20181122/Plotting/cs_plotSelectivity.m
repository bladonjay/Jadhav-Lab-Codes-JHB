function cs_plotSelectivity(regions, win, figDir)
%Run from dir where data is stored
% cs_plotSelectivity({'CA1','PFC'}, 'E:\Figures\')

allregions = zeros(length(regions), 3);
for r = 1:length(regions)
    load(['selectivityFractions_',regions{r},'_',num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms.mat'])
    all = selectivityFractions;
    
    %nonspiking = 1-all.fractSpiking;
    %spiking = all.fractSpiking;
    %selective = all.fractSelective*all.fractSpiking;
    %nonselective = all.fractSpiking - selective;
    selective = all.fractSelective;
    left = all.fractLeft*all.fractSelective;
    right = all.fractRight*all.fractSelective;
    
    total = [selective, left, right];
    allregions(r,:) = total;

end


figure, hold on

b = bar([1,2],allregions);
xticks([1,2])
set(gca,'xticklabel',{'CA1','PFC'})
 ylim([0 .5]), xlim([.5 2.5])
 ylabel('Fraction of Cells')
 xticks([1 2])

%c=[0.8242 0.8242 0.8242; 0.4102 0.4102 0.4102 ; 0    0.9792    0.6016; 0    0.7461    1.0000];
c = [rgb('slateGrey') ;rgb('RoyalBlue'); rgb('LightCoral')];
b(1).FaceColor = rgb('slateGrey');
b(2).FaceColor = rgb('RoyalBlue');
b(3).FaceColor = rgb('LightCoral');
%colormap(c)
set(gcf, 'Position', [50 50 800 800]);
set(gca,'fontsize',36);

l= legend('Total Selective','Odor 1 Selective','Odor 2 Selective');
l.FontSize = 25;
legend('boxoff')

figtitle = 'FractionSelectiveCells';
% title(figtitle);

figfile = [figDir,'NicePPTFigures\',figtitle];
    
   % saveas(gcf,figfile,'fig');
    print('-dpdf', figfile);
    print('-djpeg', figfile);
    %print('-dpdf', figfile);
    