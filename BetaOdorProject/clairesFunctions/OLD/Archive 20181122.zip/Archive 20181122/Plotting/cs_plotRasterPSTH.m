function cs_plotRasterPSTH(dataDir, region, win, plotPF)

load([dataDir,'cellSelectivityData_',region,'_',num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms.mat']);

if plotPF == 1
    load([dataDir, 'placeFieldData.mat']);
end

stdev = 2;
g = gaussian(stdev,(3*stdev));

savedCells = [];
for c = 1:length(cellSelectivity)
    cellindex = cellSelectivity(c).cellindex;
    animal = cellSelectivity(c).animal;
    z = cellSelectivity(c).zscore;
    bins = cellSelectivity(c).bins;
    binsize = bins(2)-bins(1);
    
    leftSpikes = cellSelectivity(c).psthleftTriggers; %only take spikes after odor trigger
    leftSpikeTimes = cellSelectivity(c).leftSpikeTimes;
    left = leftSpikes./binsize;
    leftFRavg = mean(left,1);
    leftFR = filter2(g,leftFRavg); 
    %leftFR = smoothdata(leftFRavg, 'gaussian', 5);
    
    rightSpikes = cellSelectivity(c).psthrightTriggers;
    rightSpikeTimes = cellSelectivity(c).rightSpikeTimes;
    right = rightSpikes./binsize;
    rightFRavg = mean(right,1);
    rightFR = filter2(g,rightFRavg);
    %rightFR = smoothdata(rightFRavg, 'gaussian', 5);
    
    figure, set(gcf,'Position',[2000, 500, 600, 400]);
    suptitle(['Cell ',animal,' ', num2str(cellindex), ' Z = ', num2str(z)])
    subplot(3, 1, 1), hold on
    for r = 1:size(leftSpikeTimes,1)
        plot(leftSpikeTimes(r,:), r, 'g.')
    end

    plot([0 0], [0 (length(leftSpikeTimes))], 'k--');
    axis( [-win(1) win(2) 0 length(leftSpikeTimes)])

    subplot(3, 1, 2), hold on
    for r = 1:size(rightSpikeTimes,1)
        plot(rightSpikeTimes(r,:), r ,'m.')
    end
    plot([0 0], [0 (length(rightSpikeTimes))], 'k--');
    axis( [-win(1) win(2) 0 length(rightSpikeTimes)])

    subplot(3, 1, 3)
    hold on
    plot(bins, leftFR, 'g');
    plot(bins, rightFR, 'm');

    plot([0 0], [0 5], 'k--');
    
    
    if plotPF == 1
        eval(['placeFields = placeFields_',region,';'])
        pfinds = vertcat(placeFields.index);
        pf = ismember(pfinds,cellindex, 'rows');
        placefield = placeFields(pf).smoothedspikerate;
        figure,set(gcf,'Position',[2600, 500, 600, 400]);
        imagesc(placefield); colormap(jet);
    end
    
    keepcell = input('Save cell index?');
    
    
    
    if keepcell == 1
        savedCells(end+1) = c;
    end
    
    close all
end

save([dataDir,'savedCells_',region,'.mat'],'savedCells')