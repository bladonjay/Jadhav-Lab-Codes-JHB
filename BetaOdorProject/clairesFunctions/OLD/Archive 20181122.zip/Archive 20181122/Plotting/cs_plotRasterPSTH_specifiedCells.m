function cs_plotRasterPSTH_specifiedCells(dataDir, figDir, region, win, plotPF, savefig)

%cs_plotRasterPSTH_specifiedCells('F:\Data\OdorPlaceAssociation\AnalysesAcrossAnimals\', 'F:\Figures\', 'CA1', [.5 1], 1, 1);


%load([dataDir, 'savedCells_',region,'.mat']);
savedCells = 55;
load([dataDir, 'cellSelectivityData_',region,'_',num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms.mat']);
load([dataDir, 'placeFieldData.mat']);
eval(['placeFields = placeFields_',region,';']);

cellstoplot = cellSelectivity(savedCells);
stdev = 2;
g = gaussian(stdev,(3*stdev));
leftcolor = rgb('RoyalBlue');
rightcolor = rgb('LightCoral');

for cell = 1:length(cellstoplot)
    c = savedCells(cell);
    cellindex = cellSelectivity(c).cellindex;
    animal = cellSelectivity(c).animal;
    z = cellSelectivity(c).zscore;
    bins = cellSelectivity(c).bins;
    binsize = bins(2)-bins(1);
    
    leftSpikes = cellSelectivity(c).psthleftTriggers; %only take spikes after odor trigger
    leftSpikeTimes = cellSelectivity(c).leftSpikeTimes;
    left = leftSpikes./binsize;
    leftFRavg = mean(left,1);
    leftFR = filter2(g,leftFRavg); 
    %leftFR = smoothdata(leftFRavg, 'gaussian', 5);
    
    rightSpikes = cellSelectivity(c).psthrightTriggers;
    rightSpikeTimes = cellSelectivity(c).rightSpikeTimes;
    right = rightSpikes./binsize;
    rightFRavg = mean(right,1);
    rightFR = filter2(g,rightFRavg);
    %rightFR = smoothdata(rightFRavg, 'gaussian', 5);
    
        figure, set(gcf,'Position',[50, 50, 800, 250]);
        %suptitle(['Cell ',animal,' ', num2str(cellindex), ' Z = ', num2str(z)])
        
%         subplot(3, 1, 1), hold on
%         for r = 1:size(leftSpikeTimes,1)
%             plot(leftSpikeTimes(r,:), r, '.', 'MarkerEdgeColor', leftcolor,'MarkerSize',15)
%         end
%         ylabel('Odor 1')
%         plot([0 0], [0 (length(leftSpikeTimes))], 'k--','LineWidth',2);
%         axis( [-win(1) win(2) 0 length(leftSpikeTimes)])
%         set(gca,'fontsize',25);
%     
%         
%         
%         subplot(3, 1, 2), hold on
%         for r = 1:size(rightSpikeTimes,1)
%             plot(rightSpikeTimes(r,:), r ,'.', 'MarkerEdgeColor', rightcolor,'MarkerSize',15)
%         end
%         plot([0 0], [0 (length(rightSpikeTimes))], 'k--','LineWidth',2);
%         axis( [-win(1) win(2) 0 length(rightSpikeTimes)])
%         ylabel('Odor 2')   
%         set(gca,'fontsize',25);
%     
%  
%         subplot(3, 1, 3)
        hold on
        plot(bins, leftFR,  'LineWidth',3.5, 'Color', leftcolor);
        plot(bins, rightFR, 'LineWidth',3.5, 'Color', rightcolor);

        maxfr = max([leftFR,rightFR]);

        plot([0 0], [0 maxfr+1], 'k--','LineWidth',2);
        ylabel('Firing Rate (Hz)')
        xlabel('Time from Odor Onset (seconds)')
        set(gca,'fontsize',25);
        axis([-win(1) win(2) 0 maxfr+1])
        %legend('Odor 1 Response','Odor 2 Response')
    
    
    
        if savefig == 1
            figtitle = ['PSTH_',region,'_',animal,'_',num2str(cellindex(1)),'_',num2str(cellindex(2)),'_',num2str(cellindex(3))];
            figfile = [figDir,'OdorSelectivity\',figtitle];
            saveas(gcf,figfile,'fig');
            print('-dpdf', figfile);
            print('-djpeg', figfile);
        end
        
    
    
    if plotPF == 1
        eval(['placeFields = placeFields_',region,';'])
        pfinds = vertcat(placeFields.index);
        pf = ismember(pfinds,cellindex, 'rows');
        placefield = placeFields(pf).smoothedspikerate;
        figure,
        set(gcf,'Position',[2000, 400, 800, 600]);
        
        imagesc(placefield); colormap(jet);
        axis off
        colorbar
        %clabel('Firing rate (Hz)')
        h = colorbar;
        ylabel(h, 'Firing rate (Hz)')
        %set(gcf, 'Position', [2000 400 900 600]);
        set(gca,'fontsize',20);
        
        if savefig ==1
            figtitle = ['PSTH_',region,'_',animal,'_',num2str(cellindex(1)),'_',num2str(cellindex(2)),'_',num2str(cellindex(3)),'_pf'];
            figfile = [figDir,'OdorSelectivity\',figtitle];
            saveas(gcf,figfile,'fig');
            print('-dpdf', figfile);
            print('-djpeg', figfile);
        end
        
        
    end
    
    %pause;
    close all
end