function cs_plotPhaseLocking_individualCells(region,nbins)

[topDir, figDir] = cs_setPaths();
animals = {'CS31','CS33','CS34','CS35'};
bins = -pi:(2*pi/nbins):pi;

 switch region
        case 'CA1'
            color = rgb('MediumIndigo');
        case 'PFC'            
            color = rgb('DarkAquamarine');
 end

for a = 1:length(animals)
    animal = animals{a};
    animDir = [topDir, animal,'Expt\',animal,'_direct\'];
    
    files = dir([animDir,animal,'betaphaselock_',region,'*']);
    
    for d = 1:length(files)
            load(files(d).name)
            day = length(
            eval(['beta_phaselock = beta_phaselock',region,';']);

           
            cellfilter = '(~isempty($sph) & ($prayl < 0.05) &($Nspikes > 10))'; %only PL cells
            cells = evaluatefilter(beta_phaselock,cellfilter);
     
            for c = 1:size(cells,1)
                ind = cells(c,:);
 
                sph = beta_phaselock{ind(1)}{ind(2)}{ind(3)}{ind(4)}.sph;
                alpha = beta_phaselock{ind(1)}{ind(2)}{ind(3)}{ind(4)}.alpha;
                betahat = beta_phaselock{ind(1)}{ind(2)}{ind(3)}{ind(4)}.betahat;
                kappa = beta_phaselock{ind(1)}{ind(2)}{ind(3)}{ind(4)}.kappa;
                
                count = histc(spikephase, bins);
                pct = (count./sum(count))*100;
                newcount = [pct,pct];
                
                newbins = [bins - pi, bins(2:end) + pi];


                %% Plot
                figure, hold on
                out = bar(newbins, newcount,1);
                set(out, 'EdgeColor',color);
                set(out, 'FaceColor',color);
                plot([0 0], [0 max(newcount+2)], 'k--');
                axis([-2*pi, 2*pi, 1 max(newcount+2)])
                xticks([-2*pi -pi 0 pi 2*pi])
                xticklabels({'-2\pi','-\pi','0','\pi','2\pi'})
                xlabel('Beta Phase')
                ylabel(' of spikes')
    
    
    
%% Stats 
    
         
                 [pdf] = circ_vmpdf(alpha,betahat,kappa);
                 binnum = lookup(betahat,alpha);
                 pdf = pdf.*(pct(binnum)/pdf(binnum));
                 newpdf = [pdf; pdf]; 
                 newalpha = [alpha - pi; alpha + pi]; 
                 %newalpha = [alpha;alpha];
                 plot(newalpha,newpdf+1,'k','LineWidth',3,'Color','k');
        
    
                title([animal, ' ', num2str
    %% Save Figure
                figtitle = [region,'toCA1beta_population'];
                newfigfile = [figDir,'PhaseLocking\',figtitle];
                saveas(gcf,newfigfile,'fig');
                print('-dpdf', newfigfile);
                print('-djpeg', newfigfile);
    
    
    
    
    
                out = bar(newbins, newcount,'hist'); 
                h = findobj(gca,'Type','line');
                    set(h,'Marker','none');
                hold on
                
                xticks([-2*pi -pi 0 pi 2*pi ])
                xticklabels({'-2\pi','-\pi','0','\pi','2\pi'})
                
                [pdf] = circ_vmpdf(alpha,betahat,kappa);
                binnum = lookup(betahat,alpha);
                pdf = pdf.*(pct(binnum)/pdf(binnum));
                newpdf = [pdf; pdf]; 
                newalpha = [alpha - pi; alpha + pi]; 
                 %newalpha = [alpha;alpha];
                plot(newalpha,newpdf+1,'k','LineWidth',3,'Color','k');
            end
    end
end
    
    
    
    
    load([animDir, 'betaModv2_',betaregion,'.mat'])

switch cellregion
    case 'CA1'
        dataAllCells = betaMod_CA1cells;
    case 'PFC'
        dataAllCells = betaMod_PFCcells;
end


pvals = [dataAllCells.prayl];
sigPL = (pvals <=0.05)';
%area = betaMod.betaregion;
sigCells = dataAllCells(sigPL);
sigCellsIndx = vertcat(sigCells.index);
nbins = length(sigCells(1).alpha)-1;
bins = -pi:(2*pi/nbins):pi;

goodCellsIndex = find(ismember(sigCellsIndx,cellstolookat,'rows'));

goodCells = sigCells(goodCellsIndex);

for c = 1:length(goodCells)
    spikephase = goodCells(c).spikephase;
    cellindex = goodCells(c).index;
    animal = goodCells(c).animal;
    
    count = histc(spikephase, bins);
    figure; %redimscreen_2horsubplots
    %set(gcf, 'Position', [200 300 900 600]);
    set(gcf, 'Position', [50 50 1200 900]); %for dual monitors
    %subplot(2,1,1);
    %hold on;
    newcount = [count;count(2:end)];
    newbins = [bins - pi, bins(2:end) + pi];
    
    
    out = bar(newbins, newcount,'hist'); 
    h = findobj(gca,'Type','line');
        set(h,'Marker','none');
    hold on
    %bar(bins + 2(pi), count, 'hist');
    xticks([-2*pi -pi 0 pi 2*pi ])
    xticklabels({'-2\pi','-\pi','0','\pi','2\pi'})
   
    binnum = lookup(goodCells(c).betahat,goodCells(c).alpha);
    pdf = goodCells(c).vmpdf;
    if count(binnum) == 0
        pdf = pdf.*(1/pdf(binnum));
    else
        pdf = pdf.*(count(binnum)/pdf(binnum));
    end
    newpdf = [pdf;pdf(2:end)];
    alpha = [goodCells(c).alpha-pi; goodCells(c).alpha(2:end)+pi];
    
    plot(alpha,newpdf,'k','LineWidth',3,'Color','k');
    
    set(gca,'XLim',[-2*pi-0.5 2*pi]); set(gca,'YLim',[0 max(count)+0.5]); ylabel('Number of Spikes'); xlabel('Phase of Beta Oscillation'); set(out,'FaceColor',plotcolor);
    titlestring = [animal, ' ', num2str(cellindex)];
    %title(titlestring);
    
    set(gca,'fontsize',36);
    box off
    
    % Shantanu - add a plot with %tage of spikes
    % -------------------------------------------
%     subplot(2,2,2);
%     hold on;
%     totalspks = sum(count);
%     countper = (count./totalspks)*100;
%     out = bar(bins, countper, 'hist');  set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
%     set(gca,'XLim',[-pi-0.5 pi]); ylabel('% of Spikes'); set(out,'FaceColor','r');
    
    
%     [t,r] = rose(spikephase);
%     subplot(2,1,2);
%     figure,
%     p=polarplot(t,r); hold on;
%     p.Color = plotcolor;
% %     The peak phase angle
%     lims = get(gca,'XLim');
%     radius = lims(2);
%     
%     ph = degtorad(goodCells(c).phdeg);
%     xx = radius .* cos(ph); yy = radius .* sin(ph);
%     line([0 xx], [0 yy],'LineWidth',4,'Color','k'); %plot(xx,yy,'ko','MarkerSize',4);
%     
%     pause
    
    filename = ['betaMod_', betaregion,'-',cellregion,'cells_', num2str(cellindex(1)), '_',num2str(cellindex(2)),'_',num2str(cellindex(3))];
    %figdir = 'E:\Figures\PhaseLocking\';
    %figdir = 'E:\Figures\NicePPTFigures\';
    
    figfile = [figDir,filename];
    
    print('-djpeg', figfile);
    print('-bestfit','-dpdf', figfile);
    saveas(gcf,figfile,'fig');
    
    
    
end
    
    
    