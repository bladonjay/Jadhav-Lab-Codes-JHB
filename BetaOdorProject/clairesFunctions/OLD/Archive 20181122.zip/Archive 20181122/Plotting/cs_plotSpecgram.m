function cs_plotSpecgram(eventTrigSpecgram_file, varargin)

%cd('E:\AnalysesAcrossAnimals\'); %home computer
%cd('D:\OdorPlaceAssociation\AnalysesAcrossAnimals\'); %lab computer

load(eventTrigSpecgram_file);

%----- Params ----- %
region = eventTrigSpecgramData.region;
trigtypes = eventTrigSpecgramData.trigtypes;
freqband = eventTrigSpecgramData.freqband;
    switch freqband
        case 'low'
            freqs = [1:40];
        case 'mid'
            freqs = [1:100];
        case 'floor'
            freqs = [1:10];
    end
    

win = eventTrigSpecgramData.win;
tapers = eventTrigSpecgramData.tapers;
movingwin = eventTrigSpecgramData.movingwin;
reforgnd = eventTrigSpecgramData.ReforGnd;



timewin = (win(1) - (-win(2)));

paramstring = eventTrigSpecgram_file(23:(strfind(eventTrigSpecgram_file, '.mat')-1));
trigstring = '';

for option = 1:2:length(varargin)-1
    switch varargin{option}
        case 'Triggers'
            Triggers = varargin{option+1};
            if strcmp(Triggers,'odorTriggers')
                 trigstring = '';
             else
                 trigstring = [Triggers,'_'];
            end
    end
end


%----- Calculate Averages -----%

std=2;
for g = 1:length(trigtypes) %for each trigtype
    
    
    trigtype = trigtypes{g};
    
    specdata = eventTrigSpecgramData.(trigtype)';
    times = [-win(1), timewin/length(specdata), win(2)];
    
    s = gaussian2(std,(2*std));
    smoothedspecdata = filter2(s,specdata); 
    %smoothedspecdata = specdata;
    
    figure, hold on
    colormap(jet);
    imagesc(times, freqs,smoothedspecdata)
    set(gca,'YDir','normal')
    plot([0 0],[1 freqs(end)],'k--', 'LineWidth', 1.5);
    axis([-win(1) win(2) 1 freqs(end)])
    colorbar
    
%     figure, colormap(jet);
%     imagesc(times, freqs, specdata)
%     set(gca,'YDir','normal')
%     colorbar
%     hold on
%     plot([0 0],[1 40],'k--', 'LineWidth', 1.5);
%     axis([-win(1) win(2) 1 40])

    figtitle1 = ['Spectrogram_',paramstring];
    title(sprintf('%s%d',figtitle1), 'Interpreter', 'none'); %allows underscores in fig titles
    
    [~,figdir] = cs_setPaths();
    
    figfile = [figdir,figtitle1];
    
    print('-djpeg', figfile);
    print('-dpdf', figfile);
    saveas(gcf,figfile,'fig');
    
    clear specdata
end