
%Plot nice PSTH and rasters for specified odor selective cells.
%enter cells to plot as a matrix. 
%____________________________________
%| animalnum | day | tetrode | cell |
%| animalnum | day | tetrode | cell |
%
% stored in "selectiveCells_(region)" files in AnalysesAcrossAnimals

%% Params
topDir = 'D:\OdorPlaceAssociation\';
figDir = 'D:\Figures\OdorSelectivity\';
region = 'PFC';

savefig = 1;

load([topDir,'AnalysesAcrossAnimals\selectiveCells_',region,'.mat']);
cellstoplot = selectivecells;

win = [0.5 1];
binsize = 0.02;
bins = (-win(1):binsize:win(2)+binsize);
animals = {'CS31','CS33','CS34','CS35'};
stdev = 4;
g = gaussian(stdev,(3*stdev));
leftcolor = rgb('BrightRoyalBlue');
rightcolor = rgb('Crimson');

%%

for c = 1:size(cellstoplot,1)
    cindex = cellstoplot(c,:);
    animal = animals{cindex(1)};
    animDir = [topDir,animal,'Expt\',animal,'_direct\'];
    
    day = cindex(2);
    daystr = getTwoDigitNumber(day);
    
     load([animDir,animal,'spikes',daystr,'.mat'])
     load([animDir,animal,'odorTriggers',daystr,'.mat'])
     load([animDir,animal,'cellinfo.mat'])
     
     region = cellinfo{day}{2}{cindex(3)}{cindex(4)}.area;
     runeps = find(~cellfun(@isempty,odorTriggers{day}));
         
         
     alltrigs = []; lefttrigs = []; righttrigs = [];
     for ep = 1:length(runeps)
              epoch = runeps(ep);
              alltrigs = [alltrigs; odorTriggers{day}{epoch}.allTriggers];
              [correct_left, correct_right, ~, ~] = cs_getSpecificTrialTypeInds(odorTriggers{day}{epoch});
              lefttrigs = [lefttrigs; alltrigs(correct_left)];
              righttrigs = [righttrigs; alltrigs(correct_right)];
     end
     
    
     allspikes = [];
      for ep = 1:length(runeps)
          epoch = runeps(ep);

          if ~isempty(spikes{cindex(2)}{epoch}{cindex(3)}{cindex(4)})
                allspikes = [allspikes; spikes{cindex(2)}{epoch}{cindex(3)}{cindex(4)}.data(:,1)];
          end


      end
      
       leftspikes = []; 
       rightspikes = [];

       for t = 1:length(lefttrigs)
            trig = lefttrigs(t);
                trigwin = [trig-win(1), trig+win(2)];
                winspikes = allspikes(allspikes > trigwin(1) & allspikes <= trigwin(2));
                winspikes = winspikes- trig;

                leftspikes{t} = winspikes';     
       end
       
       tmp = cell2mat(leftspikes);
       leftspikecount = histcounts(tmp,bins);
       avgspikecount = leftspikecount./length(lefttrigs);
       lfr = avgspikecount./binsize; %convert to hz
       leftPSTH = filter2(g,lfr); 

       for t = 1:length(righttrigs)
            trig = righttrigs(t);
                trigwin = [trig-win(1), trig+win(2)];
                winspikes = allspikes(allspikes > trigwin(1) & allspikes <= trigwin(2));
                winspikes = winspikes- trig;
                

                rightspikes{t} = winspikes';     
       end
        
        tmp = cell2mat(rightspikes);
        rightspikecount = histcounts(tmp, bins);
        avgspikecount = rightspikecount./length(righttrigs);
        rfr = avgspikecount./binsize; %convert to hz
        rightPSTH = filter2(g,rfr); 
        
    
        figure, set(gcf,'Position',[800 40 700 600]);
        
        
        %% Plot
        hold on
        plot(bins(1:end-1), leftPSTH,  'LineWidth',3.5, 'Color', leftcolor);
        plot(bins(1:end-1), rightPSTH, 'LineWidth',3.5, 'Color', rightcolor);

        maxfr = max([leftPSTH,rightPSTH]);

        plot([0 0], [0 maxfr+1], 'k--','LineWidth',2);
        ylabel('Firing Rate (Hz)')
        xlabel('Time from Odor Onset (seconds)')
        set(gca,'fontsize',25);
        axis([-win(1) win(2) 0 maxfr+1])
       
    
    
    
        if savefig == 1
            figtitle = ['PSTH_',region,'_',animal,'_',num2str(cindex(2)),'_',num2str(cindex(3)),'_',num2str(cindex(4))];
            figfile = [figDir,figtitle];
            
            print('-dpdf', figfile);
            print('-djpeg', figfile);
            
            saveas(gcf,figfile,'fig');
        end

        close all
  
end