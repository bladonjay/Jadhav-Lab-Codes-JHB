function cs_plotPhaseLocking_individualCells(region,nbins)
%% Params
[topDir, figDir] = cs_setPaths();
animals = {'CS31','CS33','CS34','CS35'};
bins = -pi:(2*pi/nbins):pi;

bins2 = [bins - pi, bins(2:end) + pi];
bincenters = bins2(2:end) - (bins2(2)-bins2(1))/2;
newbins = bincenters;
     
 switch region
        case 'CA1'
            color = rgb('MediumIndigo');
        case 'PFC'            
            color = rgb('DarkAquamarine');
 end

%% Loop
for a = 1:length(animals)
    animal = animals{a};
    animDir = [topDir, animal,'Expt\',animal,'_direct\'];
    
    files = dir([animDir,animal,'betaphaselock_',region,'*']);
    
    for d = 1:length(files)
            load(files(d).name)
            eval(['beta_phaselock = beta_phaselock',region,';']);

           
            cellfilter = '(~isempty($sph) & ($prayl < 0.05) &($Nspikes > 10))'; %only PL cells
            cells = evaluatefilter(beta_phaselock,cellfilter);
     
            for c = 1:size(cells,1)
%% Gather Data
                ind = cells(c,:);
                daystr = getTwoDigitNumber(ind(1));
                epstr = getTwoDigitNumber(ind(2));
                tetstr = getTwoDigitNumber(ind(3));
                cellstr = getTwoDigitNumber(ind(4));
 
                sph = beta_phaselock{ind(1)}{ind(2)}{ind(3)}{ind(4)}.sph;
                betahat = beta_phaselock{ind(1)}{ind(2)}{ind(3)}{ind(4)}.betahat;
                kappa = beta_phaselock{ind(1)}{ind(2)}{ind(3)}{ind(4)}.kappa;
                
                count = histcounts(sph, bins);
                pct = (count./sum(count))*100;
                newcount = [pct,pct];
                
%% Plot
                figure, hold on
                set(gcf, 'Position', [3000 500 800 350]);
                out = bar(newbins, newcount,1);
                set(out, 'EdgeColor',color);
                set(out, 'FaceColor',color);
                plot([0 0], [0 max(newcount+2)], 'k--');
                axis([-2*pi, 2*pi, 1 max(newcount+2)])
                xticks([-2*pi -pi 0 pi 2*pi])
                xticklabels({'-2\pi','-\pi','0','\pi','2\pi'})
                xlabel('Beta Phase')
                ylabel('% of spikes')
    
%% PDF line       
                
                alpha = linspace(-pi, pi, nbins)';
                [pdf] = circ_vmpdf(alpha,betahat,kappa);
                 binnum = lookup(betahat,alpha);
                 pdf = pdf.*(pct(binnum)/pdf(binnum));
                 newpdf = [pdf; pdf]; 
                 newalpha = [alpha - pi; alpha + pi]; 
                 %newalpha = [alpha;alpha];
                 plot(newalpha,newpdf+1,'k','LineWidth',3,'Color','k');
        
    
                title([animal, ' ', daystr, ' ', epstr, ' ', tetstr, ' ', cellstr])
%% Save Figure
                figtitle = ['PL_',region,'_',animal,'_', daystr, '_', epstr, '_', tetstr, '_', cellstr];
                newfigfile = [figDir,'PhaseLocking\',figtitle];
                saveas(gcf,newfigfile,'fig');
                print('-dpdf', newfigfile);
                print('-djpeg', newfigfile);
                
                close all
            end
    end
end