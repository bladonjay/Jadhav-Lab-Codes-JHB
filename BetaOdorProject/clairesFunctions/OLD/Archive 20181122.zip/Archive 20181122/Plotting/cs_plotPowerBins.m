function cs_plotPowerBins(powerDataFile)
%Run from AnalysesAcrossAnimals folder

close all
load(powerDataFile);

%----- Params ----- %

data = betaPower.all;
% animals = betaPower.animals;
region = betaPower.region;
% trigtypes = betaPower.trigtypes;
% freqband = betaPower.freqband;

switch region
    case 'CA1'
        color = [0.8594 0.0781 0.2344];
    case 'PFC'
        color = [0.1172 0.5625 1];
    case 'OB'
        color = [0.1328 0.5430 0.1328];
end

win = betaPower.win ;
winstring = ['_',num2str(-win(1)*1000),'-', num2str(win(2)*1000),'ms'];
binsize = betaPower.binsize;


 meanPowerBin_all = nanmean(data,1);
 semPowerBin_all = (nanstd(data,1)/sqrt(size(data,1)));


x_a = [-win(1):binsize:win(2)];
x_a = x_a(2:end)-(binsize/2);
figure,

for b = 1:length(x_a)
    alpha = 0.05/length(x_a);
    [h_a, p_a] = ttest(data(:,b), 0, alpha);
    stats_a(1:2,b) = [h_a, p_a];
end

nsigbinsindx = unique([find(stats_a(1,:) == 0), find(meanPowerBin_all < 0)]);
nsigbins = x_a(nsigbinsindx);
sigbins = x_a;
sigbins(nsigbinsindx) = [];
sigbinsindx = find(ismember(x_a, sigbins));


br_s = bar(sigbins,meanPowerBin_all(sigbinsindx), 'FaceColor',color, 'EdgeColor',color,  'BarWidth', 0.5); hold on
br_n = bar(nsigbins,meanPowerBin_all(nsigbinsindx), 'w','EdgeColor',color, 'BarWidth',0.5,'LineWidth',1.5); hold on


errorbar(x_a, meanPowerBin_all,semPowerBin_all,'LineWidth',1.25,'LineStyle','none', 'Color','k');

if strcmp(region,'OB')    
    axis([-win(1) win(2) -.5 2.5]);
    plot([0 0], [-.6 2.5], 'k--', 'LineWidth',1.5)
else
    axis([-win(1) win(2) -.4 1.6]);
    plot([0 0], [-.4 1.6], 'k--', 'LineWidth',1.5)
end



xticks([-win(1):binsize*2:win(2)]);
box off

xlabel('Seconds from Odor Onset');
ylabel('Average Z scored beta power');

set(gcf, 'Position', [2000 350 900 600]);
set(gca,'fontsize',20);

betaPower.stats = stats_a ;

filename = ['E:\AnalysesAcrossAnimals\betaPower',region,'_binned',winstring,'.mat'];
save(filename,'betaPower');

figtitle =['betaPower', region,winstring];
%         title(['betaPower', region])

%figdir = 'D:\Figures\EEG\';
figdir = 'E:\Figures\NicePPTFigures\';
figfile = [figdir,figtitle];
%         print('-dpdf', figfile);
print('-dpng', figfile);

saveas(gcf,figfile,'fig');