function cs_plotEnsembleTraj_mov(dataDir, animal, region, day, trigtypes, plotall)


% cs_plotEnsembleTraj('E:\AnalysesAcrossAnimals\', 'CS34', 'CA1', 4, {'leftTriggers','rightTriggers'}, 0)

daystring = getTwoDigitNumber(day);
daystring = ['Day_',daystring];
for g = 1:length(trigtypes)
    trigtype = trigtypes{g};
    ensembleFile = ['spikingColumnVectors_',region,'_',trigtype,'.mat'];

    load([dataDir,ensembleFile]);

    animals = spikeColumnVectors.animals;
    numbins = spikeColumnVectors.numbins;
    win = spikeColumnVectors.win;
    binsize = spikeColumnVectors.binsize;
    
    bins = [-win(1):binsize:win(2)];

    animnum = find(strcmp(animals, animal));
        an = animnum;

    data = spikeColumnVectors.data(an).Animals;

    data = data.(daystring);

    trialsCombined = horzcat(data.FRvectorsAllCells);
    [signals, PC, V] = pca1(trialsCombined);
    
    ensembleActivity.(trigtype).signals = signals;
    ensembleActivity.(trigtype).PC = PC;
    ensembleActivity.(trigtype).V = V;
    ensembleActivity.(trigtype).numbins = numbins;

    sig1All = zeros(length(data), numbins); 
    sig2All = sig1All; sig3All = sig1All;
    for t = 1:(size(trialsCombined,2)/numbins)

        columnStart = (numbins*t) - (numbins-1);
        columnEnd =  (numbins*t);
        
        sig1All(t,:) = signals(1, columnStart:columnEnd);
        sig2All(t,:) = signals(2, columnStart:columnEnd);
        sig3All(t,:) = signals(3, columnStart:columnEnd);
        if plotall ==1 
            plottag = 'allTrials';
            switch trigtype
                case 'leftTriggers'
                    plot3(signals(1,columnStart:columnEnd),signals(2,columnStart:columnEnd),signals(3,columnStart:columnEnd),'Color',[0.5273    0.8047    0.9792])
                    hold on
                case 'rightTriggers'
                    plot3(signals(1,columnStart:columnEnd),signals(2,columnStart:columnEnd),signals(3,columnStart:columnEnd),'Color',[1.0000    0.7500    0.7930])
                    hold on
            end
        else
            plottag = 'meanOnly';
        end
    end
    meansig1 = mean(sig1All,1);
    meansig2 = mean(sig2All,1);
    meansig3 = mean(sig3All,1);
    
if strcmp(trigtype, 'leftTriggers')
    Lmeansig1 = meansig1;
    Lmeansig2 = meansig2;
    Lmeansig3 = meansig3;
end
if strcmp(trigtype, 'rightTriggers')
    Rmeansig1 = meansig1;
    Rmeansig2 = meansig2;
    Rmeansig3 = meansig3;
end
end
    
maxx = max([Lmeansig1, Rmeansig1]);
maxy = max([Lmeansig2, Rmeansig2]);
maxz = max([Lmeansig3, Rmeansig3]);

minx = min([Lmeansig1, Rmeansig1]);
miny = min([Lmeansig2, Rmeansig2]);
minz = min([Lmeansig3, Rmeansig3]);

    figure
    view(-42, 20);
    set(gca,'XLim',[minx-1 maxx+1], 'YLim',[miny-1 maxy+1], 'ZLim',[minz-1 maxz+1]);
    curve1 = animatedline;
    curve2 = animatedline;
    
    for i = 6:11
        addpoints(curve1,Lmeansig1(i),Lmeansig2(i),Lmeansig3(i));
        addpoints(curve2,Rmeansig1(i),Rmeansig2(i),Rmeansig3(i));
        drawnow
        pause(.5);
    end

%     p1 = plot3(meansig1(3:6),meansig2(3:6),meansig3(3:6),'Color',[rgb('Gray')],'LineWidth',2.5); hold on
%     
%     if strcmp(trigtype, 'leftTriggers')
%          p2 = plot3(meansig1(6:11),meansig2(6:11),meansig3(6:11),'Color',[rgb('DarkTurquoise')],'LineWidth',2.5); hold on  
%          %p3 = plot3(meansig1(11:15),meansig2(11:15),meansig3(11:15),'Color',[rgb('PaleTurquoise')],'LineWidth',2.5);
%             %plot(meansig2,'bo','LineWidth',2.5)
%             hold on
%     end
%     if strcmp(trigtype, 'rightTriggers')
%            p4 = plot3(meansig1(6:11),meansig2(6:11),meansig3(6:11),'Color',[rgb('BlueViolet')],'LineWidth',2.5); hold on
%            %p5 = plot3(meansig1(11:15),meansig2(11:15),meansig3(11:15),'Color',[rgb('Violet')],'LineWidth',2.5);
% %             plot(meansig2,'ro','LineWidth',2.5) 
%             hold on
%     end
%    
    


grid on
xlabel('PC 1')
ylabel('PC 2')
zlabel('PC 3')

set(gca, 'XTickLabel', []);
set(gca, 'YTickLabel', []);
set(gca, 'ZTickLabel', []);

set(gcf, 'Position', [2000 400 900 600]);
                set(gca,'fontsize',20);
legend([p1, p2, p3, p4, p5], 'Before Odor', 'Left Odor', 'After Left Odor', 'Right Odor', 'After Right Odor'); 

filename = ['ensembleActivity_',animal,'_',region,'.mat'];
save([dataDir,filename],'ensembleActivity'); 


figname = ['Ensemble trajectories ',region,' ',plottag]; 
% title(figname);
% grid on 

%figdir = 'D:\Figures\'; %lab
%figdir = 'E:\Figures\EnsembleTrajectories\';
figdir = 'E:\Figures\NicePPTFigures\';
    figfile = [figdir,figname];
    
    %print('-djpeg', figfile);
    print('-dpng', figfile);
    %print('-dtiff',figfile);
    saveas(gcf,figfile,'fig');
close all
    