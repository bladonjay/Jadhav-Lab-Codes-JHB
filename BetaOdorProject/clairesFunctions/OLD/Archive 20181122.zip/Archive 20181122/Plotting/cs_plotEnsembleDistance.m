function cs_plotEnsembleDistance(ensembleDistanceFile)
% 
% cs_plotEnsembleDistance('ensembleDistance_CA1_-0.2-0.6ms.mat')

load(ensembleDistanceFile)

Zscore = ensembleDistance.Zscore;
winstring = ensembleDistance.winstring;
bins = ensembleDistance.bins;
binsize = ensembleDistance.binsize;
region = ensembleDistance.region;
endstring = erase(ensembleDistanceFile, ['ensembleDistance']);
endstring = erase(endstring, ['.mat']);

figure
newbins = (bins(1:end-1)+(.5*binsize));
axis([-.2 .6 0 9.5])

nsigbinsindx = find(Zscore < 2);
sigbinsindx = find(Zscore > 2);

nsigZ = Zscore;
nsigZ(sigbinsindx) = 0;

sigZ = Zscore;
sigZ(nsigbinsindx) = 0;
switch region
    case 'CA1'
        color = rgb('Crimson');
        bar(newbins, sigZ,'FaceColor',color, 'EdgeColor', color); hold on
        bar(newbins, nsigZ, 'w','EdgeColor',color, 'LineWidth',1.5);
        %needed to plot an extra bar because it messes up otherwise. Just cut it
        %off of the final figure. 
        axis([-.2 .6 0 9.5])
        plot([0 0], [0 9.5], 'k--', 'LineWidth',1.5);
        
    case 'PFC'
        color = rgb('DodgerBlue');
        
        bar( newbins(nsigbinsindx), Zscore(nsigbinsindx) , 'w','EdgeColor',color, 'LineWidth',1.5);  hold on
        bar(newbins(sigbinsindx), Zscore(sigbinsindx),'FaceColor',color, 'EdgeColor', color);
        axis([-.2 .6 0 4.5])
        plot([0 0], [0 4.5], 'k--', 'LineWidth',1.5);
end


xlabel('Seconds from Odor Onset');
ylabel('Population Distance Index Z-Score');

set(gcf, 'Position', [2000 350 900 600]);
set(gca,'fontsize',20);
box off

figtitle = ['ensembleDistance',endstring];
figdir = 'E:\Figures\NicePPTFigures\';
figfile = [figdir,figtitle];
%         print('-dpdf', figfile);
print('-dpng', figfile);

saveas(gcf,figfile,'fig');
      