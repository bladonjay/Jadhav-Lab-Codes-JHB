function cs_plotTetSpecgrams(animals, regions, varargin)
%run from inside AnalysesAcrossAnimals\tetSpecgrams folder


%defaults, use varargin to specify if other
freqband = 'low';
    freqs = [1:40];
win = [1.5 1.5];
    winstring = [num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms'];
tapers = [1 1];
    taperstring = ['tapers',num2str(tapers(1)),'-', num2str(tapers(2))];
binsize = 20;
    binsizestr = [num2str(binsize),'msBins'];
Triggers = 'odorTriggers';
trigtypes = {'allTriggers'};

for option = 1:2:length(varargin)-1
    switch varargin{option}
        case 'Triggers'
            Triggers = varargin{option+1};
            if strcmp(Triggers,'odorTriggers')
                 trigstring = '';
             else
                 trigstring = [Triggers,'_'];
            end
        case 'freqband'
            freqband = varargin{option+1};
                switch freqband
                    case 'low'
                        freqs = [1:40];
                    case 'mid'
                        freqs = [1:100];
                end   
        case 'win'
            win = varargin{option+1};
                winstring = [num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms'];
        case 'tapers'
            tapers = varargin{option+1};
                taperstring = ['tapers',num2str(tapers(1)),'-', num2str(tapers(2))];
        case 'binsize'
            binsize = varargin{option+1};
                binsizestr = [num2str(movingwin(2)*1000),'msBins'];
        case 'trigtypes'
            trigtypes = varargin{option+1};
            
    end
end

timewin = (win(1) - (-win(2)));

paramstring = [freqband,'_',winstring,'_',taperstring,'_',binsizestr];

files = dir();
filenames = {files(3:end).name};

f = strfind(filenames, paramstring);
paramsFiles = filenames(find(not(cellfun('isempty', f))));


for a = 1:length(animals)
    animal = animals{a};
    
    for r = 1:length(regions)
        region = regions{r};
        
        str = [animal,'_',region];
        f = strfind(paramsFiles, str);
        goodFiles = filenames(find(not(cellfun('isempty', f))));
        
        for i = 1:length(goodFiles)
            load(goodFiles{i});
            
            std=2;
            for g = 1:length(trigtypes) %for each trigtype


                trigtype = trigtypes{g};

                specdata = tetSpecgramData.(trigtype)';
                tet = tetSpecgramData.tet;
                tetstr = getTwoDigitNumber(tet);
                
                times = [-win(1), timewin/length(specdata), win(2)];

                s = gaussian2(std,(2*std));
                smoothedspecdata = filter2(s,specdata); 
                %smoothedspecdata = specdata;

                figure, hold on
                colormap(jet);
                imagesc(times, freqs,smoothedspecdata)
                set(gca,'YDir','normal')
                plot([0 0],[1 freqs(end)],'k--', 'LineWidth', 1.5);
                axis([-win(1) win(2) 1 freqs(end)])
                colorbar

            %     figure, colormap(jet);
            %     imagesc(times, freqs, specdata)
            %     set(gca,'YDir','normal')
            %     colorbar
            %     hold on
            %     plot([0 0],[1 40],'k--', 'LineWidth', 1.5);
            %     axis([-win(1) win(2) 1 40])

                figtitle = ['Spectrogram_',str, '_Tet',tetstr,'_', paramstring];
                title(sprintf('%s%d',figtitle), 'Interpreter', 'none'); %allows underscores in fig titles

                %figdir = 'E:\Figures\Specgrams\tetSpecgrams\'; %home comp
                figdir = 'D:\Figures\Specgrams\tetSpecgrams\'; %lab comp
                figfile = [figdir,figtitle];

                print('-djpeg', figfile);
                print('-dpng', figfile);
                saveas(gcf,figfile,'fig');

                clear specdata
            end
        end
    end
end