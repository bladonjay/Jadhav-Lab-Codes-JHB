function cs_plotRasterPSTH_v2(cellSelectivityDataFile, win, minZ)

load(cellSelectivityDataFile);

binsize = (win(2)+win(1))/(size(cellSelectivity(1).psthleftTriggers,2)-1);
bins = (-win(1):binsize:win(2));

zscores = [cellSelectivity.zscore];
goodCellInds = find(abs(zscores) >= minZ);

for c = 1:length(goodCellInds)
    cellInd = goodCellInds(c);
    
    leftSpikes = cellSelectivity(cellInd).psthleftTriggers;
    rightSpikes = cellSelectivity(cellInd).psthrightTriggers;
    
    leftSpikeTimes = cellSelectivity(cellInd).leftSpikeTimes.*1000;
    rightSpikeTimes = cellSelectivity(cellInd).rightSpikeTimes.*1000;
    
    animal = cellSelectivity(cellInd).animal;
    cellNum = cellSelectivity(cellInd).cellnum;
    SI = cellSelectivity(cellInd).selectivityIndex;
    zscore = cellSelectivity(cellInd).zscore;
    
    left = leftSpikes./(binsize/1000);
    leftFRavg = mean(left,1);
         
    leftFR = smoothdata(leftFRavg, 'gaussian', 8);
    
    right = rightSpikes./(binsize/1000);
    rightFRavg = mean(right,1);
    
    rightFR = smoothdata(rightFRavg, 'gaussian', 8);

    figure, 
        suptitle([animal,' Cell ', num2str(cellNum), ' SI = ', num2str(SI), ' Z = ', num2str(zscore)])
        subplot(3, 1, 1), hold on
        for i = 1:size(leftSpikeTimes,1)
            plot(leftSpikeTimes(i,:), i, 'g.')
        end
        
        plot([0 0], [0 (length(leftSpikeTimes))], 'k--');
        axis( [-win(1) win(2) 0 length(leftSpikeTimes)])
        
        subplot(3, 1, 2), hold on
        for i = 1:size(rightSpikeTimes,1)
            plot(rightSpikeTimes(i,:), i ,'m.')
        end
        plot([0 0], [0 (length(rightSpikeTimes))], 'k--');
        axis( [-win(1) win(2) 0 length(rightSpikeTimes)])
        
        subplot(3, 1, 3)
        hold on
        plot(bins, leftFR, 'g');
        plot(bins, rightFR, 'm');
        
        plot([0 0], [0 5], 'k--');
        
        
        

       pause;
    
end


