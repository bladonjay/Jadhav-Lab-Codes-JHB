function cs_plotPhaseLocking(phaselockingfile)

load(phaselockingfile)

dataAllCells = betaMod;

pvals = [dataAllCells.prayl];
sigPL = (pvals <=0.05)';

sigCells = dataAllCells(sigPL);
nbins = length(sigCells(1).alpha)-1;
bins = -pi:(2*pi/nbins):pi;

for c = 1:length(sigCells)
    spikephase = sigCells(c).spikephase;
    cellindex = sigCells(c).index;
    animal = sigCells(c).animal;
    
    count = histc(spikephase, bins);
    figure; %redimscreen_2horsubplots
    set(gcf, 'Position', [1800 100 900 600]);
    %set(gcf, 'Position', [2000 350 900 600]); %for dual monitors
    subplot(2,1,1);
    hold on;
    out = bar(bins, count, 'hist'); set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
    hold on
    binnum = lookup(sigCells(c).betahat,sigCells(c).alpha);
    pdf = sigCells(c).vmpdf;
    pdf = pdf.*(count(binnum)/pdf(binnum));
    plot(sigCells(c).alpha,pdf,'k','LineWidth',3,'Color','k');
    
    set(gca,'XLim',[-pi-0.5 pi]); ylabel('NSpikes'); set(out,'FaceColor','r');
    titlestring = [animal, ' ', num2str(cellindex)];
    title(titlestring);
    % Shantanu - add a plot with %tage of spikes
    % -------------------------------------------
%     subplot(2,2,2);
%     hold on;
%     totalspks = sum(count);
%     countper = (count./totalspks)*100;
%     out = bar(bins, countper, 'hist');  set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
%     set(gca,'XLim',[-pi-0.5 pi]); ylabel('% of Spikes'); set(out,'FaceColor','r');
    
    
    [t,r] = rose(spikephase);
    subplot(2,1,2);
    polar(t,r,'r'); hold on;
    % The peak phase angle
    lims = get(gca,'XLim');
    radius = lims(2);
    
    ph = degtorad(sigCells(c).phdeg);
    xx = radius .* cos(ph); yy = radius .* sin(ph);
    line([0 xx], [0 yy],'LineWidth',4,'Color','k'); %plot(xx,yy,'ko','MarkerSize',4);
    
    pause
    
end
    
    
    