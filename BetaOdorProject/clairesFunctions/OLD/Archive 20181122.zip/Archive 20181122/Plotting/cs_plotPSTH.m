function cs_plotPSTH(prefix, datadir)
%enter datadir with trailing \

filename = [datadir, prefix, 'psth.mat'];
load(filename);

leftTrials = psth.leftTrials;

rightTrials = psth.rightTrials;
bins = rightTrials(1).bins;


for c = 1:length(leftTrials)
    if (any(leftTrials(c).smoothedpsth)) || (any(rightTrials(c).smoothedpsth)) 
%         leftpsth = leftTrials(c).smoothedpsth;
%         rightpsth = rightTrials(c).smoothedpsth;

        leftpsth = leftTrials(c).smoothedpsth;
        leftsemup = leftTrials(c).smoothedpsth + leftTrials(c).smoothedSEM;
        leftsemdown = leftTrials(c).smoothedpsth - leftTrials(c).smoothedSEM;
        
        
        rightpsth = rightTrials(c).smoothedpsth;
        rightsemup = rightTrials(c).smoothedpsth + rightTrials(c).smoothedSEM;
        rightsemdown = rightTrials(c).smoothedpsth - rightTrials(c).smoothedSEM;
        
        index = leftTrials(c).index;
        
        
        figure, hold on
        plot(bins, leftpsth, 'r-', 'Linewidth', 3)
        plot(bins, rightpsth, 'b-', 'Linewidth', 3)
        alpha(patch([bins, fliplr(bins)], [leftsemup, fliplr(leftsemdown)], [1 0 0], 'EdgeColor','None'),0.3);
        alpha(patch([bins, fliplr(bins)], [rightsemup, fliplr(rightsemdown)], [0 0 1], 'EdgeColor','None'),0.3);
        plot([0 0], [0 10], 'k--', 'Linewidth', 2)
        
        xlabel('Average firing rate')
        ylabel('Number of spikes')
        
        title(['Day ', num2str(index(1)), ' Tetrode ', num2str(index(2)), ' Cell ', num2str(index(3))]);
        
    end
end
       