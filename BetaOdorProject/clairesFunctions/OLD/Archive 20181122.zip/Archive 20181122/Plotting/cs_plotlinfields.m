function cs_plotlinfields(dataDir, prefix, runIndex, trialtype, tetrodesinarea)
% runIndex should be Mx2 matrix, where each row represents a different
% epoch. e.g.:
% 
%         1  2
%         1  4
%         1  6
%         2  2
%         2  4
%         2  6

%trial type should be 0 (right) or 1 (left)


loadstring = [dataDir, prefix,'placeFieldData.mat'];
load(loadstring);

if trialtype == 0
    linFields = placeFieldData.rightTrials;
    trialstr = 'Right trials';
elseif trialtype == 1
    linFields = placeFieldData.leftTrials;
    trialstr = 'Left trials';
end

for e = 1:size(runIndex,1)
    
    for c = 1:length(linFields)
        epochcells = [];
        if isequal(linFields(c).index(1:2), runIndex(e,:)) && ismember(linFields(c).index(3), tetrodesinarea)
            epochcells = [epochcells ; linFields(c).smoothedspikerate];
        end
        
    end
    
    orderedcells = [epochcells, zeros(size(epochcells,1),1)];
    for r = 1:size(epochcells,1)
        
        [val, peakIndex] = max(epochcells(r,:));
        if val>=4 && val<=30 
        orderedcells(r,size(orderedcells,2)) = peakIndex;
        end
        
    end

    orderedcells = sortrows(orderedcells,size(orderedcells,2));
    orderedcells = orderedcells((orderedcells(:,end) > 0),:);
    orderedcells = orderedcells(:,1:end-1);
    
    figure,
    imagesc(orderedcells);
    colormap(jet);
    colorbar;
    
    titlestring = ['Day ' num2str(runIndex(e,1)), ' Epoch ', num2str(runIndex(e,2)), ' ', trialstr];
    title(titlestring)
    xlabel('Linar distance from nosepoke (cm)');
    ylabel('Cell number');
    
        
end
            
            
            
        
