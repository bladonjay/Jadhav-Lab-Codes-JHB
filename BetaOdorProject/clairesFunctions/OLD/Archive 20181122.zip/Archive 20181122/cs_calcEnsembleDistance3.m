function [Zscore] = cs_calcEnsembleDistance3(dataDir, region, win,binsize)

% cs_calcEnsembleDistance2('E:\AnalysesAcrossAnimals\', 'CA1', [.2 .6])

winstring = [num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms'];
binstr = [num2str(binsize),'msBins'];


load([dataDir,'TriggeredSpiking_',region,'_',winstring,'_',binstr,'.mat']);
binsize = triggeredSpiking.binsize;
bins = (-win(1):binsize:win(2));

%----- Gather data from all animals together -----%
allAnimalSpikes = []; 
for an = 1:length(triggeredSpiking.data)
     spikingdata = triggeredSpiking.data(an).output{1,1};
     
     %----- Take only cells that spiked during sniffing -----%
     
     spikingcells = spikingdata(~isnan(vertcat(spikingdata.selectivityIndex)));
     
     if isempty(allAnimalSpikes)
         allAnimalSpikes = spikingcells;
     else
        allAnimalSpikes(end+1:end+length(spikingcells)) = spikingcells;
     end
     
end

%---- Find average FR in each time bin for each cell -----%

leftFR = zeros(length(allAnimalSpikes), length(bins)-1); %one cell in each row
rightFR = zeros(length(allAnimalSpikes), length(bins)-1);

for c = 1:length(allAnimalSpikes)
    cell = allAnimalSpikes(c);
    
    cellspikesleft = cell.psthleftTriggers(:,1:end-1);
    cellspikesright = cell.psthrightTriggers(:,1:end-1);
    
    cellFRleft = cellspikesleft/binsize;
    cellFRright = cellspikesright/binsize;
    
    leftFR(c,:) = mean(cellFRleft,1);
    rightFR(c,:) = mean(cellFRright,1);
    
end



%----- Calculate PDI -----%
PDI = zeros(1,length(bins)-1);
for b = 1:length(bins)-1
    FRbinL = leftFR(:,b);
    FRbinR = rightFR(:,b);
    
    magL = sqrt(sum(FRbinL.^2));
    magR = sqrt(sum(FRbinR.^2));
    
    CCbin = (dot(FRbinL,FRbinR))/(magL * magR);
    
    PDIbin = 1-CCbin; %PV Differential Index, from Igarashi et al 2014
    PDI(b) = PDIbin;
    
end

%---- Calculate Euclidean Distance -----%
EDist = zeros(1,length(bins)-1);
for b = 1:length(bins)-1
    FRbinL = leftFR(:,b);
    FRbinR = rightFR(:,b);
    
    dist = sqrt(sum((FRbinL - FRbinR).^2)); 
    
    EDist(b) = dist;
end


%---- Compare to Shuffle -----%
iterations = 1000;

Zscore = zeros(1,length(bins)-1);
for b = 1:length(bins)-1
    
    shuffPDI = zeros(iterations,1);
    for i = 1:iterations

        leftFRNew = zeros(length(allAnimalSpikes),1);
        rightFRNew = zeros(length(allAnimalSpikes),1);
        for c = 1:length(allAnimalSpikes)
            cell = allAnimalSpikes(c);

            cellspikesleft = cell.psthleftTriggers(:,b);
            cellspikesright = cell.psthrightTriggers(:,b);

            cellFRleft = cellspikesleft/binsize;
            cellFRright = cellspikesright/binsize;

            leftIndicators = ones(size((cellFRleft),1),1);
            rightIndicators = zeros(size((cellFRright),1),1);

            indicators = [leftIndicators; rightIndicators];
            cellFRAll = [cellFRleft; cellFRright];

            %----- Do the shuffle -----%
            shuffledRL = indicators(randperm(length(indicators)));

            cellLeftFR = mean(cellFRAll(shuffledRL == 1,:),1);
            cellRightFR = mean(cellFRAll(shuffledRL == 0,:),1);

            leftFRNew(c,:) = cellLeftFR;
            rightFRNew(c,:) = cellRightFR;
        end

        %PDIiteration = zeros(1,length(bins)-1);
    %for b = 1:length(bins)-1
%         FRbinL = leftFRNew(:,b);
%         FRbinR = rightFRNew(:,b);

        FRbinL = leftFRNew;
        FRbinR = rightFRNew;

        magL = sqrt(sum(FRbinL.^2));
        magR = sqrt(sum(FRbinR.^2));

        CCbin = (dot(FRbinL,FRbinR))/(magL * magR);

        PDIbin = 1-CCbin; %PV Differential Index, from Igarashi et al 2014
        %PDIiteration(b) = PDIbin;

    %end
    
    %shuffPDI(i) = PDIiteration;
        shuffPDI(i) = PDIbin;
    end

    meanShuff = mean(shuffPDI,1);
    stdShuff = std(shuffPDI,1);

    Zscore(1,b) = (PDI(b) - meanShuff)./stdShuff;
end
    
    
    
ensembleDistance.Zscore = Zscore;
ensembleDistance.winstring = winstring;
ensembleDistance.bins = bins;
ensembleDistance.binsize = binsize;
ensembleDistance.region = region;

save([dataDir,'ensembleDistance3_',region,'_',winstring,'_',binstr,'.mat'],'ensembleDistance')


% figure
% newbins = (bins(1:end-1)+(.5*binsize));
% 
% nsigbinsindx = find(Zscore < 2);
% sigbinsindx = find(Zscore > 2);
% 
% color = rgb('Indigo');
% bar(newbins(sigbinsindx), Zscore(sigbinsindx),'FaceColor',color, 'EdgeColor', color); hold on
% bar(newbins(nsigbinsindx), Zscore(nsigbinsindx), 'w','EdgeColor',color, 'LineWidth',1.5, 'BarWidth', 0.5);
% 
% 
% 
% 
% hold on
% plot([bins(1) bins(end)], [2 2], 'r--');
% plot([0 0], [0 10], 'k-');
% disp('done');        