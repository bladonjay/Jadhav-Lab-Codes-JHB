function cs_eventTrigMultiunit(dataDir,animID,epochindex, win, trialtype)
%epochindex = matrix where column1 is day and column2 is epoch (for
%separating laseron/laseroff)

%trialtype- 'Disruption' or 'Control'

days = unique(epochindex(:,1));

load([dataDir,animID,'tetinfo.mat'])
    
tetfilter = '(isequal($area, ''PFC''))';
tets = evaluatefilter(tetinfo, tetfilter);
tets = unique(tets(:,3));

allSpikeTimes = [];
for d = 1:length(days)
    day = days(d);
    
    daystr = getTwoDigitNumber(day);
    load([dataDir,animID,'laserTriggers',daystr,'.mat']);
    load([dataDir,animID,'spikes',daystr,'.mat']);
    
    
    epochs = epochindex(epochindex(:,1) == day, 2);
    
    for e = 1:length(epochs)
        epoch = epochs(e);
        
        triggers = laserTriggers{1,day}{1,epoch}.allTriggers;
        
        for t = 1:length(tets)
            tet = tets(t);
            multiunit = spikes{1,day}{1,epoch}{1,tet}{1,1}.data(:,1);
            
            for tr = 1:length(triggers)
                trigger = triggers(t);
                trigstart = trigger - win(1);
                trigend = trigger + win(2);
            trigspikes = multiunit(multiunit >= trigstart & multiunit <= trigend);
            trigspikes = trigspikes - trigger;
            
            allSpikeTimes = [allSpikeTimes ; trigspikes];
            end
        end
    end
end

counts = histogram(allSpikeTimes, [-win(1):.01:win(2)]);
vline(0,'k')
xlabel('Time from laser pulse (s)')
ylabel('Number of Spikes')

figname = ['D:\Figures\',animID, '_', trialtype];
print('-dpng', figname);
print('-djpeg', figname);
saveas(gcf,figname,'fig');
            
            
            



