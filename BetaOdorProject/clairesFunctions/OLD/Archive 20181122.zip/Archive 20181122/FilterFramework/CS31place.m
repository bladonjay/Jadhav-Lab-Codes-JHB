
animals={'CS31'}; %CHANGE DATADIR PATH IN 'animaldef.mat' FOR DIFFERENT COMPUTERS
    runepochfilter = 'isequal($environment, ''odorplace'')';
    %cellfilter = '((strcmp($area, ''CA1'') && ($numspikes > 100))  ||  (strcmp($area, ''PFC'') && ($numspikes > 100) ) )';
    %timefilter = { {'DFTFsj_getlinstate', '(($state ~= -1) & (abs($linearvel) >= 5))', 6} }; 
    %riptetfilter = '(isequal($descrip, ''riptet''))';
    %timefilter = { {'DFTFsj_getlinstate', '(($state ~= -1) & (abs($linearvel) >= 5))', 6, 'headdir',0}, {'DFTFsj_getriptimes','($nripples == 0)','tetfilter',riptetfilter,'minthresh',3} };
    %timefilter = {{'DFTFsj_getvelpos', '(($absvel >= 5))'}};
    tetfilter = '(strcmp($area, ''CA1''))';
    % Iterator
    % --------
    iterator = 'eeganal';
    
    % Filter creation
    % ----------------
    psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtrodes',tetfilter, 'iterator', iterator);
    % psf = createfilter('animal',animals,'days',dayfilter,'epochs',epochfilter,'cells',placecellfilter,'iterator', iterator);
    
    % Set analysis function
    % ---------------------
    %pmf_all = setfilterfunction(psf, 'DFAsj_openfieldrate_tf', {'spikes', 'linpos', 'pos', 'runTrialBounds'}, 'appendindex' ,1 , 'binsize', 1, 'std', 2);    
%     pmf_left = setfilterfunction(psf, 'DFAcs_linposfield', {'spikes', 'linpos', 'runTrialBounds'}, 'appendindex' ,1 , 'binsize', 1, 'std', 2, 'trialtype', 1);    
%     pmf_right = setfilterfunction(psf, 'DFAcs_linposfield', {'spikes', 'linpos', 'runTrialBounds'}, 'appendindex' ,1 , 'binsize', 1, 'std', 2, 'trialtype', 0); 
    % Run analysis 
    % ------------
    %pmf_all = runfilter(pmf_all);  % Place Field Map
    pmf_left = runfilter(pmf_left);
    pmf_right = runfilter(pmf_right);
    
    % tetrode metadata
 hpc   = [2 3 4 17 18 19 20 27 28 29 30 31 32];
 hpcRef=  1;
 pfc   = [7 8 9 11 12 13 14 15 16 21 22 23 25 26];
 pfcRef=   10;
 ob = [24];
 %riptetlist = [1,2,3,4,5,6];
 
 %Saves data so you don't have to run filter every time
%  animalString = animals{1,1}; 
%  f = ['D:\OdorPlaceAssociation\CS31Expt\CS31_direct\',animalstring,'placeFieldData'];
%  try 
%      load(f);
%      CS31placeFieldData = pmf.output{1,1};
%  catch
%      
 %CS31placeFieldData.allTrials = pmf_all.output{1,1};
 placeFieldData.leftTrials = pmf_left.output{1,1};
 placeFieldData.rightTrials = pmf_right.output{1,1};

 f = ['D:\OdorPlaceAssociation\CS31Expt\CS31_direct\CS31placeFieldData'];
 save([f '.mat'],'placeFieldData');
%  
%    for i=1:length(pmf.output{1, 1})
%         %sprintf('Doing cell %d',i); 
%         figure;
%         imagesc(flipud(pmf.output{1, 1}(i).smoothedspikerate)); colormap(jet);
%         ind= pmf.output{1, 1}(i).index;
%         if any(ind(3) == hpc); areaStr= 'hpc'; elseif any(ind(3) == pfc); areaStr= 'pfc'; elseif any(ind(3) == ctx); areaStr= 'ctx'; end;
%         name= ['tetrode' num2str(ind(3)) 'cell' num2str(ind(4)) 'area' areaStr 'day' num2str(ind(1)) 'epoch' num2str(ind(2))];
%         title(name);
%         figfile= ['D:\OdorPlaceAssociation\CS31Expt\CS31_direct\PlaceFields\' name];
%         colorbar;
%         print('-dpng', figfile, '-r300');
%         %close all;
%     end
