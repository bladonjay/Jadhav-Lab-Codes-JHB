function [ output ] = DFAcs_odorRasterPSTH(index, excludeperiods, spikes, odorTriggers, varargin)

% This function loops through all trials of a given type (left odor, right
% odor, etc) and identifies all spikes from a cell that occured within a
% specified time window around the odor onset time. 

%Outputs smoothed histogram with number of spikes in each bin, and also spiketimes for each trial.  

win = [0.5 1.0]; %default, can change with varargin
bin = .025;

for option = 1:2:length(varargin)-1   
    if isstr(varargin{option})       
        switch(varargin{option})
            case 'trialtype' %specify - 'allTriggers', 'leftTriggers', 'rightTriggers', 'correctTriggers', or 'incorrectTriggers'
                trialtype = varargin{option+1};
            case 'win'
                win = varargin{option+1}; 
            case 'binsize'
                bin = varargin{option+1};
            
	    otherwise
                error(['Option ',varargin{option},' unknown.']);
	end   
    else
        error('Options must be strings, followed by the variable');
    end
end



spikes = spikes{index(1)}{index(2)}{index(3)}{index(4)}.data;
odorTriggers = odorTriggers{index(1)}{index(2)}.(trialtype);


bins = [-win(1):bin:(win(2)+bin)];


triggerspikes = [];
rawpsth = zeros(length(odorTriggers), length(bins)-1);

for tr = 1:length(odorTriggers)
    timewin = [(odorTriggers(tr) - win(1)) (odorTriggers(tr) + win(2))];
    spikesinwin = spikes(spikes(:,1) >= timewin(1) & spikes(:,1) <= timewin(2));
    
    spikesinwin = spikesinwin - odorTriggers(tr); 
    if ~isempty(spikesinwin)
        triggerspikes = stack(triggerspikes, spikesinwin');
    end
    
    [hist] = histcounts(spikesinwin, bins);
    rawpsth(tr,:) = hist;
    
end

% figure, hold on
% for p = 1:size(triggerspikes,1)
%     plot(triggerspikes(p,:),p, 'k.');
% end
% plot([0 0], [0, size(triggerspikes,1)], 'k-');



%spikerate = 1000*hist/(length(odorTriggers)*bin);

% std = 2;
% g = gaussian(std,(6*std));
% smoothedhist = filter2(g,hist);

% figure
% plot(bins(1:end-1),smoothedhist, 'b-');

output.triggerspikes = triggerspikes;
output.rawpsth = rawpsth;
%output.smoothedpsth = smoothedhist;
output.bins = bins(1:end-1);
output.index = index;
end


