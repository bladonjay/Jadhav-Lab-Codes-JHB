
%----- Params -----%
animals = {'CS31','CS33','CS34','CS35'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS

regions = {'CA1','PFC'};
%datadir = 'E:\AnalysesAcrossAnimals\'; %home
datadir = 'D:\OdorPlaceAssociation\AnalysesAcrossAnimals\'; %lab


trigtypes = {'leftTriggers','rightTriggers'}; %always do LEFT first for consistency (matters for index)
win = [0 1];
binsize = 0.05;
FRthresh = 2;

binstr = [num2str(binsize*1000), 'msBins'];
winstr = ['_',num2str(-win(1)*1000), '-',num2str(win(2)*1000),'ms'];
%winstr = '';

plotfigs = 0; %change to zero if you don't want to plot all the PSTHs
figdir = 'D:\Figures\'; %lab computer

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for r=1:length(regions)
    region = regions{r}; 

%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';

switch region
    case 'CA1'
        cellfilter = '((strcmp($area, ''CA1'')) && ($numspikes > 100) && (strcmp($type, ''pyr'')))';
    case 'PFC'
        cellfilter = '((strcmp($area, ''PFC'')) && ($numspikes > 100) && (strcmp($type, ''pyr'')))';
end

%----- Iterator -----%
   
 iterator = 'singlecellanal';
    
%----- Filter creation -----%
    
 psf = createfilter('animal',animals,'epochs',runepochfilter,'cells',cellfilter,'excludetime', [],'iterator', iterator);   
    
%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_odorSelectivityPSTH',{'spikes','odorTriggers'},'trigtypes',trigtypes,'win',win,'binsize',binsize,'FRthresh',FRthresh);
    
%----- Run analysis -----%
out_all = runfilter(out);

    

disp('Done with all');

%---- Save file with params -----%
triggeredSpiking.data = out_all;
triggeredSpiking.animals = animals;
triggeredSpiking.region = region;
triggeredSpiking.trigtypes = trigtypes;
triggeredSpiking.win = win;
triggeredSpiking.binsize = binsize;


%----- Combine over Epochs! -----%
for a = 1:length(animals)
    data = [triggeredSpiking.data(a).output{1,1}];
    cellindex = vertcat(data.index);
    cellindexnoepochs = cellindex(:,[1,3,4]);
    
    uniquecells = unique((cellindexnoepochs),'rows');
    
    
    for c = 1:length(uniquecells)
        cell = uniquecells(c,:);
        cellstocombine = data(ismember(cellindexnoepochs,cell, 'rows'));
        
        if length(cellstocombine) > 1
            newdata(c).psthleftTriggers = vertcat(cellstocombine.psthleftTriggers);  
            for j = 2:length(cellstocombine)
                newdata(c).spikesleftTriggers = stack(cellstocombine(j).spikesleftTriggers,cellstocombine(j-1).spikesleftTriggers);
            end
            newdata(c).FRleftTriggers = mean([cellstocombine.FRleftTriggers]);
            newdata(c).psthrightTriggers = vertcat(cellstocombine.psthrightTriggers);    
            for j = 2:length(cellstocombine)
                newdata(c).spikesrightTriggers = stack(cellstocombine(j).spikesrightTriggers,cellstocombine(j-1).spikesrightTriggers);
            end     
            newdata(c).FRrightTriggers = mean([cellstocombine.FRrightTriggers]);
            newdata(c).selectivityIndex = nanmean([cellstocombine.selectivityIndex]);
            newdata(c).index = cell;
        else
            newdata(c) = data(c);
            newdata(c).index = cell;
        end
    end
    
    triggeredSpiking.data(a).output{1,1} = newdata;
    clear newdata
end


filename = ['TriggeredSpiking_', region, winstr,'_',binstr, '.mat'];

save([datadir,filename],'triggeredSpiking');

%save(['E:\AnalysesAcrossAnimals\',filename],'triggeredSpiking'); %home
%computer
save(['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\',filename],'triggeredSpiking'); %lab computer

cs_getCellSelectivity(datadir, filename, 10000);

selectivityFilename = ['cellSelectivityData_',region,winstr,'.mat'];


if plotfigs == 1
    cd(datadir)
    cs_plotRasterPSTH_v2(selectivityFilename, win*1000, 2)
end
 
end
