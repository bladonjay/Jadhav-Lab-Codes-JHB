function out = DFAcs_trigBetaMod(sind, eind, excludetimes, spikes, odorTriggers, beta, varargin)

win = 1; %how many seconds to look at after trigger
nbins = 24;
trigtypes = {'allTriggers','correctTriggers','incorrectTriggers','leftTriggers','rightTriggers'};


for option = 1:2:length(varargin)-1
    if isstr(varargin{option})
        switch(varargin{option})
            case 'nbins'
                nbins = varargin{option+1};
            case 'trigtypes'
                trigtypes = varargin{option+1};
            case 'win'
                win = varargin{option+1};
            otherwise
                error(['Option ',varargin{option},' unknown.']);
        end
    else
        error('Options must be strings, followed by the variable');
    end
end


spikes = spikes{sind(1)}{sind(2)}{sind(3)}{sind(4)}.data(:,1); %all spike times
disp(['Doing day ', num2str(sind(1)), ' epoch ', num2str(sind(2)), ' tetrode ', num2str(sind(3)), ' cell ', num2str(sind(4))]);

beta = beta{eind(1)}{eind(2)}{eind(3)};
    betatimes = (beta.starttime : (1/beta.samprate) : beta.endtime)';
    betaph = double(beta.data(:,2))/10000; %phase of beta at all timepoints

odorTriggers = odorTriggers{sind(1)}{sind(2)};

%----- Do separately for each trig type -----%
for g = 1:length(trigtypes)
    trigtype = trigtypes{g};
    triggers = odorTriggers.(trigtype);
    triggers(:,2) = triggers + win; %gives Nx2 matrix with start and end times for each trigger window
    
    trigspikes = [];
    for tr = 1:size(triggers,1)
        
        trigwin = triggers(tr,:);
        %if length(spikes(spikes> trigwin(1) & spikes<trigwin(2))) > 1
            trigspikes = [trigspikes; spikes(spikes> trigwin(1) & spikes<trigwin(2))]; %gets just the timing of each spike within trig window to compare to eeg phase
        %end
    end
    
   %----- STATS - Don't do here, combine over epochs first -----%
 if length(trigspikes) >= 10 %should there be a FR criterion?? 
       spikephase = betaph(lookup(trigspikes, betatimes)); 
 else 
     spikephase = [];
 end
% 
%         % Rayleigh and Modulation: Originally in lorenlab Functions folder
%         stats = rayleigh_test(spikephase); % stats.p and stats.Z, and stats.n
%         [mod, ph] = modulation(spikephase);
%         phdeg = ph*(180/pi); %convert to degrees ?
%         % Von Mises Distribution - From Circular Stats toolbox
%         [thetahat, kappa] = circ_vmpar(spikephase); % Better to give raw data. Can also give binned data.
%         thetahat_deg = thetahat*(180/pi);
% 
% 
%         [prayl, zrayl] = circ_rtest(spikephase); % Rayleigh test for non-uniformity of circular data
% 
%         % Make finer polar plot and overlay Von Mises Distribution Fit.
%         % Circ Stats Box Von Mises pdf uses a default of 100 angles/nbin
%         % ------------------------------------------------------------
%         %bins = -pi:(2*pi/nbins):pi;
%         %count = histc(spikephase, bins);
% 
%         % Make Von Mises Fit
%         alpha = linspace(-pi, pi, 50)';
%         [pdf] = circ_vmpdf(alpha,thetahat,kappa);
% 
%     else
%         spikephase = [];
%         stats=0;
%         mod=0;
%         phdeg=0;
%         kappa=0;
%         thetahat_deg=0;
%         prayl=0;
%         zrayl=0;
%         alpha=0;
%         pdf=0;
% 
%     end


    % Output
    % ------
    
    out.(trigtype).index = sind;
    out.(trigtype).tetindex = eind;
    out.(trigtype).spikephase = spikephase;
    out.(trigtype).Nspikes = length(trigspikes);
    
    
%     % Rayleigh test
%     out.(trigtype).stats = stats;
%     out.(trigtype).modln = mod;
%     out.(trigtype).phdeg = phdeg;
%     % Von Mises Fit
%     out.(trigtype).kappa = kappa;
%     out.(trigtype).thetahat_deg = thetahat_deg;
%     out.(trigtype).prayl = prayl;
%     out.(trigtype).zrayl = zrayl;
%     out.(trigtype).alpha = alpha;
%     out.(trigtype).vmpdf = pdf;

end








