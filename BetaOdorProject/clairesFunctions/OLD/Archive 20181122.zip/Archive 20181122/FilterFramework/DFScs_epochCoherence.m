%This function calculates the coherence for each tetrode pair across the
%each entire epoch and saves in animal_direct folders. For use in further
%analyses ie coherograms. Prevents the need to recalculate coherence each
%time a new analysis is done. 

%----- Params -----%
animals = {'CS31','CS33','CS34','CS35'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS

dataDir = 'D:\OdorPlaceAssociation\'; %lab computer
 
%regions = {'PFC','OB';'CA1','OB';'CA1','PFC'};
regions = {'PFC','OB'};

%loop over all pairs of regions
for r = 1:size(regions,1)
    region = [regions{r,1},'-',regions{r,2}];

%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';

tetfilter = {['(strcmp($area, ''',regions{r,1},''' ))'],['(strcmp($area, ''',regions{r,2},''' ))']};

%----- Iterator -----%
   
iterator = 'tetpaireeganal_mean'; 
    
%----- Filter creation -----%
    
psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodepairs',tetfilter, 'iterator', iterator);
   
    
%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_epochCoherence',{'eeg'});
    
%----- Run analysis -----%
out_all = runfilter(out);

    

disp(['Done with ',region]);

%separate out_all files into animals and days, average over all tet pairs
%for each epoch, store in cell array. 
% for a = 1:length(animals)
%         animal = animals{a};
%         animaldata = out_all(a);
%         filename = [animal,'coherenceoutput.mat'];
%             save([animDir,'tempData\',filename],'animaldata');
% end

    for a = 1:length(animals)
        animal = animals{a};
        data = [out_all(a).output{1,1}];
        epochs = vertcat(data.epoch);

        animDir = [dataDir, animal,'Expt\',animal,'_direct\'];
        days = unique(epochs(:,1));

        for d = 1:length(days)
            day = days(d);
            dayepochs = epochs(epochs(:,1) == day,:);

            for ep = 1:size(dayepochs,1)
                epoch = dayepochs(ep,:);
                
                epochdata = data(ismember(epochs,epoch, 'rows'));
                
                coherence{1,day}{1,epoch(2)}.coherence = epochdata.meanData;
                coherence{1,day}{1,epoch(2)}.time = epochdata.params.time;
                coherence{1,day}{1,epoch(2)}.binlength = epochdata.params.binlength;
                coherence{1,day}{1,epoch(2)}.freqs = epochdata.params.freqs;
            end
            

            filename = [animal,'coherence',region,getTwoDigitNumber(day),'.mat'];
            save([animDir,filename],'coherence');

            clear('coherence')

        end
    end

end
