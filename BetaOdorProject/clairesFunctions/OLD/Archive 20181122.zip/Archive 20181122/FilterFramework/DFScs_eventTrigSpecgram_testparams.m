% 
%----- Params -----%
animals = {'CS31','CS33','CS34'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS

dataDir = 'E:\AnalysesAcrossAnimals\'; %home computer

savefile = 0;
trigtypes = {'allTriggers'};
reforgnd = 'gnd';
freqband = 'low'; %low = 0-40 Hz
eegspecfile = ['eeg',reforgnd,'spec',freqband];
win = [1 1];
tapers = [1 1];
movingwin = [500 20]/1000;

binsizestr = [num2str(movingwin(2)*1000),'ms_bins'];

winstring = [num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms'];
taperstring = ['tapers',num2str(tapers(1)),'_', num2str(tapers(2))];

region = 'OB';

%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';

switch region
    case 'PFC'
        tetfilter = '(isequal($area, ''PFC''))';
    case 'CA1'
        tetfilter = '(isequal($area, ''CA1''))';
    case 'OB'
        tetfilter = '(isequal($area, ''OB''))';
end

%----- Iterator -----%
   
iterator = 'cs_eeganal'; 
    
%----- Filter creation -----%
    
psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodes', tetfilter, 'iterator', iterator);
   
    
%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_eventTrigSpecgram_raw',{'eeg', eegspecfile, 'odorTriggers'},'trigtypes',trigtypes, 'gnd', 1, 'win', win, 'tapers',tapers, 'movingwin',movingwin);
    
%----- Run analysis -----%
out_all = runfilter(out);

    

disp('Done with all');



for t = 1:length(trigtypes)
        trigtype = trigtypes{t};
        
        newdata = [];
        for a = 1:length(animals)
            data = [out_all(a).output{1,1}.(trigtype)];
            data = cat(3, data.Smean);
            
            data = mean(data,3);
            newdata(:,:,a) = data;
        end
        
        MeanSpec = mean(newdata,3);
        eventTrigSpecgramData.(trigtype)= MeanSpec;
end

eventTrigSpecgramData.ReforGnd = reforgnd;
eventTrigSpecgramData.freqband = freqband;
eventTrigSpecgramData.trigtypes = trigtypes;
eventTrigSpecgramData.region = region;
eventTrigSpecgramData.win = win;
eventTrigSpecgramData.tapers = tapers;
eventTrigSpecgramData.movingwin = movingwin;


region = eventTrigSpecgramData.region;
trigtypes = eventTrigSpecgramData.trigtypes;
freqband = eventTrigSpecgramData.freqband;
    if strcmp(freqband,'low')
        freqs = [1:40];
    end
RefOrGnd = eventTrigSpecgramData.ReforGnd;
win = eventTrigSpecgramData.win;
tapers = eventTrigSpecgramData.tapers;
movingwin = eventTrigSpecgramData.movingwin;

winstring = [num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms'];
taperstring = ['tapers',num2str(tapers(1)),'_',num2str(tapers(2))];
binsizestr = [num2str(movingwin(2)*1000),'ms_bins'];

timewin = (win(1) - (-win(2)));
%----- Calculate Averages -----%
std = 2; 

for g = 1:length(trigtypes) %for each trigtype
    
    
    trigtype = trigtypes{g};
    
    specdata = eventTrigSpecgramData.(trigtype)';
    times = [-win(1), timewin/length(specdata), win(2)];
    
%     s = gaussian2(std,(2*std));
%     smoothedspecdata = filter2(s,(specdata)); 
    
    smwin=2;
    
   % Smoothing along freq axis 
    for i=1:size(specdata,1)
    winst = i-smwin/2; winend = i+smwin/2;
    if winst<1, winst=1; end
    if winend>size(specdata,2), winend = size(specdata,2); end
    specdata(:,i) = mean(specdata(:,winst:winend),2);
    end
% 
% % Smoothing along time axis
%     smwin=smwin*2;
%     for i=1:size(Smean,1)
%     winst = i-smwin/2; winend = i+smwin/2;
%     if winst<1, winst=1; end
%     if winend>size(Smean,1), winend = size(Smean,1); end
%     Smean(i,:) = mean(Smean(winst:winend,:),1);
    
    figure, hold on
    colormap(jet);
    imagesc(times, freqs, specdata)
    set(gca,'YDir','normal')
    colorbar
    hold on
    plot([0 0],[1 40],'k--', 'LineWidth', 1.5);
    axis([-win(1) win(2) 1 40])

%     figtitle1 = ['Spectrogram_',region,'_',trigtype,'_',RefOrGnd,'_',winstring,'_',taperstring,'_',binsizestr];
%     title(sprintf('%s%d',figtitle1), 'Interpreter', 'none'); %allows underscores in fig titles
%     
%     figdir = 'E:\Figures\Specgrams\'; %home comp
%     %figdir = 'D:\Figures\Specgrams\'; %lab comp
%     figfile = [figdir,figtitle1];
    
%     print('-djpeg', figfile);
%     print('-dpdf', figfile);
%     saveas(gcf,figfile,'fig');
%     

end

if savefile == 1
filename = ['eventTrigSpecgramData_', region,'_',winstring, '_', taperstring,'_',binsizestr, '.mat'];

save([dataDir,filename],'eventTrigSpecgramData');
end

