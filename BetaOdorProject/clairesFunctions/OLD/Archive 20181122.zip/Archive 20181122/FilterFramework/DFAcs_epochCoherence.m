function out = DFAcs_epochCoherence(index1, index2, excludeperiods, eeg, varargin)

movingwin = [1000 20]/1000; 
params.Fs = 1500;
params.err = [2 0.05];
params.fpass = [0 40];
params.tapers = [2 3]; %DO NOT GO LOWER THAN THIS- MESSES UP 

for option = 1:2:length(varargin)-1   
    if isstr(varargin{option})       
        switch(varargin{option})
            case 'fpass'
                fpass = varargin{option+1};
	    otherwise
                error(['Option ',varargin{option},' unknown.']);
        end   
    else
        error('Options must be strings, followed by the variable');
    end
end



%----- Get the eeg data and time -----%
eeg1 = eeg{index1(1)}{index1(2)}{index1(3)}.data;
time1 = [eeg{index1(1)}{index1(2)}{index1(3)}.starttime:(1/eeg{index1(1)}{index1(2)}{index1(3)}.samprate):eeg{index1(1)}{index1(2)}{index1(3)}.endtime]';
eeg2 = eeg{index2(1)}{index2(2)}{index2(3)}.data;
time2 = [eeg{index2(1)}{index2(2)}{index2(3)}.starttime:(1/eeg{index2(1)}{index2(2)}{index2(3)}.samprate):eeg{index2(1)}{index2(2)}{index2(3)}.endtime]';

        if ~all(time2 == time1)% check if time vectors are matched
              eeg2 = interp1(time2,eeg2,time1,'nearest');
        end

%----- Do the cohereogram calc -----%
disp(['Doing day', num2str(index1(1)), ' epoch', num2str(index1(2)), ' tets ',num2str(index1(3)), '/', num2str(index2(3))]);
[Coh,Phi,~,~,~,t,freq] = cohgramc(eeg1,eeg2,movingwin,params); 
Coh = Coh';
t = t + time1(1); %add to starttime

out.epochCoherence = Coh;
out.index = [index1,index2(3)];
out.binlength = t(2)-t(1); %length of time bins
out.freqs = freq;
out.time = t;
out.meanData = [];
out.epoch = [];
out.params = [];