
%----- Params -----%
animals = {'CS35'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS

dataDir = 'D:\OdorPlaceAssociation\AnalysesAcrossAnimals\'; %lab computer

trigtypes = {'allTriggers'};
freqband = 'beta';
window = [2 2]; winstring = [num2str(-window(1)*1000),'-',num2str(window(2)*1000),'ms'];

 
regions = {'PFC','OB';'CA1','OB';'CA1','PFC'};


%Triggers = 'stemTimes';
Triggers = 'odorTriggers';
 if strcmp(Triggers,'odorTriggers')
     trigstr = '';
 else
     trigstr = [Triggers,'_'];
 end
 
filenameparams = [trigstr,'_',freqband,'_', winstring,'.mat'];


%loop over all pairs of regions
for r = 1:length(regions)
    region = [regions{r,1},'-',regions{r,2}];
%region = 'PFC-OB';

%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';

tetfilter = {['(strcmp($area, ''',regions{r,1},''' ))'],['(strcmp($area, ''',regions{r,2},''' ))']};

%----- Iterator -----%
   
iterator = 'tetpaireeganal2'; 
    
%----- Filter creation -----%
    
psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodepairs',tetfilter, 'iterator', iterator);
   
    
%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_eventcoherence',{'eeg',Triggers},'trigtypes',trigtypes,'freqband',freqband,'window',window);
    
%----- Run analysis -----%
out_all = runfilter(out);

    

disp('Done with all');

%---- Save file with params -----%
coherenceData.data = out_all;
coherenceData.animals = animals;
coherenceData.region = region;
coherenceData.trigtypes = trigtypes;
coherenceData.freqband = freqband;

filename = ['Coherence_', region,filenameparams,'.mat'];

save([dataDir,filename],'coherenceData');
%save(['E:\AnalysesAcrossAnimals\',filename],'coherenceData');

%%%% run cs_plotCoherence to plot %%%% 
%cs_plotCoherence(['E:\AnalysesAcrossAnimals\',filename])
cs_plotCoherence([dataDir,filename])
close all

end
