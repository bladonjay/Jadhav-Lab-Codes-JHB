%CS 1/23/2018 
%Creates specgram data files for each tetrode separately for plotting.
%Filters are the same as for normal specgrams, just combines data
%differently at the end. 


%----- Params -----%
animals = {'CS31','CS33','CS34'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS
%animals = {'SG7'};

%dataDir = 'E:\AnalysesAcrossAnimals\'; %home computer
dataDir = 'D:\OdorPlaceAssociation\AnalysesAcrossAnimals\'; %lab computer
%dataDir = ['D:\OdorPlaceAssociation\',animals{1},'Expt\', animals{1},'_direct\'];
%dataDir = 'D:\OdorPlaceAssociation\SG7Expt\SG7_direct\';


savefile = 1;

Triggers = 'odorTriggers';
%Triggers = 'laserTriggers';
%Triggers = 'stemTimes';
%Triggers = 'rewardTimes';
 
switch Triggers
    case 'odorTriggers'
        trigstr = '';
    case 'stemTimes'
        trigstr = '_stem';
    case 'laserTriggers'
        trigstr = '_laser';
    case 'rewardTimes'
        trigstr = '_reward';
end

trigtypes = {'allTriggers'};
reforgnd = 'gnd';
freqband = 'low'; fpass = [0 40]; %low = 0-40 Hz
%freqband = 'mid'; fpass = [0 100];
eegspecfile = ['eeg',reforgnd,'spec',freqband]; %(eg eegrefspeclow, eeggndspecmid, etc)
win = [1.5 1.5];
tapers = [1 1];
movingwin = [1000 20]/1000; 

binsizestr = [num2str(movingwin(2)*1000),'msBins'];

winstring = [num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms'];
taperstring = ['tapers',num2str(tapers(1)),'-', num2str(tapers(2))];

filenametitle = ['tetSpecgramData_'];
filenameparams = [trigstr,'_',freqband,'_',winstring,'_',taperstring,'_', binsizestr, '.mat'];

varargstr = {'trigtypes',trigtypes, 'gnd', 1, 'win', win, 'tapers',tapers, 'movingwin', movingwin,'fpass',fpass};


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

region = 'PFC';

%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';
%runepochfilter = 'isequal($environment, ''laseroff'')';

switch region
    case 'PFC'
        tetfilter = '(isequal($area, ''PFC''))';
    case 'CA1'
        tetfilter = '(isequal($area, ''CA1''))';
    case 'OB'
        tetfilter = '(isequal($area, ''OB''))';
end

%----- Iterator -----%
   
iterator = 'cs_eeganal'; 
    
%----- Filter creation -----%
    
psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodes', tetfilter, 'iterator', iterator);
   
    
%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_eventTrigSpecgram',{'eeg', eegspecfile, Triggers},varargstr);
    
%----- Run analysis -----%
out_all = runfilter(out);

    



%Combine each tetrode over epochs and save separately

for t = 1:length(trigtypes)
        trigtype = trigtypes{t};
        
        for a = 1:length(animals)
            animal = animals{a};
            data = [out_all(a).output{1,1}.(trigtype)];
            tets = out_all(a).eegdata{1, 1}{1, 1};
            tetindex = vertcat(data.index);
            
            for t = 1:length(tets)
                tet = tets(t);
                tetstr = getTwoDigitNumber(tet);
                dataIndex = find(tetindex(:,3) == tet);
                
                tetSpecgramData.(trigtype) = mean(cat(3,data(dataIndex).Smean),3);
                tetSpecgramData.tet = tet;
                
                filename = [filenametitle, animal, '_', region, '_Tet', tetstr, filenameparams];
    
                save([dataDir,'\tetSpecgrams\',filename],'tetSpecgramData');
                
            
            end
        end
        
        
end

disp(['Done with ',region]);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

region = 'CA1';

%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';
%runepochfilter = 'isequal($environment, ''laseroff'')';

switch region
    case 'PFC'
        tetfilter = '(isequal($area, ''PFC''))';
    case 'CA1'
        tetfilter = '(isequal($area, ''CA1''))';
    case 'OB'
        tetfilter = '(isequal($area, ''OB''))';
end

%----- Iterator -----%
   
iterator = 'cs_eeganal'; 
    
%----- Filter creation -----%
    
psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodes', tetfilter, 'iterator', iterator);
   
    
%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_eventTrigSpecgram',{'eeg', eegspecfile, Triggers},varargstr);
    
%----- Run analysis -----%
out_all = runfilter(out);

    



%Combine each tetrode over epochs and save separately

for t = 1:length(trigtypes)
        trigtype = trigtypes{t};
        
        for a = 1:length(animals)
            animal = animals{a};
            data = [out_all(a).output{1,1}.(trigtype)];
            tets = out_all(a).eegdata{1, 1}{1, 1};
            tetindex = vertcat(data.index);
            
            for t = 1:length(tets)
                tet = tets(t);
                tetstr = getTwoDigitNumber(tet);
                dataIndex = find(tetindex(:,3) == tet);
                
                tetSpecgramData.(trigtype) = mean(cat(3,data(dataIndex).Smean),3);
                tetSpecgramData.tet = tet;
                
                filename = [filenametitle, animal, '_', region, '_Tet', tetstr, filenameparams];
    
                save([dataDir,'\tetSpecgrams\',filename],'tetSpecgramData');
                
            
            end
        end
        
        
end


disp(['Done with ',region]);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
region = 'OB';

%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';
%runepochfilter = 'isequal($environment, ''laseroff'')';

switch region
    case 'PFC'
        tetfilter = '(isequal($area, ''PFC''))';
    case 'CA1'
        tetfilter = '(isequal($area, ''CA1''))';
    case 'OB'
        tetfilter = '(isequal($area, ''OB''))';
end

%----- Iterator -----%
   
iterator = 'cs_eeganal'; 
    
%----- Filter creation -----%
    
psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodes', tetfilter, 'iterator', iterator);
   
    
%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_eventTrigSpecgram',{'eeg', eegspecfile, Triggers},varargstr);
    
%----- Run analysis -----%
out_all = runfilter(out);

    



%Combine each tetrode over epochs and save separately

for t = 1:length(trigtypes)
        trigtype = trigtypes{t};
        
        for a = 1:length(animals)
            animal = animals{a};
            data = [out_all(a).output{1,1}.(trigtype)];
            tets = out_all(a).eegdata{1, 1}{1, 1};
            tetindex = vertcat(data.index);
            
            for t = 1:length(tets)
                tet = tets(t);
                tetstr = getTwoDigitNumber(tet);
                dataIndex = find(tetindex(:,3) == tet);
                
                tetSpecgramData.(trigtype) = mean(cat(3,data(dataIndex).Smean),3);
                tetSpecgramData.tet = tet;
                
                filename = [filenametitle, animal, '_', region, '_Tet', tetstr, filenameparams];
    
                save([dataDir,'\tetSpecgrams\',filename],'tetSpecgramData');
                
            
            end
        end
        
        
end

disp(['Done with ',region]);




disp('Done with all');
