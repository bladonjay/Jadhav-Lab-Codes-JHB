function out = DFAcs_betaPowerOdorTrigs(index, excludeperiods, beta, odorTriggers,varargin)
%This function outputs the beta power aligned to all odor trigger. Output
%is a matrix where each column is a timebin, and each row is a different
%trial. 

%------------------------------------------------------%
binsize = 0.05; % 50ms
win = [0.5 0.5]; %500ms
binning = 'bins' ;%'bins' or 'nobins'
trialtype = 'allTriggers'; %change to 'correct','incorrect','right', or 'left'
betamax = 750; %to remove high jumps in amplitude due to noise

for option = 1:2:length(varargin)-1   
    if isstr(varargin{option})       
        switch(varargin{option})
%             case 'appendindex'
%                 appendindex = varargin{option+1};
            case 'trialtype' 
                trialtype = varargin{option+1};
            case 'binning' 
                binning = varargin{option+1};
            case 'binsize'
                binsize = varargin{option+1};
            case 'win'
                win = varargin{option+1};    
            case 'betamax'
                betamax = varargin{option+1};
            
	    otherwise
                error(['Option ',varargin{option},' unknown.']);
	end   
    else
        error('Options must be strings, followed by the variable');
    end
end


odorTriggers = odorTriggers{index(1)}{index(2)}.(trialtype);

beta = beta{index(1)}{index(2)}{index(3)}; %take envelope from hilbert transform
betatime = [beta.starttime:(1/beta.samprate):beta.endtime]';
beta = [betatime, double(beta.data(:,3))];

disp(['Doing day ',num2str(index(1)), ' epoch ', num2str(index(2)), ' tetrode ', num2str(index(3)), ' ', trialtype]);

%Remove noise:
b = find(beta(:,2) >=betamax);
for i = 1:length(b)
    beta(b(i)-150:b(i)+150,2) = nan;  %finds all spots where beta power is greater than 300, replaces it and the 150 data points (100ms) before and after with nan
end

  meanEpochBeta = nanmean(beta(:,2));
  stdEpochBeta = nanstd(beta(:,2));   


switch binning
    case 'bins'
        bins = (-win(1):binsize:win(2));
        
        binnedPowerAllTrials = zeros(length(odorTriggers),length(bins)-1); %one row for each trial, one column per bin
        
        for t = 1:length(odorTriggers)
            trigtime = odorTriggers(t);
            timebins = bins + trigtime;
            betabins = zeros(1,length(bins)-1);
             for b = 1:length(bins)-1
                 bin = [timebins(b) timebins(b+1)];
                 powerinbin = mean(beta((beta(:,1)>=bin(1) & beta(:,1)<=bin(2)),2));
                 zscorebin = (powerinbin-meanEpochBeta)/stdEpochBeta;
                 betabins(b) = zscorebin;
             end
                 
            binnedPowerAllTrials(t,:) = betabins;
   
        end
        
        out = binnedPowerAllTrials;
        
        
        
    case 'nobins'
        
        powerAllTrials = zeros(length(odorTriggers),((win(1)+win(2))*1500));
        for t = 1:length(odorTriggers)
            trigtime = odorTriggers(t);
            timewin = [trigtime-win(1),trigtime+win(2)];
        
        singleTrial = beta((beta(:,1)>=timewin(1) & beta(:,1)<=timewin(2)),2); 
        zscoreSingleTrial = (singleTrial-meanEpochBeta)/stdEpochBeta;
        if length(zscoreSingleTrial) > 1500
            zscoreSingleTrial = (zscoreSingleTrial(1:1500)); %sometimes it takes too many time points? 
        end
        powerAllTrials(t,:) = zscoreSingleTrial;
%         if length(singleTrial) > 1500
%             singleTrial = (singleTrial(1:1500)); %sometimes it takes too many time points? 
%         end
%         powerAllTrials(t,:) = singleTrial;
        end
        
        out = powerAllTrials;
        
end 

