
function [ output ] = DFAcs_odorSelectivityPSTH(index, excludeperiods, spikes, odorTriggers, varargin)

% This function loops through all trials of a given type (left odor, right
% odor, etc) and identifies all spikes from a cell that occured within a
% specified time window around the odor onset time. 

%Outputs histogram data with number of spikes in each bin, spiketimes for each trial for each type, and selectivity index (-1 RIGHT to 1 LEFT).  

win = [0.5 1.0]; %default, can change with varargin
bin = .025; %for psth
FRthresh = 1;
trigtypes = {'leftTriggers','rightTriggers'}; %For consistency, always enter "left" first


for option = 1:2:length(varargin)-1   
    if isstr(varargin{option})       
        switch(varargin{option})
            case 'trigtypes' 
                trigtypes = varargin{option+1};
            case 'win'
                win = varargin{option+1}; 
            case 'binsize'
                bin = varargin{option+1};
            case 'FRthresh'
                FRthresh = varargin{option+1};
            
	    otherwise
                error(['Option ',varargin{option},' unknown.']);
        end   
    else
        error('Options must be strings, followed by the variable');
    end
end


spikes = spikes{index(1)}{index(2)}{index(3)}{index(4)}.data(:,1);

odorTriggers = odorTriggers{index(1)}{index(2)};
[correct_left, correct_right, ~, ~] = cs_getSpecificTrialTypeInds(odorTriggers);
               
odorTriggers.leftTriggers = odorTriggers.allTriggers(correct_left); %added 10/1/18, only takes correct trials.
odorTriggers.rightTriggers = odorTriggers.allTriggers(correct_right);

bins = [-win(1):bin:(win(2))];

disp(['Doing Day ',num2str(index(1)), ' Epoch ', num2str(index(2)), ' Tetrode ', num2str(index(3)), ' Cell ', num2str(index(4))]);
% ----- get spiking and psths for each trial type -----%
for g = 1:length(trigtypes)
    trigtype = trigtypes{g};
    
    triggers = odorTriggers.(trigtype);
    
    trigFR = zeros(length(triggers),1);
    psthSpikes = [];
    rawpsth = zeros(length(triggers), length(bins)-1);

    %----- loop over trials -----%
    for tr = 1:length(triggers)
        timewin = [(triggers(tr) - win(1)) (triggers(tr) + win(2))];
        spikesInWin = spikes(spikes >= timewin(1) & spikes <= timewin(2));
        
        spikesInWin = spikesInWin - triggers(tr); 
        spikesAfterTrig = spikesInWin(spikesInWin > 0);
        
        if isempty(spikesInWin)
                spikesInWin = nan;
        end
        psthSpikes = stack(psthSpikes, spikesInWin');
        
        [hist,edges] = histcounts(spikesInWin', bins);
        rawpsth(tr,:) = hist;
        
        
        
        if ~isempty(spikesAfterTrig)
            trigFR(tr) = length(spikesAfterTrig)/win(2); %calc FR using number of spikes after trigger / seconds after trigger
        else
            trigFR(tr) = 0;
        end
        
        
    
    end
triggeredSpikes.(['psth',trigtype]) = rawpsth; % the number of spikes in each time bin, for making a histogram
triggeredSpikes.(['spikes',trigtype]) = psthSpikes; % spike timings within window

meanFR = sum(trigFR)/size(rawpsth,1);
triggeredSpikes.(['FR',trigtype]) = meanFR; %mean firing rate in Hz for this cell on this type of trial
FR{1,g} = meanFR;

end

%----- Calculate selectivity Index -----$

%only keep it if either one of the firing rates is over threshold (i.e.
%don't want to count it as selectivity of 1 if it fired one spike on left
%and 0 spikes on right
if FR{1,1} > FRthresh || FR{1,2} > FRthresh 
    
    selectivityIndex = (FR{1,1} - FR{1,2})/(FR{1,1} + FR{1,2});
    triggeredSpikes.selectivityIndex = selectivityIndex;  

else
    triggeredSpikes.selectivityIndex = NaN;  
    
end

output = triggeredSpikes;
output.index = index;

end


