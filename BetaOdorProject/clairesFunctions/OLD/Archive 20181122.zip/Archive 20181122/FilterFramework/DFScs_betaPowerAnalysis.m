
%animals={'CS31','CS33','CS34'}; %CHANGE DATADIR PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS
 animals = {'CS31', 'CS33','CS34'};
    
    region = 'OB';
    ref = ''; %'Ref' or ''
    figtitle =['betaPower', ref, region];
    
    binning = 'bins';
    win = [1 1];
    binsize = 0.1;
    
    winstring = ['_',num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms'];
    %winstring = '';
    
    
    runepochfilter = 'isequal($environment, ''odorplace'')';
    
    switch region
        case 'CA1'
            tetfilter = '(strcmp($area, ''CA1''))';
        case 'PFC'
            tetfilter = '(strcmp($area, ''PFC''))';
        case 'OB'
            tetfilter = '(strcmp($area, ''OB''))';
    end
    % Iterator
    % --------
    iterator = 'cs_eeganal';
    
    % Filter creation
    % ----------------
    psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodes',tetfilter, 'iterator', iterator);
   
    
    % Set analysis function
    % ----------------------
    switch ref
        case ''
    out_all = setfilterfunction(psf, 'DFAcs_betaPowerOdorTrigs',{'beta','odorTriggers'},'trialtype','allTriggers','binning',binning,'win',win,'binsize',binsize);
    %out_incorrect = setfilterfunction(psf, 'DFAcs_betaPowerOdorTrigs',{'beta','odorTriggers'},'trialtype','incorrect','binning',binning,'win',win,'binsize',binsize);
    %out_correct = setfilterfunction(psf, 'DFAcs_betaPowerOdorTrigs',{'beta','odorTriggers'},'trialtype','correct','binning',binning,'win',win,'binsize',binsize);
        case 'Ref'
     out_all = setfilterfunction(psf, 'DFAcs_betaRefPowerOdorTrigs',{'betaRef','odorTriggers'},'trialtype','all','binning','nobins');
     %out_incorrect = setfilterfunction(psf, 'DFAcs_betaRefPowerOdorTrigs',{'betaRef','odorTriggers'},'trialtype','incorrect','binning','nobins');
     %out_correct = setfilterfunction(psf, 'DFAcs_betaRefPowerOdorTrigs',{'betaRef','odorTriggers'},'trialtype','correct','binning','nobins');
    
    end   
    %Run analysis 
    % ------------
    out_all = runfilter(out_all);
    %out_incorrect = runfilter(out_incorrect);
    %out_correct = runfilter(out_correct);
    

%------- Average over Animals ------%
allanimals_a = [];
%allanimals_i = [];
%allanimals_c = [];
    for i = 1:length(out_all)
        %meananim_a = nanmean(out_all(i).output{1,1},1);
        %allanimals_a(i,:) = [meananim_a];   
        
        %meananim_i = nanmean(out_incorrect(i).output{1,1},1);
        %allanimals_i(i,:) = [meananim_i];  
        
        %meananim_c = nanmean(out_correct(i).output{1,1},1);
        %allanimals_c(i,:) = [meananim_c]; 
        allanimals_a = [allanimals_a; out_all(i).output{1, 1}];
        %allanimals_i = [allanimals_i; out_incorrect(i).output{1, 1}];
        %allanimals_c = [allanimals_c; out_correct(i).output{1, 1}];
        
        
    end
    

%------ Plot the Data and Save------%
switch binning
    case 'nobins'

        figure,  hold on

        meanall_a = nanmean(allanimals_a,1);
        stderror_a = nanstd( allanimals_a,1) / (sqrt( size(allanimals_a,1 )));

         t = (1:length(meanall_a))/(1500); %convert back to seconds
         t = t - (max(t)/2);

        plot(t, meanall_a,'k','LineWidth',1.5)

         %patch([t fliplr(t)], [meanall_a+stderror_a fliplr(meanall_a-stderror_a)], 'k', 'FaceAlpha',.5 );

        meanall_i = nanmean(allanimals_i,1);
        stderror_i = nanstd (allanimals_i,1) / (sqrt( size(allanimals_i,1 )));
         plot(t, meanall_i,'r')
         patch([t fliplr(t)], [meanall_i+stderror_i fliplr(meanall_i-stderror_i)], 'r', 'FaceAlpha',.5 );

        meanall_c = nanmean(allanimals_c,1);
         stderror_c = nanstd (allanimals_c,1) / (sqrt( size(allanimals_c,1 )));
         plot(t, meanall_c,'g')
         patch([t fliplr(t)], [meanall_c+stderror_c fliplr(meanall_c-stderror_c)], 'g', 'FaceAlpha',.5 );

         %plot([0 0], [-1 1], 'k--', 'LineWidth', 2);
         plot([0 0], [-0.25 1.75], 'k--', 'LineWidth', 2);
         title(figtitle);
         xlabel('Time from nosepoke trigger')
         ylabel('Average z-scored beta power');

        betaPower.all = allanimals_a;
        betaPower.incorrect = allanimals_i;
        betaPower.correct = allanimals_c;
        betaPower.animals = animals;
        betaPower.region = region;


        filename =  ['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\betaPower',ref,region];
        save(filename,'betaPower');


        figdir = 'D:\Figures\EEG\';
        figfile = [figdir,figtitle];
        print('-dpdf', figfile);
        print('-djpeg', figfile);

       saveas(gcf,figfile,'fig');
   
   case 'bins'
        
        meanPowerBin_all = nanmean(allanimals_a,1)';
        semPowerBin_all = (nanstd(allanimals_a,1)/sqrt(size(allanimals_a,1)))';
%         meanPowerBin_correct = nanmean(allanimals_c,1)';
%         semPowerBin_correct = (nanstd(allanimals_c,1)/sqrt(size(allanimals_c,1)))';
%         meanPowerBin_incorrect = nanmean(allanimals_c,1)';
%         semPowerBin_incorrect = (nanstd(allanimals_i,1)/sqrt(size(allanimals_i,1)))';
        
     
%         x = [-9.5 -8.5 -7.5 -3.5 -2.5 -1.5 1.5, 2.5, 3.5 7.5, 8.5, 9.5];
%         x_a = x(1:3:end);
%         x_c = x(2:3:end);
%         x_i = x(3:3:end);
        
%         x_a = [-win(1):binsize:win(2)];
%         x_a = x_a(2:end)-(binsize/2);
%         figure,
% 
%         
%         bar(x_a,meanPowerBin_all, 'c'), hold on
% %         bar(x_c, meanPowerBin_correct, 'g', 'BarWidth', 0.15 )
% %         bar(x_i, meanPowerBin_incorrect, 'r', 'BarWidth', 0.15)
%         errorbar(x_a, meanPowerBin_all,semPowerBin_all,'LineStyle','none', 'Color','k');
% %         errorbar(x_c, meanPowerBin_correct,semPowerBin_correct,'LineStyle','none','Color','k');
% %         errorbar(x_i, meanPowerBin_incorrect,semPowerBin_incorrect,'LineStyle','none','Color','k');
%         plot([0 0], [0 .5], 'k--')
%         
%         xticks([-6.5, 0 , 6.5])
%         set(gca,'XTickLabels', [-.2 0 .2])
%         xlabel('Seconds from Odor Onset');
%         ylabel('Average Z scored beta power');
%         
%         [h_a, p_a] = ttest2(allanimals_a(:,1), allanimals_a(:,3));
% %         [h_c, p_c] = ttest2(allanimals_c(:,1), allanimals_c(:,3));
% %         [h_i, p_i] = ttest2(allanimals_i(:,1), allanimals_i(:,3));
%         
%         stats_a = [ h_a, p_a ];
% %         stats_c = [h_c, p_c];
% %         stats_i = [h_i, p_i];
%         
        betaPower.all = allanimals_a;
%         betaPower.incorrect = allanimals_i;       
%         betaPower.correct = allanimals_c;
        betaPower.animals = animals;
        betaPower.win = win;
        betaPower.binsize = binsize;
        %betaPower.stats_all = stats_a ;
%         betaPower.stats_correct = stats_c;
%         betaPower.stats_incorrect = stats_i;
        betaPower.region = region;
%         
        %filename =  ['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\betaPower',ref,region,'_binned'];
        filename = ['E:\AnalysesAcrossAnimals\betaPower',ref,region,'_binned',winstring,'.mat'];
        save(filename,'betaPower');
        
%         figtitle =['betaPower', ref, region,'_binned'];
%         title(['betaPower', ref, region])
%         %figdir = 'D:\Figures\EEG\';
%         figdir = 'E:\Figures\EEG\';
%         figfile = [figdir,figtitle];
%         print('-dpdf', figfile);
%         print('-djpeg', figfile);
% 
%         saveas(gcf,figfile,'fig');
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%animals={'CS31','CS33','CS34'}; %CHANGE DATADIR PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS
 animals = {'CS31', 'CS33','CS34'};
    
    region = 'CA1';
    
    
    
    runepochfilter = 'isequal($environment, ''odorplace'')';
    
    switch region
        case 'CA1'
            tetfilter = '(strcmp($area, ''CA1''))';
        case 'PFC'
            tetfilter = '(strcmp($area, ''PFC''))';
        case 'OB'
            tetfilter = '(strcmp($area, ''OB''))';
    end
    % Iterator
    % --------
    iterator = 'cs_eeganal';
    
    % Filter creation
    % ----------------
    psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodes',tetfilter, 'iterator', iterator);
   
    
    % Set analysis function
    % ----------------------
    switch ref
        case ''
    out_all = setfilterfunction(psf, 'DFAcs_betaPowerOdorTrigs',{'beta','odorTriggers'},'trialtype','allTriggers','binning',binning,'win',win,'binsize',binsize);
    %out_incorrect = setfilterfunction(psf, 'DFAcs_betaPowerOdorTrigs',{'beta','odorTriggers'},'trialtype','incorrect','binning',binning,'win',win,'binsize',binsize);
    %out_correct = setfilterfunction(psf, 'DFAcs_betaPowerOdorTrigs',{'beta','odorTriggers'},'trialtype','correct','binning',binning,'win',win,'binsize',binsize);
        case 'Ref'
     out_all = setfilterfunction(psf, 'DFAcs_betaRefPowerOdorTrigs',{'betaRef','odorTriggers'},'trialtype','all','binning','nobins');
     %out_incorrect = setfilterfunction(psf, 'DFAcs_betaRefPowerOdorTrigs',{'betaRef','odorTriggers'},'trialtype','incorrect','binning','nobins');
     %out_correct = setfilterfunction(psf, 'DFAcs_betaRefPowerOdorTrigs',{'betaRef','odorTriggers'},'trialtype','correct','binning','nobins');
    
    end   
    %Run analysis 
    % ------------
    out_all = runfilter(out_all);
    %out_incorrect = runfilter(out_incorrect);
    %out_correct = runfilter(out_correct);
    

%------- Average over Animals ------%
allanimals_a = [];
%allanimals_i = [];
%allanimals_c = [];
    for i = 1:length(out_all)
        %meananim_a = nanmean(out_all(i).output{1,1},1);
        %allanimals_a(i,:) = [meananim_a];   
        
        %meananim_i = nanmean(out_incorrect(i).output{1,1},1);
        %allanimals_i(i,:) = [meananim_i];  
        
        %meananim_c = nanmean(out_correct(i).output{1,1},1);
        %allanimals_c(i,:) = [meananim_c]; 
        allanimals_a = [allanimals_a; out_all(i).output{1, 1}];
        %allanimals_i = [allanimals_i; out_incorrect(i).output{1, 1}];
        %allanimals_c = [allanimals_c; out_correct(i).output{1, 1}];
        
        
    end
    

%------ Plot the Data and Save------%
switch binning
    case 'nobins'

        figure,  hold on

        meanall_a = nanmean(allanimals_a,1);
        stderror_a = nanstd( allanimals_a,1) / (sqrt( size(allanimals_a,1 )));

         t = (1:length(meanall_a))/(1500); %convert back to seconds
         t = t - (max(t)/2);

        plot(t, meanall_a,'k','LineWidth',1.5)

         %patch([t fliplr(t)], [meanall_a+stderror_a fliplr(meanall_a-stderror_a)], 'k', 'FaceAlpha',.5 );

        meanall_i = nanmean(allanimals_i,1);
        stderror_i = nanstd (allanimals_i,1) / (sqrt( size(allanimals_i,1 )));
         plot(t, meanall_i,'r')
         patch([t fliplr(t)], [meanall_i+stderror_i fliplr(meanall_i-stderror_i)], 'r', 'FaceAlpha',.5 );

        meanall_c = nanmean(allanimals_c,1);
         stderror_c = nanstd (allanimals_c,1) / (sqrt( size(allanimals_c,1 )));
         plot(t, meanall_c,'g')
         patch([t fliplr(t)], [meanall_c+stderror_c fliplr(meanall_c-stderror_c)], 'g', 'FaceAlpha',.5 );

         %plot([0 0], [-1 1], 'k--', 'LineWidth', 2);
         plot([0 0], [-0.25 1.75], 'k--', 'LineWidth', 2);
         title(figtitle);
         xlabel('Time from nosepoke trigger')
         ylabel('Average z-scored beta power');

        betaPower.all = allanimals_a;
        betaPower.incorrect = allanimals_i;
        betaPower.correct = allanimals_c;
        betaPower.animals = animals;
        betaPower.region = region;


        filename =  ['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\betaPower',ref,region];
        save(filename,'betaPower');


        figdir = 'D:\Figures\EEG\';
        figfile = [figdir,figtitle];
        print('-dpdf', figfile);
        print('-djpeg', figfile);

       saveas(gcf,figfile,'fig');
   
   case 'bins'
        
        meanPowerBin_all = nanmean(allanimals_a,1)';
        semPowerBin_all = (nanstd(allanimals_a,1)/sqrt(size(allanimals_a,1)))';
%         meanPowerBin_correct = nanmean(allanimals_c,1)';
%         semPowerBin_correct = (nanstd(allanimals_c,1)/sqrt(size(allanimals_c,1)))';
%         meanPowerBin_incorrect = nanmean(allanimals_c,1)';
%         semPowerBin_incorrect = (nanstd(allanimals_i,1)/sqrt(size(allanimals_i,1)))';
        
     
%         x = [-9.5 -8.5 -7.5 -3.5 -2.5 -1.5 1.5, 2.5, 3.5 7.5, 8.5, 9.5];
%         x_a = x(1:3:end);
%         x_c = x(2:3:end);
%         x_i = x(3:3:end);
        
%         x_a = [-win(1):binsize:win(2)];
%         x_a = x_a(2:end)-(binsize/2);
%         figure,
% 
%         
%         bar(x_a,meanPowerBin_all, 'c'), hold on
% %         bar(x_c, meanPowerBin_correct, 'g', 'BarWidth', 0.15 )
% %         bar(x_i, meanPowerBin_incorrect, 'r', 'BarWidth', 0.15)
%         errorbar(x_a, meanPowerBin_all,semPowerBin_all,'LineStyle','none', 'Color','k');
% %         errorbar(x_c, meanPowerBin_correct,semPowerBin_correct,'LineStyle','none','Color','k');
% %         errorbar(x_i, meanPowerBin_incorrect,semPowerBin_incorrect,'LineStyle','none','Color','k');
%         plot([0 0], [0 .5], 'k--')
%         
%         xticks([-6.5, 0 , 6.5])
%         set(gca,'XTickLabels', [-.2 0 .2])
%         xlabel('Seconds from Odor Onset');
%         ylabel('Average Z scored beta power');
%         
%         [h_a, p_a] = ttest2(allanimals_a(:,1), allanimals_a(:,3));
% %         [h_c, p_c] = ttest2(allanimals_c(:,1), allanimals_c(:,3));
% %         [h_i, p_i] = ttest2(allanimals_i(:,1), allanimals_i(:,3));
%         
%         stats_a = [ h_a, p_a ];
% %         stats_c = [h_c, p_c];
% %         stats_i = [h_i, p_i];
%         
        betaPower.all = allanimals_a;
%         betaPower.incorrect = allanimals_i;       
%         betaPower.correct = allanimals_c;
        betaPower.animals = animals;
        betaPower.win = win;
        betaPower.binsize = binsize;
        %betaPower.stats_all = stats_a ;
%         betaPower.stats_correct = stats_c;
%         betaPower.stats_incorrect = stats_i;
        betaPower.region = region;
%         
        %filename =  ['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\betaPower',ref,region,'_binned'];
        filename = ['E:\AnalysesAcrossAnimals\betaPower',ref,region,'_binned',winstring,'.mat'];
        save(filename,'betaPower');
        
%         figtitle =['betaPower', ref, region,'_binned'];
%         title(['betaPower', ref, region])
%         %figdir = 'D:\Figures\EEG\';
%         figdir = 'E:\Figures\EEG\';
%         figfile = [figdir,figtitle];
%         print('-dpdf', figfile);
%         print('-djpeg', figfile);
% 
%         saveas(gcf,figfile,'fig');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%animals={'CS31','CS33','CS34'}; %CHANGE DATADIR PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS
 animals = {'CS31', 'CS33','CS34'};
    
    region = 'PFC';
   
    
    runepochfilter = 'isequal($environment, ''odorplace'')';
    
    switch region
        case 'CA1'
            tetfilter = '(strcmp($area, ''CA1''))';
        case 'PFC'
            tetfilter = '(strcmp($area, ''PFC''))';
        case 'OB'
            tetfilter = '(strcmp($area, ''OB''))';
    end
    % Iterator
    % --------
    iterator = 'cs_eeganal';
    
    % Filter creation
    % ----------------
    psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodes',tetfilter, 'iterator', iterator);
   
    
    % Set analysis function
    % ----------------------
    switch ref
        case ''
    out_all = setfilterfunction(psf, 'DFAcs_betaPowerOdorTrigs',{'beta','odorTriggers'},'trialtype','allTriggers','binning',binning,'win',win,'binsize',binsize);
    %out_incorrect = setfilterfunction(psf, 'DFAcs_betaPowerOdorTrigs',{'beta','odorTriggers'},'trialtype','incorrect','binning',binning,'win',win,'binsize',binsize);
    %out_correct = setfilterfunction(psf, 'DFAcs_betaPowerOdorTrigs',{'beta','odorTriggers'},'trialtype','correct','binning',binning,'win',win,'binsize',binsize);
        case 'Ref'
     out_all = setfilterfunction(psf, 'DFAcs_betaRefPowerOdorTrigs',{'betaRef','odorTriggers'},'trialtype','all','binning','nobins');
     %out_incorrect = setfilterfunction(psf, 'DFAcs_betaRefPowerOdorTrigs',{'betaRef','odorTriggers'},'trialtype','incorrect','binning','nobins');
     %out_correct = setfilterfunction(psf, 'DFAcs_betaRefPowerOdorTrigs',{'betaRef','odorTriggers'},'trialtype','correct','binning','nobins');
    
    end   
    %Run analysis 
    % ------------
    out_all = runfilter(out_all);
    %out_incorrect = runfilter(out_incorrect);
    %out_correct = runfilter(out_correct);
    

%------- Average over Animals ------%
allanimals_a = [];
%allanimals_i = [];
%allanimals_c = [];
    for i = 1:length(out_all)
        %meananim_a = nanmean(out_all(i).output{1,1},1);
        %allanimals_a(i,:) = [meananim_a];   
        
        %meananim_i = nanmean(out_incorrect(i).output{1,1},1);
        %allanimals_i(i,:) = [meananim_i];  
        
        %meananim_c = nanmean(out_correct(i).output{1,1},1);
        %allanimals_c(i,:) = [meananim_c]; 
        allanimals_a = [allanimals_a; out_all(i).output{1, 1}];
        %allanimals_i = [allanimals_i; out_incorrect(i).output{1, 1}];
        %allanimals_c = [allanimals_c; out_correct(i).output{1, 1}];
        
        
    end
    

%------ Plot the Data and Save------%
switch binning
    case 'nobins'

        figure,  hold on

        meanall_a = nanmean(allanimals_a,1);
        stderror_a = nanstd( allanimals_a,1) / (sqrt( size(allanimals_a,1 )));

         t = (1:length(meanall_a))/(1500); %convert back to seconds
         t = t - (max(t)/2);

        plot(t, meanall_a,'k','LineWidth',1.5)

         %patch([t fliplr(t)], [meanall_a+stderror_a fliplr(meanall_a-stderror_a)], 'k', 'FaceAlpha',.5 );

        meanall_i = nanmean(allanimals_i,1);
        stderror_i = nanstd (allanimals_i,1) / (sqrt( size(allanimals_i,1 )));
         plot(t, meanall_i,'r')
         patch([t fliplr(t)], [meanall_i+stderror_i fliplr(meanall_i-stderror_i)], 'r', 'FaceAlpha',.5 );

        meanall_c = nanmean(allanimals_c,1);
         stderror_c = nanstd (allanimals_c,1) / (sqrt( size(allanimals_c,1 )));
         plot(t, meanall_c,'g')
         patch([t fliplr(t)], [meanall_c+stderror_c fliplr(meanall_c-stderror_c)], 'g', 'FaceAlpha',.5 );

         %plot([0 0], [-1 1], 'k--', 'LineWidth', 2);
         plot([0 0], [-0.25 1.75], 'k--', 'LineWidth', 2);
         title(figtitle);
         xlabel('Time from nosepoke trigger')
         ylabel('Average z-scored beta power');

        betaPower.all = allanimals_a;
        betaPower.incorrect = allanimals_i;
        betaPower.correct = allanimals_c;
        betaPower.animals = animals;
        betaPower.region = region;


        filename =  ['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\betaPower',ref,region];
        save(filename,'betaPower');


        figdir = 'D:\Figures\EEG\';
        figfile = [figdir,figtitle];
        print('-dpdf', figfile);
        print('-djpeg', figfile);

       saveas(gcf,figfile,'fig');
   
   case 'bins'
        
        meanPowerBin_all = nanmean(allanimals_a,1)';
        semPowerBin_all = (nanstd(allanimals_a,1)/sqrt(size(allanimals_a,1)))';
%         meanPowerBin_correct = nanmean(allanimals_c,1)';
%         semPowerBin_correct = (nanstd(allanimals_c,1)/sqrt(size(allanimals_c,1)))';
%         meanPowerBin_incorrect = nanmean(allanimals_c,1)';
%         semPowerBin_incorrect = (nanstd(allanimals_i,1)/sqrt(size(allanimals_i,1)))';
        
     
%         x = [-9.5 -8.5 -7.5 -3.5 -2.5 -1.5 1.5, 2.5, 3.5 7.5, 8.5, 9.5];
%         x_a = x(1:3:end);
%         x_c = x(2:3:end);
%         x_i = x(3:3:end);
        
%         x_a = [-win(1):binsize:win(2)];
%         x_a = x_a(2:end)-(binsize/2);
%         figure,
% 
%         
%         bar(x_a,meanPowerBin_all, 'c'), hold on
% %         bar(x_c, meanPowerBin_correct, 'g', 'BarWidth', 0.15 )
% %         bar(x_i, meanPowerBin_incorrect, 'r', 'BarWidth', 0.15)
%         errorbar(x_a, meanPowerBin_all,semPowerBin_all,'LineStyle','none', 'Color','k');
% %         errorbar(x_c, meanPowerBin_correct,semPowerBin_correct,'LineStyle','none','Color','k');
% %         errorbar(x_i, meanPowerBin_incorrect,semPowerBin_incorrect,'LineStyle','none','Color','k');
%         plot([0 0], [0 .5], 'k--')
%         
%         xticks([-6.5, 0 , 6.5])
%         set(gca,'XTickLabels', [-.2 0 .2])
%         xlabel('Seconds from Odor Onset');
%         ylabel('Average Z scored beta power');
%         
%         [h_a, p_a] = ttest2(allanimals_a(:,1), allanimals_a(:,3));
% %         [h_c, p_c] = ttest2(allanimals_c(:,1), allanimals_c(:,3));
% %         [h_i, p_i] = ttest2(allanimals_i(:,1), allanimals_i(:,3));
%         
%         stats_a = [ h_a, p_a ];
% %         stats_c = [h_c, p_c];
% %         stats_i = [h_i, p_i];
%         
        betaPower.all = allanimals_a;
%         betaPower.incorrect = allanimals_i;       
%         betaPower.correct = allanimals_c;
        betaPower.animals = animals;
        betaPower.win = win;
        betaPower.binsize = binsize;
        %betaPower.stats_all = stats_a ;
%         betaPower.stats_correct = stats_c;
%         betaPower.stats_incorrect = stats_i;
        betaPower.region = region;
%         
        %filename =  ['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\betaPower',ref,region,'_binned'];
        filename = ['E:\AnalysesAcrossAnimals\betaPower',ref,region,'_binned',winstring,'.mat'];
        save(filename,'betaPower');
        
%         figtitle =['betaPower', ref, region,'_binned'];
%         title(['betaPower', ref, region])
%         %figdir = 'D:\Figures\EEG\';
%         figdir = 'E:\Figures\EEG\';
%         figfile = [figdir,figtitle];
%         print('-dpdf', figfile);
%         print('-djpeg', figfile);
% 
%         saveas(gcf,figfile,'fig');
end
