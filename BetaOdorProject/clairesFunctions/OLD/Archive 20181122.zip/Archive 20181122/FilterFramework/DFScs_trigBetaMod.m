
%----- Params -----%
animals = {'CS31','CS33','CS34'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS
 
tetregion = 'OB'; 
trigtypes = {'allTriggers','correctTriggers','incorrectTriggers','leftTriggers','rightTriggers'};
win = 1; %how many seconds to look at after trigger
nbins = 30;

%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';

cellfilter = '((strcmp($area, ''CA1'') && ($numspikes > 100))  ||  (strcmp($area, ''PFC'') && ($numspikes > 100) ) )';

switch tetregion
    case 'PFC'
        tetfilter = '(isequal($descrip, ''pfcRef''))';
    case 'CA1'
        tetfilter = '(isequal($descrip, ''hpcRef''))';
    case 'OB'
        tetfilter = '(isequal($area, ''OB''))';
end

%----- Iterator -----% 

iterator = 'singlecelleeganal';
 
%----- Filter creation -----%

psf = createfilter('animal',animals,'epochs',runepochfilter,'cells',cellfilter,'eegtetrodes', tetfilter,'excludetime', [],'iterator', iterator); 

%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_trigBetaMod',{'spikes','odorTriggers','beta'},'trigtypes',trigtypes,'win',win,'nbins', nbins);

    
%----- Run analysis -----%
out_all = runfilter(out);

disp('Done with all');

%----- Combine over Epochs -----%

for a = 1:length(animals)
    alldata = [out_all(a).output{1,1}];
    animal = animals{a};
    
    for t = 1:length(trigtypes)
        trigtype = trigtypes{t};
        data = [alldata.(trigtype)];
        
        cellindex = vertcat(data.index);
        cellindexnoepochs = cellindex(:,[1,3,4]);
    
        uniquecells = unique((cellindexnoepochs),'rows');
    
    
        for c = 1:length(uniquecells)
            cell = uniquecells(c,:);
            cellstocombine = data(ismember(cellindexnoepochs,cell, 'rows'));
                
                newdata(c).animal = animal;
                newdata(c).index = cell;
                newdata(c).spikephase = vertcat(cellstocombine.spikephase);
                newdata(c).Nspikes = sum([cellstocombine.Nspikes]);
                
                %----- Do stats on combined data -----%
                if ~isempty(newdata(c).spikephase)
                    spikephase = newdata(c).spikephase;
                  % Rayleigh and Modulation: Originally in lorenlab Functions folder
                    stats = rayleigh_test(spikephase); % stats.p and stats.Z, and stats.n
                    [mod, ph] = modulation(spikephase);
                    phdeg = ph*(180/pi); %convert to degrees 
                 % Von Mises Distribution - From Circular Stats toolbox
                    [betahat, kappa] = circ_vmpar(spikephase); % Better to give raw data. Can also give binned data.
                    betahat_deg = betahat*(180/pi);
                    [prayl, zrayl] = circ_rtest(spikephase); % Rayleigh test for non-uniformity of circular data

                % Make finer polar plot and overlay Von Mises Distribution Fit.
                % Circ Stats Box Von Mises pdf uses a default of 100 angles/nbin
                % ------------------------------------------------------------
                    %nbins = 30;
                    bins = -pi:(2*pi/nbins):pi;
                    count = histc(spikephase, bins);

                    alpha = linspace(-pi, pi, nbins)';
                    [pdf] = circ_vmpdf(alpha,betahat,kappa); %von mises phase distribution function? 


                    newdata(c).stats = stats;
                    newdata(c).modulation = mod;
                    newdata(c).phdeg = phdeg;
                    newdata(c).kappa = kappa;
                    newdata(c).betahat = betahat;
                    newdata(c).betahat_deg = betahat_deg;
                    newdata(c).prayl = prayl;
                    newdata(c).zrayl = zrayl;
                    newdata(c).alpha = alpha;
                    newdata(c).vmpdf = pdf;

         
                  else
                    newdata(c).spikephase = [];
                    newdata(c).stats = [];
                    newdata(c).modulation = 0;
                    newdata(c).phdeg = 0;
                    newdata(c).kappa = 0;
                    newdata(c).betahat = 0;
                    newdata(c).betahat_deg = 0;
                    newdata(c).prayl = 0;
                    newdata(c).zrayl = 0;
                    newdata(c).alpha = [];
                    newdata(c).vmpdf = [];

                end
        end
        
        alldata_new(a).(trigtype) = newdata;
    
        clear newdata
    end
end

%----- combine over animals -----%
for t = 1:length(trigtypes)
    trigtype = trigtypes{t};
    
    d = [alldata_new.(trigtype)];
    
    betaMod.(trigtype) = d(find(vertcat(d.modulation))); %get rid of zeros (cells didn't spike enough)
    
end

    

%---- Save file with params -----%
betaMod.animals = animals;
betaMod.betaregion = tetregion;
betaMod.trigtypes = trigtypes;
betaMod.win = win;
betaMod.nbins = nbins;

filename = ['betaMod_', tetregion, '.mat'];

%save(['E:\AnalysesAcrossAnimals\',filename],'betaMod'); %home computer
%save(['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\',filename],'betaMod'); %lab computer
save(['F:\Data\OdorPlaceAssociation\AnalysesAcrossAnimals\',filename],'betaMod');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%----- Params -----%
animals = {'CS31','CS33','CS34'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS
 
tetregion = 'CA1'; 


%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';

cellfilter = '((strcmp($area, ''CA1'') && ($numspikes > 100))  ||  (strcmp($area, ''PFC'') && ($numspikes > 100) ) )';

switch tetregion
    case 'PFC'
        tetfilter = '(isequal($descrip, ''pfcRef''))';
    case 'CA1'
        tetfilter = '(isequal($descrip, ''hpcRef''))';
    case 'OB'
        tetfilter = '(isequal($area, ''OB''))';
end

%----- Iterator -----% 

iterator = 'singlecelleeganal';
 
%----- Filter creation -----%

psf = createfilter('animal',animals,'epochs',runepochfilter,'cells',cellfilter,'eegtetrodes', tetfilter,'excludetime', [],'iterator', iterator); 

%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_trigBetaMod',{'spikes','odorTriggers','beta'},'trigtypes',trigtypes,'win',win,'nbins', nbins);

    
%----- Run analysis -----%
out_all = runfilter(out);

disp('Done with all');

%----- Combine over Epochs -----%

for a = 1:length(animals)
    alldata = [out_all(a).output{1,1}];
    animal = animals{a};
    
    for t = 1:length(trigtypes)
        trigtype = trigtypes{t};
        data = [alldata.(trigtype)];
        
        cellindex = vertcat(data.index);
        cellindexnoepochs = cellindex(:,[1,3,4]);
    
        uniquecells = unique((cellindexnoepochs),'rows');
    
    
        for c = 1:length(uniquecells)
            cell = uniquecells(c,:);
            cellstocombine = data(ismember(cellindexnoepochs,cell, 'rows'));
                
                newdata(c).animal = animal;
                newdata(c).index = cell;
                newdata(c).spikephase = vertcat(cellstocombine.spikephase);
                newdata(c).Nspikes = sum([cellstocombine.Nspikes]);
                
                %----- Do stats on combined data -----%
                if ~isempty(newdata(c).spikephase)
                    spikephase = newdata(c).spikephase;
                  % Rayleigh and Modulation: Originally in lorenlab Functions folder
                    stats = rayleigh_test(spikephase); % stats.p and stats.Z, and stats.n
                    [mod, ph] = modulation(spikephase);
                    phdeg = ph*(180/pi); %convert to degrees 
                 % Von Mises Distribution - From Circular Stats toolbox
                    [betahat, kappa] = circ_vmpar(spikephase); % Better to give raw data. Can also give binned data.
                    betahat_deg = betahat*(180/pi);
                    [prayl, zrayl] = circ_rtest(spikephase); % Rayleigh test for non-uniformity of circular data

                % Make finer polar plot and overlay Von Mises Distribution Fit.
                % Circ Stats Box Von Mises pdf uses a default of 100 angles/nbin
                % ------------------------------------------------------------
                    %nbins = 30;
                    bins = -pi:(2*pi/nbins):pi;
                    count = histc(spikephase, bins);

                    alpha = linspace(-pi, pi, nbins)';
                    [pdf] = circ_vmpdf(alpha,betahat,kappa); %von mises phase distribution function? 


                    newdata(c).stats = stats;
                    newdata(c).modulation = mod;
                    newdata(c).phdeg = phdeg;
                    newdata(c).kappa = kappa;
                    newdata(c).betahat = betahat;
                    newdata(c).betahat_deg = betahat_deg;
                    newdata(c).prayl = prayl;
                    newdata(c).zrayl = zrayl;
                    newdata(c).alpha = alpha;
                    newdata(c).vmpdf = pdf;

         
                  else
                    newdata(c).spikephase = [];
                    newdata(c).stats = [];
                    newdata(c).modulation = 0;
                    newdata(c).phdeg = 0;
                    newdata(c).kappa = 0;
                    newdata(c).betahat = 0;
                    newdata(c).betahat_deg = 0;
                    newdata(c).prayl = 0;
                    newdata(c).zrayl = 0;
                    newdata(c).alpha = [];
                    newdata(c).vmpdf = [];

                end
        end
        
        alldata_new(a).(trigtype) = newdata;
    
        clear newdata
    end
end

%----- combine over animals -----%
for t = 1:length(trigtypes)
    trigtype = trigtypes{t};
    
    d = [alldata_new.(trigtype)];
    
    betaMod.(trigtype) = d(find(vertcat(d.modulation))); %get rid of zeros (cells didn't spike enough)
    
end

    

%---- Save file with params -----%
betaMod.animals = animals;
betaMod.betaregion = tetregion;
betaMod.trigtypes = trigtypes;
betaMod.win = win;
betaMod.nbins = nbins;

filename = ['betaMod_', tetregion, '.mat'];

%save(['E:\AnalysesAcrossAnimals\',filename],'betaMod'); %home computer
%save(['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\',filename],'betaMod'); %lab computer
save(['F:\Data\OdorPlaceAssociation\AnalysesAcrossAnimals\',filename],'betaMod');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%----- Params -----%
animals = {'CS31','CS33','CS34'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS
 
tetregion = 'PFC'; 

%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';

cellfilter = '((strcmp($area, ''CA1'') && ($numspikes > 100))  ||  (strcmp($area, ''PFC'') && ($numspikes > 100) ) )';

switch tetregion
    case 'PFC'
        tetfilter = '(isequal($descrip, ''pfcRef''))';
    case 'CA1'
        tetfilter = '(isequal($descrip, ''hpcRef''))';
    case 'OB'
        tetfilter = '(isequal($area, ''OB''))';
end

%----- Iterator -----% 

iterator = 'singlecelleeganal';
 
%----- Filter creation -----%

psf = createfilter('animal',animals,'epochs',runepochfilter,'cells',cellfilter,'eegtetrodes', tetfilter,'excludetime', [],'iterator', iterator); 

%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_trigBetaMod',{'spikes','odorTriggers','beta'},'trigtypes',trigtypes,'win',win,'nbins', nbins);

    
%----- Run analysis -----%
out_all = runfilter(out);

disp('Done with all');

%----- Combine over Epochs -----%

for a = 1:length(animals)
    alldata = [out_all(a).output{1,1}];
    animal = animals{a};
    
    for t = 1:length(trigtypes)
        trigtype = trigtypes{t};
        data = [alldata.(trigtype)];
        
        cellindex = vertcat(data.index);
        cellindexnoepochs = cellindex(:,[1,3,4]);
    
        uniquecells = unique((cellindexnoepochs),'rows');
    
    
        for c = 1:length(uniquecells)
            cell = uniquecells(c,:);
            cellstocombine = data(ismember(cellindexnoepochs,cell, 'rows'));
                
                newdata(c).animal = animal;
                newdata(c).index = cell;
                newdata(c).spikephase = vertcat(cellstocombine.spikephase);
                newdata(c).Nspikes = sum([cellstocombine.Nspikes]);
                
                %----- Do stats on combined data -----%
                if ~isempty(newdata(c).spikephase)
                    spikephase = newdata(c).spikephase;
                  % Rayleigh and Modulation: Originally in lorenlab Functions folder
                    stats = rayleigh_test(spikephase); % stats.p and stats.Z, and stats.n
                    [mod, ph] = modulation(spikephase);
                    phdeg = ph*(180/pi); %convert to degrees 
                 % Von Mises Distribution - From Circular Stats toolbox
                    [betahat, kappa] = circ_vmpar(spikephase); % Better to give raw data. Can also give binned data.
                    betahat_deg = betahat*(180/pi);
                    [prayl, zrayl] = circ_rtest(spikephase); % Rayleigh test for non-uniformity of circular data

                % Make finer polar plot and overlay Von Mises Distribution Fit.
                % Circ Stats Box Von Mises pdf uses a default of 100 angles/nbin
                % ------------------------------------------------------------
                    %nbins = 30;
                    bins = -pi:(2*pi/nbins):pi;
                    count = histc(spikephase, bins);

                    alpha = linspace(-pi, pi, nbins)';
                    [pdf] = circ_vmpdf(alpha,betahat,kappa); %von mises phase distribution function? 


                    newdata(c).stats = stats;
                    newdata(c).modulation = mod;
                    newdata(c).phdeg = phdeg;
                    newdata(c).kappa = kappa;
                    newdata(c).betahat = betahat;
                    newdata(c).betahat_deg = betahat_deg;
                    newdata(c).prayl = prayl;
                    newdata(c).zrayl = zrayl;
                    newdata(c).alpha = alpha;
                    newdata(c).vmpdf = pdf;

         
                  else
                    newdata(c).spikephase = [];
                    newdata(c).stats = [];
                    newdata(c).modulation = 0;
                    newdata(c).phdeg = 0;
                    newdata(c).kappa = 0;
                    newdata(c).betahat = 0;
                    newdata(c).betahat_deg = 0;
                    newdata(c).prayl = 0;
                    newdata(c).zrayl = 0;
                    newdata(c).alpha = [];
                    newdata(c).vmpdf = [];

                end
        end
        
        alldata_new(a).(trigtype) = newdata;
    
        clear newdata
    end
end

%----- combine over animals -----%
for t = 1:length(trigtypes)
    trigtype = trigtypes{t};
    
    d = [alldata_new.(trigtype)];
    
    betaMod.(trigtype) = d(find(vertcat(d.modulation))); %get rid of zeros (cells didn't spike enough)
    
end

    

%---- Save file with params -----%
betaMod.animals = animals;
betaMod.betaregion = tetregion;
betaMod.trigtypes = trigtypes;
betaMod.win = win;
betaMod.nbins = nbins;

filename = ['betaMod_', tetregion, '.mat'];

%save(['E:\AnalysesAcrossAnimals\',filename],'betaMod'); %home computer
%save(['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\',filename],'betaMod'); %lab computer
save(['F:\Data\OdorPlaceAssociation\AnalysesAcrossAnimals\',filename],'betaMod');



 
 