function out = DFAcs_betaRefPowerOdorTrigs(index, excludeperiods, betaRef, odorTriggers,varargin)
%EEG band power around triggers
%load beta file
%load odor triggers file
%inputs:dataDir, prefix, frequency, days, epochs, tetrodes
% dataDir = 'D:\OdorPlaceAssociation\CS34Expt\CS34_direct\';
% prefix = 'CS34';
% freq = 'beta';
% day = 1; epoch = 2; tetrode = 30;
% daystr = getTwoDigitNumber(day); epstr = getTwoDigitNumber(epoch); tetstr = getTwoDigitNumber(tetrode);

%------------------------------------------------------%
binsize = 0.05; % 50ms
winsize = 0.5; %500ms
binning = 'bins' ;%'bins' or 'nobins'
trialtype = 'all'; %change to 'correct','incorrect','right', or 'left'
betamax = 750; %to remove high jumps in amplitude due to noise

for option = 1:2:length(varargin)-1   
    if isstr(varargin{option})       
        switch(varargin{option})
%             case 'appendindex'
%                 appendindex = varargin{option+1};
            case 'trialtype' 
                trialtype = varargin{option+1};
            case 'binning' 
                binning = varargin{option+1};
            case 'binsize'
                binsize = varargin{option+1};
            case 'winsize'
                winsize = varargin{option+1};    
            case 'betamax'
                betamax = varargin{option+1};
            
	    otherwise
                error(['Option ',varargin{option},' unknown.']);
	end   
    else
        error('Options must be strings, followed by the variable');
    end
end



switch trialtype
    case 'all' 
        odorTriggers = odorTriggers{index(1)}{index(2)}.allTriggers;
    case 'correct'
        odorTriggers = odorTriggers{index(1)}{index(2)}.correctTriggers;
    case 'incorrect'
        odorTriggers = odorTriggers{index(1)}{index(2)}.incorrectTriggers;
    case 'left'
        odorTriggers = odorTriggers{index(1)}{index(2)}.leftTriggers;
    case 'right'
        odorTriggers = odorTriggers{index(1)}{index(2)}.rightTriggers;
end

betaRef = betaRef{index(1)}{index(2)}{index(3)}; %take envelope from hilbert transform
betatime = [betaRef.starttime:(1/betaRef.samprate):betaRef.endtime]';
betaRef = [betatime, double(betaRef.data(:,3))];


%Remove noise:
b = find(betaRef(:,2) >=betamax);
for i = 1:length(b)
    betaRef(b(i)-150:b(i)+150,2) = nan;  %finds all spots where beta power is greater than 300, replaces it and the 150 data points (100ms) before and after with nan
end

  meanEpochBeta = nanmean(betaRef(:,2));
  stdEpochBeta = nanstd(betaRef(:,2));   


switch binning
    case 'bins'
        
        
        bins = [-winsize:binsize:winsize];
        binnedPowerAllTrials = zeros(length(odorTriggers),length(bins)-1); %one row for each trial, one column per bin
        
        
        
        for t = 1:length(odorTriggers)
        trigtime = odorTriggers(t);
        
        %Binned averages
        bins = [trigtime-winsize:binsize:trigtime+winsize];

            for b = 1:length(bins)-1
                binstart = bins(b); binend = bins(b+1);
                
                meanPowerinBin = mean(betaRef((betaRef(:,1)>=binstart & betaRef(:,1)<=binend),2));
                zscorePowerBin = (meanPowerinBin - meanEpochBeta)/stdEpochBeta;
                
                binnedPowerAllTrials(t,b) = zscorePowerBin;
                
                
            end
            
        end
        
        
        out = zscorePowerAllTrials;
        
        
        
    case 'nobins'
        
        powerAllTrials = zeros(length(odorTriggers),(2*(winsize)*1500));
        for t = 1:length(odorTriggers)
            trigtime = odorTriggers(t);
            timewin = [trigtime-winsize,trigtime+winsize];
        
        singleTrial = betaRef((betaRef(:,1)>=timewin(1) & betaRef(:,1)<=timewin(2)),2); 
        zscoreSingleTrial = (singleTrial-meanEpochBeta)/stdEpochBeta;
        if length(zscoreSingleTrial) > 1500
            zscoreSingleTrial = (zscoreSingleTrial(1:1500)); %sometimes it takes too many time points? 
        end
        powerAllTrials(t,:) = zscoreSingleTrial;
%         if length(singleTrial) > 1500
%             singleTrial = (singleTrial(1:1500)); %sometimes it takes too many time points? 
%         end
%         powerAllTrials(t,:) = singleTrial;
        end
        
        out = powerAllTrials;
        
end 

%add something to save the data



    
    %both before and after
        %create average over all tets and trials, plot this as bar
        %graph/line plot with error bars (many samples)
    %both amplitude and hilbert transform
        %specify in varargin
    %both beta and betaref
        %specify in input to function
    %hpc, pfc, and ob separately
        %specify in filter
