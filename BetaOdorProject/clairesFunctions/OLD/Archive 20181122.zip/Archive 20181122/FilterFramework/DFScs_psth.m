
animals={'CS31'};
    runepochfilter = 'isequal($environment, ''odorplace'')';
    cellfilter = '((strcmp($area, ''CA1'') && ($numspikes > 100))  ||  (strcmp($area, ''PFC'') && ($numspikes > 100) ) )';
    %timefilter = { {'DFTFsj_getlinstate', '(($state ~= -1) & (abs($linearvel) >= 5))', 6} }; 
    riptetfilter = '(isequal($descrip, ''riptet''))';
    timefilter = { {'DFTFsj_getlinstate', '(($state ~= -1) & (abs($linearvel) >= 5))', 6, 'headdir',0}, {'DFTFsj_getriptimes','($nripples == 0)','tetfilter',riptetfilter,'minthresh',3} };
    %timefilter = {{'DFTFsj_getvelpos', '(($absvel >= 5))'}};
    % Iterator
    % --------
    iterator = 'singlecellanal';
    
    % Filter creation
    % ----------------
    psf = createfilter('animal',animals,'epochs',runepochfilter,'cells',cellfilter,'excludetime', timefilter,'iterator', iterator);
    % psf = createfilter('animal',animals,'days',dayfilter,'epochs',epochfilter,'cells',placecellfilter,'iterator', iterator);
    
    % Set analysis function
    % ----------------------
    %pmf_all = setfilterfunction(psf, 'DFAsj_openfieldrate_tf', {'spikes', 'linpos', 'pos', 'runTrialBounds'}, 'appendindex' ,1 , 'binsize', 1, 'std', 2);    
    pmf_left = setfilterfunction(psf, 'DFAcs_odorRasterPSTH', {'spikes', 'odorTriggers'}, 'trialtype' , 'leftTriggers', 'binsize',0.05); 
    pmf_right = setfilterfunction(psf, 'DFAcs_odorRasterPSTH', {'spikes', 'odorTriggers'}, 'trialtype' , 'rightTriggers', 'binsize', 0.05);  
   
    % Run analysis 
    % ------------
    %pmf_all = runfilter(pmf_all);  % Place Field Map
    pmf_left = runfilter(pmf_left);
    pmf_right = runfilter(pmf_right);
    
    % tetrode metadata
 hpc   = [2 3 4 17 18 19 20 27 28 29 30 31 32];
 hpcRef=  1;
 pfc   = [7 8 9 11 12 13 14 15 16 21 22 23 25 26];
 pfcRef=   10;
 ob = [24];
 %riptetlist = [1,2,3,4,5,6];
 
 %Saves data so you don't have to run filter every time
%  animalString = animals{1,1}; 
%  f = ['D:\OdorPlaceAssociation\CS31Expt\CS31_direct\',animalstring,'placeFieldData'];
%  try 
%      load(f);
%      CS31placeFieldData = pmf.output{1,1};
%  catch
%      
 %CS31placeFieldData.allTrials = pmf_all.output{1,1};
 psthraw.leftTrials = pmf_left.output{1,1};
 psthraw.rightTrials = pmf_right.output{1,1};

 f = ['D:\OdorPlaceAssociation\CS31Expt\CS31_direct\CS31psthraw'];
    %f = ['D:\MATLAB\DATA\OdorPlaceAssociation\CS31_direct\CS31psthraw']; %HOME DESKTOP
 save([f '.mat'],'psthraw');
 
 %GATHER EPOCHS
 [psthdayleft] = cs_gatherepochs(psf.animal{1,2}, psf.animal{1,1}, 'psthraw', 'leftTrials', {'rawpsth'}, {'daypsth'}, {'bins'});
 [psthdayright] = cs_gatherepochs(psf.animal{1,2}, psf.animal{1,1}, 'psthraw', 'rightTrials', {'rawpsth'}, {'daypsth'}, {'bins'});

 psth.leftTrials = psthdayleft;
 psth.rightTrials = psthdayright;
 
 fields = fieldnames(psth);
 
 binsize = (psth.leftTrials(1).bins(2) - psth.leftTrials(1).bins(1)); 
 stdev = 2;
 g = gaussian(stdev,(4*stdev));
 
 for e = 1:numel(fields)
     fieldname = fields{e,1};
     for c = 1:length(psth.(fieldname))
            psth.(fieldname)(c).avgpsth = mean(psth.(fieldname)(c).daypsth, 1);
            SEM = std(psth.(fieldname)(c).daypsth)/sqrt(size(psth.(fieldname)(c).daypsth,1)); 
            
            psth.(fieldname)(c).spikerate = psth.(fieldname)(c).avgpsth*(1/binsize);
            SEMspikerate = SEM*(1/binsize);
            
            smoothedpsth = filter2(g,psth.(fieldname)(c).spikerate);
            psth.(fieldname)(c).smoothedpsth = smoothedpsth;
            
            smoothedSEM = filter2(g,SEMspikerate);
            psth.(fieldname)(c).smoothedSEM = smoothedSEM;
            
            
     end
     
 end
 
 
 f2 = ['D:\OdorPlaceAssociation\CS31Expt\CS31_direct\CS31psth'];
 save([f2 '.mat'],'psth');
%  


leftTrials = psth.leftTrials;

rightTrials = psth.rightTrials;
bins = rightTrials(1).bins;

% 
% for c = 1:length(leftTrials)
%     if (any(leftTrials(c).smoothedpsth)) || (any(rightTrials(c).smoothedpsth)) 
%         leftpsth = leftTrials(c).smoothedpsth;
%         rightpsth = rightTrials(c).smoothedpsth;
%         index = leftTrials(c).index;
%         
%         
%         figure, hold on
%         plot(bins, leftpsth, 'r-', 'Linewidth', 3)
%         plot(bins, rightpsth, 'b-', 'Linewidth', 3)
%         plot([0 0], [0 10], 'k--', 'Linewidth', 2)
%         
%         xlabel('Time from odor onset')
%         ylabel('Number of spikes')
%         
%         title(['Day ', num2str(index(1)), ' Tetrode ', num2str(index(2)), ' Cell ', num2str(index(3))]);
%         
%     end
% end

