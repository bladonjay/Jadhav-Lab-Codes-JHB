
%----- Params -----%
animals = {'CS31','CS33','CS34','CS35'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS

dataDir = cs_setPaths();

trigtypes = {'allTriggers'};
freqband = 'beta';
window = [1 2];

%Triggers = 'stemTimes';
Triggers = 'odorTriggers';
 if strcmp(Triggers,'odorTriggers')
     trigstr = '';
 else
     trigstr = [Triggers,'_'];
 end
 
 
 

region = 'PFC-OB';

%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';

switch region
    case 'CA1-PFC'
        tetfilter = {'(strcmp($area, ''CA1'' ))','(strcmp($area, ''PFC'' ))'};
    case 'PFC-OB'
        tetfilter = {'(strcmp($area, ''PFC''))', '(strcmp($area, ''OB'' ))'};
    case 'CA1-OB'
        tetfilter = {'(strcmp($area, ''CA1'' ))','(strcmp($area, ''OB''))'};
end

%----- Iterator -----%
   
iterator = 'tetpaireeganal'; 
    
%----- Filter creation -----%
    
psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodepairs',tetfilter, 'iterator', iterator);
   
    
%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_eventcoherence',{'eeg',Triggers},'trigtypes',trigtypes,'freqband',freqband,'window',window);
    
%----- Run analysis -----%
out_all = runfilter(out);

    

disp('Done with all');

%---- Save file with params -----%
coherenceData.data = out_all;
coherenceData.animals = animals;
coherenceData.region = region;
coherenceData.trigtypes = trigtypes;
coherenceData.freqband = freqband;

filename = ['Coherence_', trigstr, region,'.mat'];

save([dataDir,filename],'coherenceData');
%save(['E:\AnalysesAcrossAnimals\',filename],'coherenceData');

%%%% run cs_plotCoherence to plot %%%% 
%cs_plotCoherence(['E:\AnalysesAcrossAnimals\',filename])
cs_plotCoherence([dataDir,filename])
close all




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%----- Params -----%
%animals = {'CS31','CS33','CS34'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS
 
region = 'CA1-PFC';


%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';

switch region
    case 'CA1-PFC'
        tetfilter = {'(strcmp($area, ''CA1'' ))','(strcmp($area, ''PFC'' ))'};
    case 'PFC-OB'
        tetfilter = {'(strcmp($area, ''PFC''))', '(strcmp($area, ''OB'' ))'};
    case 'CA1-OB'
        tetfilter = {'(strcmp($area, ''CA1'' ))','(strcmp($area, ''OB''))'};
end

%----- Iterator -----%
   
iterator = 'tetpaireeganal'; 
    
%----- Filter creation -----%
    
psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodepairs',tetfilter, 'iterator', iterator);
   
    
%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_eventcoherence',{'eeg',Triggers},'trigtypes',trigtypes,'freqband',freqband,'window',window);
    
%----- Run analysis -----%
out_all = runfilter(out);

    

disp('Done with all');

%---- Save file with params -----%
coherenceData.data = out_all;
coherenceData.animals = animals;
coherenceData.region = region;
coherenceData.trigtypes = trigtypes;
coherenceData.freqband = freqband;

filename = ['Coherence_', trigstr, region,'.mat'];


% save(['E:\AnalysesAcrossAnimals\',filename],'coherenceData');
save([dataDir,filename],'coherenceData');

%%%% run cs_plotCoherence to plot %%%% 
%cs_plotCoherence(['E:\AnalysesAcrossAnimals\',filename])
close all
 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%----- Params -----%
%animals = {'CS31','CS33','CS34'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS
 
region = 'CA1-OB';


%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';

switch region
    case 'CA1-PFC'
        tetfilter = {'(strcmp($area, ''CA1'' ))','(strcmp($area, ''PFC'' ))'};
    case 'PFC-OB'
        tetfilter = {'(strcmp($area, ''PFC''))', '(strcmp($area, ''OB'' ))'};
    case 'CA1-OB'
        tetfilter = {'(strcmp($area, ''CA1'' ))','(strcmp($area, ''OB''))'};
end

%----- Iterator -----%
   
iterator = 'tetpaireeganal'; 
    
%----- Filter creation -----%
    
psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodepairs',tetfilter, 'iterator', iterator);
   
    
%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_eventcoherence',{'eeg',Triggers},'trigtypes',trigtypes,'freqband',freqband,'window',window);
    
%----- Run analysis -----%
out_all = runfilter(out);

    

disp('Done with all');

%---- Save file with params -----%
coherenceData.data = out_all;
coherenceData.animals = animals;
coherenceData.region = region;
coherenceData.trigtypes = trigtypes;
coherenceData.freqband = freqband;

filename = ['Coherence_', trigstr, region,'.mat'];

% save(['E:\AnalysesAcrossAnimals\',filename],'coherenceData');
save([dataDir,filename],'coherenceData');

%%%% run cs_plotCoherence to plot %%%% 
%cs_plotCoherence(['E:\AnalysesAcrossAnimals\',filename])
close all



