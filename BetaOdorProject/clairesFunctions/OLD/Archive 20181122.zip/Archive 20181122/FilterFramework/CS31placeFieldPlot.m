
animalstring = 'CS31';
trialtype = 'leftTrials';
hpc   = [2 3 4 17 18 19 20 27 28 29 30 31 32];
 hpcRef=  1;
 pfc   = [7 8 9 11 12 13 14 15 16 21 22 23 25 26];
 pfcRef=   10;
 ob = [24];


file = load([animalstring 'placeFieldData.mat']);
datafield = [animalstring 'placeFieldData'];
placeFieldData = file.(datafield).(trialtype);

for i=1:length(placeFieldData)
        %sprintf('Doing cell %d',i); 
        figure;
        imagesc(flipud(placeFieldData(i).smoothedspikerate)); colormap(jet);
        ind= placeFieldData(i).index;
        if any(ind(3) == hpc); areaStr= 'hpc'; elseif any(ind(3) == pfc); areaStr= 'pfc'; elseif any(ind(3) == ctx); areaStr= 'ctx'; end;
        name= ['tetrode' num2str(ind(3)) 'cell' num2str(ind(4)) 'area' areaStr 'day' num2str(ind(1)) 'epoch' num2str(ind(2)) trialtype];
        title(name);
        figfile= ['D:\OdorPlaceAssociation\CS31Expt\CS31_direct\PlaceFields\' name];
        colorbar;
        print('-dpng', figfile, '-r300');
        %close all;
end