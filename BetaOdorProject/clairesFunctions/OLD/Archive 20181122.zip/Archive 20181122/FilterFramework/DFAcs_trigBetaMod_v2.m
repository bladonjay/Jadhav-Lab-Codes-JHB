function out = DFAcs_trigBetaMod_v2(ind, excludetimes, spikes, highBeta, betaPhase, varargin)

%only looks at periods of high beta power after odor trigger

for option = 1:2:length(varargin)-1
    if isstr(varargin{option})
        switch(varargin{option})
            case 'betaregion'
                betaregion = varargin{option+1};
            case 'trigtype'
                trigtype = varargin{option+1};
                if strcmp(trigtype,'allTriggers')
                    trigstr = '';
                else 
                    trigstr = ['_',trigtype];
                end
                
            otherwise
                error(['Option ',varargin{option},' unknown.']);
        end
    else
        error('Options must be strings, followed by the variable');
    end
end

if ~isempty(highBeta{ind(1)}{ind(2)}.(trigtype).(betaregion))
    

    spikes = spikes{ind(1)}{ind(2)}{ind(3)}{ind(4)}.data(:,1); %all spike times
    disp(['Doing day ', num2str(ind(1)), ' epoch ', num2str(ind(2)), ' tetrode ', num2str(ind(3)), ' cell ', num2str(ind(4))]);

    betaph = betaPhase{ind(1)}{ind(2)}.(betaregion)(:,2)/10000;
    betatime = betaPhase{ind(1)}{ind(2)}.(betaregion)(:,1);

    highBeta = highBeta{ind(1)}{ind(2)}.(trigtype).(betaregion);

    trigspikes = [];
    for tr = 1:size(highBeta,1)
        betawin = highBeta(tr,:);
        trigspikes = [trigspikes; spikes(spikes > betawin(1) & spikes<betawin(2))];
        %gets just the timing of each spike within trig window to compare to eeg phase

    end

    if length(trigspikes) >= 10 %should there be a FR criterion?? 
         spikephase = betaph(lookup(trigspikes, betatime)); 
    else 
         spikephase = [];
    end


     out.index = ind;
     out.betaregion = betaregion;
     out.spikephase = spikephase;
     out.Nspikes = length(trigspikes);

else
   out = [];

end







