
% Theta modulation of cells. 
% Also see sj_plotthetamod
% Gather data like DFSsj_getcellinfo and DFSsj_HPexpt_xcorrmeasures2

clear; %close all;
runscript = 1;
savedata = 1; % save data option - only works if runscript is also on
figopt1 = 1; % Figure Options - Indicidual cells
gatherdata = 1;
val = 9; %CHANGE THIS
plotfigs = [];

% savedir = 'E:\Data\OdorPlaceAssociation\CS31_direct\';
% figdir = 'E:\Figures\PhaseLocking\';

% switch val
%     case 2
%         savefile = [savedir 'CS31_lowgammamod_CA1_odortriggers']; area = 'CA1'; clr = 'b';
%         figfile = [figdir, 'CS31_lowgammamod_hpc_odortriggers'];
%     case 1 
%         savefile = [savedir 'CS31_lowgammamod_CA1_alldata']; area = 'CA1'; clr = 'b';
%     case 3
%         savefile = [savedir 'CS31_lowgammamod_PFC_alldata']; area = 'PFC'; clr = 'r';
%     case 4
%         savefile = [savedir 'CS31_lowgammamod_PFC_odortriggers']; area = 'PFC'; clr = 'r';
%     case 5
%         savefile = [savedir 'CS31_lowgammamod_PFCtoCA1_alldata']; area = 'PFCtoCA1'; clr = 'r';
%     case 6
%         savefile = [savedir 'CS31_lowgammamod_PFCtoCA1_odortriggers']; area = 'PFCtoCA1'; clr = 'r';
%         figfile = [figdir, 'CS31_lowgammamod_pfctohpc_odortriggers'];
%     case 7
%         savefile = [savedir 'CS31_lowgammamod_CA1toOB_odortriggers']; area = 'CA1toOB'; clr = 'g';
%         figfile = [figdir, 'CS31_lowgammamod_hpctoob_odortriggers'];
%     case 8
%         savefile = [savedir 'CS31_lowgammamod_PFCtoOB_odortriggers']; area = 'PFCtoOB'; clr = 'g';
%     case 9
%         savefile = [savedir 'CS31_lowgammamod_CA1toPFC_odortriggers']; area = 'CA1toPFC'; clr = 'g';
% end

%val=1; savefile = [savedir 'CS31_lowgamma_CA1_odortriggers']; area = 'CA1'; clr = 'b'; 
 
%val=2; savefile = [savedir 'HP_thetamod_CA1_alldata']; area = 'CA1';  clr = 'r';% CA1
savefig1=1;
savefig2=1;


% Plot options
plotanimidx =  []; % To pick animals for plotting
plotdays = []; % If you only load data when runscript=0 and savedata=0, then this field will supplant days


% If runscript, run Datafilter and save data
if runscript == 1
    
    %Animal selection
    %-----------------------------------------------------
    animals = {'CS31'};
    
    %Filter creation
    %-----------------------------------------------------
    
    % Epoch filter
    % -------------
    %dayfilter = '1:8'; % Shantanu - I am adding day filter to parse out epoch filter
    % Either Only do 1st w-track. 2 or 1 epochs per day
    % Or do Wtr1 and Wtr2, 2 epochs per day
    runepochfilter = 'isequal($environment, ''odorplace'')'; % used only day2 for initial CS31 analysis, must change environment for these files to look at all days together
    
    % Cell filter
    % -----------
    switch val
        case {1,2,7,9}
            cellfilter = 'strcmp($area, ''CA1'')'; % This includes all, including silent cells. Spike criterion later
        case {3,4,5,6,8}
            cellfilter = 'strcmp($area, ''PFC'')';
    end
    % For more exclusive choosing, use $tag
    % Take care of number of spikes while gathering data
    
    % Time filter
    % -----------
    %CS - CHANGE THIS
%     riptetfilter = '(isequal($descrip, ''riptet''))';
%     timefilter_theta = { {'DFTFsj_getlinstate', '(($state ~= -1) & (abs($linearvel) >= 5))', 6},...
%         {'DFTFsj_getriptimes','($nripples == 0)','tetfilter',riptetfilter,'minthresh',2} };
    % Can also use gethighthetatimes2 -
    
    % EEG Filter
    % ----------
    % Options are sametet, tetfilter, maxvar, file. kk also added "static tet"
    % I am going to use CA1Ref tetrode. Can pass along the file, or use $descrip
    switch val
        case {1,2,5,6}
            ca1reftetfilter = '(isequal($descrip, ''hpcRef''))';
        case {3,4,9}
            pfcreftetfilter = '(isequal($descrip, ''pfcRef''))';
        case {7,8}
            obtetfilter = '(isequal($area, ''OB''))';
    end
    % Both the normal and the Gnd files are the same for Ref electrode
    % theta or thetagnd. Make sure to add thetagnd to "iseeg" field
    switch val
        case {1,2,5,6}
            eegfilter = {'sj_geteegtet', 'lowgamma', 'tetfilter',ca1reftetfilter};
        case {3,4,9}
            eegfilter = {'sj_geteegtet', 'lowgamma', 'tetfilter',pfcreftetfilter};
        case 0
            eegfilter = {'sj_geteegtet', 'theta', 'tetfilter',ca1reftetfilter};
        case {7,8}
            eegfilter = {'sj_geteegtet', 'lowgamma', 'tetfilter',obtetfilter};
        
    end
    
    % Iterator
    % --------
    iterator = 'singlecelleeganal';
    
    % Filter creation
    % ----------------
    %modf = createfilter('animal',animals,'days',dayfilter,'epochs',runepochfilter, 'excludetimefilter', timefilter_theta, 'cells',...
    %    cellfilter,'eegtetrodes', eegfilter, 'iterator', iterator);
    %modf = createfilter('animal',animals,'epochs',runepochfilter, 'excludetimefilter', timefilter_theta, 'cells',...
    %    cellfilter,'eegtetrodes', eegfilter, 'iterator', iterator);
    modf = createfilter('animal',animals,'epochs',runepochfilter, 'cells',...
        cellfilter,'eegtetrodes', eegfilter, 'iterator', iterator);
    
    disp('Done Filter Creation');
    
    % Set analysis function
    % ----------------------
    switch val
        case {1,3,5}
            modf = setfilterfunction(modf,'DFAsj_plotthetamod',{'spikes','lowgamma'}); % Corresponding function is sj_plotthetamod
        case {2,4,6,7,8,9}
            modf = setfilterfunction(modf,'DFAsjcs_ploteegmod',{'spikes','lowgamma','eventtriggers'},'useodortriggers',1); % Corresponding function is sj_plotthetamod
            %modf = setfilterfunction(modf,'DFAsjcs_ploteegmod',{'spikes','lowgamma'});
    end
                
    
    %modf = setfilterfunction(modf,'DFAsj_plotthetamod',{'spikes','theta'},'nbins',36); % Options can be "threshspks" or "nbins"
    
    % Run analysis
    % ------------
    modf = runfilter(modf);
    disp('Finished running filter script');
    %--------------------- Finished Filter Function Run -------------------
    
    if savedata == 1
        clear figopt1 runscript plotdays plotanimidx savedata
        save(savefile);
    end
    
else
    
    load(savefile);
    
end % end runscript




% -------------------------  Filter Format Done -------------------------



% ----------------------------------
% Whether to gather data or to load previously gathered data
% --------------------------------------------------------------------
savegatherdata = 1;
switch val
    case 0
        gatherdatafile = [savedir 'CS31_thetamod_CA1_alldata_gather']; % PFC cells to Hipp theta
    case 1
        gatherdatafile = [savedir 'CS31_lowgammamod_CA1_alldata_gather']; % PFC cells to Hipp theta
    case 2
        gatherdatafile = [savedir 'CS31_lowgammamod_CA1_odortriggers_gather'];
    case 3
        gatherdatafile = [savedir 'CS31_lowgammamod_PFC_alldata_gather'];
    case 4
        gatherdatafile = [savedir 'CS31_lowgammamod_PFC_odortriggers_gather'];
    case 5
        gatherdatafile = [savedir 'CS31_lowgammamod_PFCtoCA1_alldata_gather'];
    case 6
        gatherdatafile = [savedir 'CS31_lowgammamod_PFCtoCA1_odortriggers_gather'];
    case 7
        gatherdatafile = [savedir 'CS31_lowgammamod_CA1toOB_odortriggers_gather'];
    case 8
        gatherdatafile = [savedir 'CS31_lowgammamod_PFCtoOB_odortriggers_gather'];
    case 9
        gatherdatafile = [savedir 'CS31_lowgammamod_CA1toPFC_odortriggers_gather'];
end


if gatherdata == 1
    
    % Parameters if any
    % -----------------
    nbins = 30;
    % Circ Stats Box Von Mises pdf uses a default of 100 angles/nbin
    % -------------------------------------------------------------
    
    cnt=0; % Count how man cells will be kept based on nspikes in output
    allanimindex=[]; alldata=[]; all_Nspk=[];
    
    
    for an = 1:length(modf)
        for i=1:length(modf(an).output{1})
            % Check for empty output
            if (modf(an).output{1}(i).Nspikes > 0)
                cnt=cnt+1;
                anim_index{an}(cnt,:) = modf(an).output{1}(i).index;
                % Only indexes
                animindex=[an modf(an).output{1}(i).index]; % Put animal index in front
                allanimindex = [allanimindex; animindex]; % Collect all Anim Day Epoch Tet Cell Index
                % Data
                alldata{cnt} = modf(an).output{1}(i).sph; % Only get spike phases. Compute evrything else after combining epochs
                all_Nspk(cnt) = modf(an).output{1}(i).Nspikes;
            end
        end
        
    end
    
    % Consolidate single cells across epochs. 2 methods: see DFSsj_getcellinfo
    % and DFSsj_xcorrmeasures2
    % Here, I will use combined animal-index. Prevents having to loop over animals
    % ----------------------------------------------------------------------------
    allthetamod = struct;
    dummyindex=allanimindex;  % all anim-day-epoch-tet-cell indices
    cntcells=0;
    
    for i=1:size(alldata,2)
        animdaytetcell=allanimindex(i,[1 2 4 5]);
        ind=[];
        while rowfind(animdaytetcell,dummyindex(:,[1 2 4 5]))~=0          % collect all rows (epochs)
            ind = [ind rowfind(animdaytetcell,dummyindex(:,[1 2 4 5]))];        % finds the first matching row
            dummyindex(rowfind(animdaytetcell,dummyindex(:,[1 2 4 5])),:)=[0 0 0 0 0]; % after adding index, remove the corresponding row
            % so you could find the next one
        end
        
        % Gather everything for the current cell across epochs
        currsph=[]; currNspk=0;
        for r=ind
            currNspk = currNspk + all_Nspk(r);
            currsph = [currsph; alldata{r}];
        end
        
        if currNspk >= 50 % based on Siapas 2005; maybe it should be 100
            cntcells = cntcells + 1;
            allthetamod_idx(cntcells,:)=animdaytetcell;
            allthetamod(cntcells).index=animdaytetcell;
            allthetamod(cntcells).sph=currsph; % Remember, this is seperated across epochs. Can take mean
            allthetamod(cntcells).Nspk=currNspk;
        end
    end
    
    
    % Calculations - can incorporate in loop above as well
    % ------------
    for i=1:cntcells
        sph = allthetamod(i).sph;
        % Rayleigh test and Modulation:
        stats = rayleigh_test(sph); % stats.p and stats.Z, and stats.n
        [m, ph] = modulation(sph);
        phdeg = ph*(180/pi);
        % Von Mises Distribution - From Circular Stats toolbox
        [thetahat, kappa] = circ_vmpar(sph); % Better to give raw data. Can also give binned data.
        thetahat_deg = thetahat*(180/pi);
        [prayl, zrayl] = circ_rtest(sph); % Rayleigh test for non-uniformity of circular data
        % Von Mises Fit - Use nbins defined above
        bins = -pi:(2*pi/nbins):pi;
        count = histc(sph, bins);
        % Make Von Mises Fit
        %alpha = linspace(-pi, pi, 50)';
        alpha = linspace(-pi, pi, nbins)';
        [pdf] = circ_vmpdf(alpha,thetahat,kappa);
        % Another way of doing mean phase
        A=mean(exp(j*sph)); % problem with i - clashes with variable. so use j.
        meancos=real(A);
        meansin=imag(A);
        meanphase=atan2(meansin,meancos); % Exactly the same as von mises fit
        
        % Save
        allthetamod(i).thetahist = count; % Theta histogram plot
        allthetamod(i).thetahistnorm = count./max(count); % Normalized - Theta histogram plot
        allthetamod(i).thetaper = (count./sum(count))*100; % Histogram in units of percentage of spikes
        allthetamod(i).stats = stats;
        allthetamod(i).modln = m;
        allthetamod(i).phdeg = phdeg;
        allthetamod(i).kappa = kappa;
        allthetamod(i).thetahat = thetahat; % From von Mises fit - use this
        allthetamod(i).thetahat_deg = thetahat_deg; % From von Mises fit - use this
        allthetamod(i).prayl = prayl;
        allthetamod(i).zrayl = zrayl;
        allthetamod(i).alpha = alpha;
        allthetamod(i).vmpdf = pdf;
        allthetamod(i).meanphase = meanphase;
        allthetamod(i).anim = allthetamod(i).index(1); allanim(i) = allthetamod(i).index(1);
        allthetamod(i).days = allthetamod(i).index(2); alldays(i) = allthetamod(i).index(2);
    end
    
    % Save
    % -----
    if savegatherdata == 1
        save(gatherdatafile);
    end
    
else % gatherdata=0
    
    load(gatherdatafile);
    
end % end gather data

%add to "super" variable
% super{reg}=modf;


% ------------------------------
% Plotting for individual cells
% ------------------------------


%figdir = '/data25/sjadhav/HPExpt/Figures/ThetaMod/Egs/';
set(0,'defaultaxesfontweight','normal'); set(0,'defaultaxeslinewidth',2);
forppr=0;
if forppr==1
    set(0,'defaultaxesfontsize',16);
    tfont = 18; % title font
    xfont = 16;
    yfont = 16;
else
    set(0,'defaultaxesfontsize',32);
    tfont = 32;
    xfont = 32;
    yfont = 32;
end

figopt1=1;
if (figopt1)
    
    for i=1:cntcells
        
        curridx = allthetamod(i).index;
%         switch curridx(1)
% %             case 1
% %                 prefix = 'HPa';
% %             case 2
% %                 prefix = 'HPb';
% %             case 3
% %                 prefix = 'HPc';
%         end
        day = curridx(2); tet = curridx(3); cell = curridx(4);
        % To control plotting
        %if curridx(1)==3 && sig_shuf==1  
        %if curridx(1)==2 && curridx(2)==2 && curridx(3)==12 && curridx(4)==1
            
            
            sph = allthetamod(i).sph;
            Nspk = allthetamod(i).Nspk;
            thetahist = allthetamod(i).thetahist; % Theta histogram plot
            thetahistnorm = allthetamod(i).thetahistnorm; % Normalized - Theta histogram plot
            thetaper = allthetamod(i).thetaper; % Histogram in units of percentage of spikes
            stats = allthetamod(i).stats;
            m = allthetamod(i).modln;
            phdeg = allthetamod(i).phdeg;
            kappa = allthetamod(i).kappa;
            thetahat_deg = allthetamod(i).thetahat_deg; % From von Mises fit - use this
            prayl = allthetamod(i).prayl;
            zrayl = allthetamod(i).zrayl;
            alpha = allthetamod(i).alpha;
            pdf = allthetamod(i).vmpdf;
            meanphase = allthetamod(i).meanphase;
            
            countper = thetaper;
            bins = -pi:(2*pi/nbins):pi;
            ph = phdeg*(pi/180);
            
            figure; hold on;
            set(gcf,'Position',[10 10 925 1000]); % Vertical figure at right edge of screen
%             set(gcf,'Position',[750 90 1145 1000]); % For 2 X 2 plot
            redimscreen_2versubplots;
            %subplot(2,2,1); hold on; % Raster
            %Cant do raster without getting data for each individual theta cycle
            
                    %subplot(3,1,1); hold on; % Hist with Nspikes
                    out = bar(bins, thetahist, 'hist'); set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
                    set(gca,'XLim',[-pi pi]); ylabel('Number of spikes');
                    set(out,'FaceColor','r'); set(out,'EdgeColor','r');
                    %pdf = pdf.*(max(count)/max(pdf));
                    % Instead of maximum - match values at a bin, maybe close to peak
                    binnum = lookup(thetahat,alpha);
                    pdf = pdf.*(count(binnum)/pdf(binnum));
                    plot(alpha,pdf,'k','LineWidth',3,'Color','k');
                    set(gca,'XTickLabels',{'-pi', '-pi/2', '0', 'pi/2', 'pi'})
            
            
            %subplot(2,1,1); hold on; % Hist with percentage of spikes
%             out = bar(bins, thetaper, 'hist'); set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
            %set(gca,'XLim',[-pi pi]); ylabel('NSpikes');
            %set(gca,'XLim',[-pi pi]); ylabel('% of Spikes');
            %set(out,'FaceColor','r'); set(out,'EdgeColor','r');
%             binnum = lookup(thetahat,alpha);
%             pdf = pdf.*(countper(binnum)/pdf(binnum));
%             plot(alpha,pdf,'k','LineWidth',3,'Color','k');
            title(sprintf('%d %d %d %d, Kappa%f, prefang%g, pval%f', curridx, kappa, thetahat_deg, prayl));
            %title(sprintf('Nspikes %d', totalspks));
            
%             subplot(2,1,2); hold on; % Polar plot
%             [t,r] = rose(sph);
%             polar(t,r,'r'); hold on;
%             % The peak phase angle
%             lims = get(gca,'XLim');
%             radius = lims(2);
%             xx = radius .* cos(ph); yy = radius .* sin(ph);
%             line([0 xx], [0 yy],'LineWidth',4,'Color','k');
%             title(sprintf('%s Day %d Tet %d Cell %d', prefix, day, tet, cell),'FontSize',tfont,'Fontweight','normal');

            
            figfile = [figdir,area,'EgThetamod_',num2str(i)];
            %keyboard;
            
        
          
        
        %print('-dpdf', figfile); print('-djpeg', figfile); saveas(gcf,figfile,'fig');
        
        
        
    end % end cntcells
    
end % end if figopt

% ------------------
% Population Figures
% ------------------

% Population Data
% ----------------------------

allsigphases = []; cntsig = 0;
allkappas = []; allsigkappas = [];
allZ = []; allsigZ = []; allm=[];
allsph =[]; allthetahist=[]; allthetahistnorm=[];

days = unique(alldays);
anim = unique(allanim);

%ncells_days = zeros(length(days),1);
%ncells_days_sig = zeros(length(days),1);

for i = 1:length(allthetamod)
    allkappas(i) = allthetamod(i).kappa;
    allZ(i) = allthetamod(i).zrayl;
    currday = allthetamod(i).days;
    %ncells_days(currday) = ncells_days(currday)+1;
    
    if (allthetamod(i).prayl < 0.05)
        cntsig = cntsig+1;
        %ncells_days_sig(currday) = ncells_days_sig(currday)+1;
        allsigphases(cntsig) = allthetamod(i).meanphase; % Can use mean phase (atan) or thetahat_deg (from von Mises distribution)
        allsigkappas(cntsig) = allthetamod(i).kappa;
        allsigZ(cntsig) = allthetamod(i).zrayl;
        allm(cntsig) = allthetamod(i).modln;
        allsph = [allsph; allthetamod(i).sph]; % All spikes pooled
        
        allthetahist(cntsig,:) = allthetamod(i).thetahist;
        allthetaper(cntsig,:) = allthetamod(i).thetaper;
        allthetahistnorm(cntsig,:) = allthetamod(i).thetahistnorm;
               
    end
end


forppr = 0; 
% If yes, everything set to redimscreen_figforppr1
% If not, everything set to redimscreen_figforppt1

%figdir = '/data25/sjadhav/HPExpt/Figures/31Oct/';
summdir = figdir;
set(0,'defaultaxesfontweight','normal'); set(0,'defaultaxeslinewidth',2);

if forppr==1
    set(0,'defaultaxesfontsize',16);
    tfont = 18; % title font
    xfont = 16;
    yfont = 16;
else
    set(0,'defaultaxesfontsize',24);
    tfont = 28;
    xfont = 24;
    yfont = 24;
end


if 1
    % 1) Histogram of mean phases
    % ----------------------------
    if any(plotfigs == 1)
    figure; hold on;
    if forppr==1, redimscreen_figforppr1; else redimscreen_figforppt1; end
    
    nbins=24; % For population plots, reduce nbins
    
    
    binsp = -pi:(2*pi/nbins):pi;
    
    N = histc(allsigphases,binsp);
    N=N(1:(end-1));
    bins_plot = binsp(1:(end-1));
    bins_plot = bins_plot + (binsp(2)-binsp(1))/2;
    h = bar([bins_plot bins_plot+2*pi],[N , N],'histc');
    set(h(1),'facecolor',clr)
    set(h(1),'edgecolor',clr)
    xlabel(['Phase'],'FontSize',xfont,'Fontweight','normal');
    ylabel(['No. of cells'],'FontSize',yfont,'Fontweight','normal');

    %title(sprintf('Mean phases of sig. locked units: %d',cntsig),'FontSize',tfont,'FontWeight','normal')
    title(sprintf('Mean phases of phase locked units: %d out of %d',cntsig,cntcells),'FontSize',tfont,'FontWeight','normal')
    axis tight
    hold on
    plot([pi,pi],[0 8],'k--','LineWidth',1.5)
    plot([-pi,-pi],[0 8],'k--','LineWidth',1.5)
    plot([3*pi,3*pi],[0 8],'k--','LineWidth',1.5)
    plot([0,0],[0 8],'k:','LineWidth',1.5)
    plot([2*pi,2*pi],[0 8],'k:','LineWidth',1.5)
    
    %set(gca, 'XTick', [-pi:pi:3*pi], 'XTickLabel',num2str([-180,0,180,0,-180]'));
    
    a = num2str([-180,0,180,0,180]'); a(3,:) = '+-pi';
    set(gca, 'XTick', [-pi:pi:3*pi], 'XTickLabel',a);
    set(gca,'XLim',[-pi 3*pi]);
    %set(gca, 'XTick', [-pi], 'XTickLabel',sprintf('%s','-pi'));
    %set(gca, 'XTick', [0], 'XTickLabel',sprintf('%s','0'));
    set(gcf,'Position',[100 100 1200 895]);

    if savefig1==1
        fig1file = [figfile,'_cells'];
        print('-depsc2', fig1file); print('-djpeg', fig1file); 
        saveas(gcf,fig1file,'fig');
    end
end

end
if 1
    % 2)plot phase histogram of aggregate spikes, sig units
     % ----------------------------------------------------
    if any(plotfigs == 2)
    norm = 1;
    nbins = 24;
    figure; hold on;
    if forppr==1, redimscreen_figforppr1; else redimscreen_figforppt1; end
    phasehist=histc(allsph,bins);
    phasehist = phasehist(1:(end-1));
    phasehist_norm = phasehist/(sum(phasehist))*100; % percentage of spikes
    bins_plot = bins(1:(end-1));
    bins_plot = bins_plot + (bins(2)-bins(1))/2;
    if norm == 1
        h = bar([bins_plot bins_plot+2*pi],[phasehist_norm; phasehist_norm],'histc');
        set(h(1),'facecolor',clr)
        set(h(1),'edgecolor',clr)
        axis tight
        %ylim([0 .1])
        set(gca,'YLim',[0 max(phasehist_norm)+0.5])
        ylabel(['Percentage of spikes'],'FontSize',yfont,'Fontweight','normal');
    else
        h = bar([bins_plot bins_plot+2*pi],[phasehist; phasehist],'histc');
        set(h(1),'facecolor',clr)
        set(h(1),'edgecolor',clr)
        axis tight
        ylim([0 max(phasehist)+1500])
        ylabel(['No. of cells'],'FontSize',yfont,'Fontweight','normal');

    end
    xlabel(['Phase'],'FontSize',xfont,'Fontweight','normal');
    title(sprintf('Phase histogram of spikes from significant units: %d out of %d',cntsig,cntcells),'FontSize',tfont,'FontWeight','normal');
    hold on
    plot([pi,pi],[0 99999],'k--','LineWidth',1.5)
    plot([-pi,-pi],[0 99999],'k--','LineWidth',1.5)
    plot([3*pi,3*pi],[0 99999],'k--','LineWidth',1.5)
    plot([0,0],[0 99999],'k:','LineWidth',1.5)
    plot([2*pi,2*pi],[0 99999],'k:','LineWidth',1.5)
    
    %set(gca, 'XTick', [-pi:pi:3*pi], 'XTickLabel',num2str([-180,0,180,0,-180]'));
    a = num2str([-180,0,180,0,180]'); a(3,:) = '+-pi';
    set(gca, 'XTick', [-pi:pi:3*pi], 'XTickLabel',a);
    set(gca,'XLim',[-pi 3*pi]);
    set(gcf,'Position',[100 100 1200 895]);
   
    if savefig2==1
        figfile = [figfile,'_spikes'];
        print('-dpdf', figfile); print('-djpeg', figfile); saveas(gcf,figfile,'fig');
    end

    end
end



if 1
   % 3) Matrix of normalized histograms aligned by peak phase 
    if any(plotfigs == 3)
    figure; hold on;
    if forppr==1, redimscreen_figforppr1; else redimscreen_figforppt1; end
   
   [sortedph, order] = sort(allsigphases,2,'descend');
   sort_histnorm = allthetahistnorm(order,:);
   sort_histper = allthetaper(order,:);
   
   smsort=[];    bins_plot = bins(1:(end-1));
   % nstd=1: gaussian of length 4. nstd = 2: gaussian of length 7, nstd=3: gaussian of length 10.
    nstd = 3; g1 = gaussian(nstd, 3*nstd+1);

   for n =1:length(order),
       curr = sort_histnorm(n,1:50); % Last bin should be skipped
       curr = smoothvect(curr,g1);
       smsort(n,:) = curr(2:end-1);
       smsort(n,:) = smsort(n,:)./max(smsort(n,:)); % Renormalize
   end
   bins_plot = bins_plot(2:end-1);
   
   imagesc(bins_plot,1:n,smsort); colorbar;
   set(gca,'XLim',[-pi pi]); set(gca,'YLim',[0 n]);
   a = num2str([-180,0,180]');
   set(gca, 'XTick', [-pi:pi:pi], 'XTickLabel',a);
   xlabel(['Phase'],'FontSize',xfont,'Fontweight','normal'); 
   ylabel(['Cell no'],'FontSize',yfont,'Fontweight','normal'); 
   title(sprintf('Phase-locked units aligned by Pref Phase: %d',cntsig),'FontSize',tfont,'FontWeight','normal');
   
   figfile = [figdir,area,'_Thetamod_MatrixAlignPrefPhase'];
   if savefig1==1,       
        print('-dpdf', figfile); print('-djpeg', figfile); saveas(gcf,figfile,'fig');
    end
    end
end


if 1
   % 4) Matrix of normalized histograms aligned by concentration parameter
   if any(plotfigs == 4)
    figure; hold on;
    if forppr==1, redimscreen_figforppr1; else redimscreen_figforppt1; end
   
   [sortedk, order] = sort(allsigkappas);
   sort_histnorm = allthetahistnorm(order,:);
   sort_histper = allthetaper(order,:);
   
   smsort=[];    bins_plot = bins(1:(end-1));
   % nstd=1: gaussian of length 4. nstd = 2: gaussian of length 7, nstd=3: gaussian of length 10.
    nstd = 3; g1 = gaussian(nstd, 3*nstd+1);

   for n =1:length(order),
       curr = sort_histnorm(n,1:50); % Last bin should be skipped
       curr = smoothvect(curr,g1);
       smsort(n,:) = curr(2:end-1);
       smsort(n,:) = smsort(n,:)./max(smsort(n,:)); % Renormalize
   end
   bins_plot = bins_plot(2:end-1);
   
   imagesc(bins_plot,1:n,smsort); colorbar;
   set(gca,'XLim',[-pi pi]); set(gca,'YLim',[0 n]);
   a = num2str([-180,0,180]');
   set(gca, 'XTick', [-pi:pi:pi], 'XTickLabel',a);
   xlabel(['Phase'],'FontSize',xfont,'Fontweight','normal'); 
   ylabel(['Cell no'],'FontSize',yfont,'Fontweight','normal'); 
   title(sprintf('Phase-locked units aligned by Conc Parm : %d',cntsig),'FontSize',tfont,'FontWeight','normal');
   
   figfile = [figdir,area,'_Thetamod_MatrixAlignModlnStrength'];
   if savefig1==1,
        
        print('-dpdf', figfile); print('-djpeg', figfile); saveas(gcf,figfile,'fig');
   end
   end
end


if 1
    % 5) Plot distribution of Kappas
    % ------------------------------------
    if any(plotfigs == 5)
    figure; hold on;
    
    if forppr==1, redimscreen_figforppr1; else redimscreen_figforppt1; end
    currbins = [0:0.2:max(allsigkappas)]
    N = histc(allsigkappas,currbins);
    h = bar(currbins,N,'histc');
    set(h(1),'facecolor',clr);
    set(h(1),'edgecolor',clr);
    xlabel(['Conc parameter (Kappa)'],'FontSize',xfont,'Fontweight','normal');
    ylabel(['No. of cells'],'FontSize',yfont,'Fontweight','normal');
    title(sprintf('Conc par (kappa) of sig. locked units: %d',cntsig),'FontSize',tfont,'FontWeight','normal')
    set(gca,'XLim',[-0.15 max(allsigkappas)+0.1])
    if savefig1==1,
        figfile = [figdir,area,'_Thetamod_KappaDistr'];
        print('-dpdf', figfile); print('-djpeg', figfile); saveas(gcf,figfile,'fig');
    end
    end
end


if 1
    % 6) Plot distribution of Rayleigh Z
    % ------------------------------------
    if any(plotfigs == 6)
    figure; hold on;
    if forppr==1, redimscreen_figforppr1; else redimscreen_figforppt1; end
    
    logZ = log(allZ);
    logsigZ = log(allsigZ);
    currbins = min(logZ):0.8:max(logZ);
    N = histc(logZ,currbins); Nsig = histc(logsigZ,currbins);
    h = bar(currbins,N,'histc');
    set(h(1),'facecolor',clr);
    set(h(1),'edgecolor',clr);
    h2 = bar(currbins,Nsig,'histc');
    set(h2(1),'facecolor','k');
    set(h2(1),'edgecolor','k');
    xlabel(['log(Rayleigh Z)'],'FontSize',xfont,'Fontweight','normal');
    ylabel(['No. of cells'],'FontSize',yfont,'Fontweight','normal');
    title(sprintf('Rayleigh Z distribution'),'FontSize',tfont,'FontWeight','normal')
    plot([1 1],[0 max(N)],'k--','LineWidth',1.5);
    %set(gca,'XLim',[-0.15 max(allsigkappas)+0.1])
    if savefig1==1,
        figfile = [figdir,area,'_Thetamod_RayleighZDistr'];
        print('-dpdf', figfile); print('-djpeg', figfile); saveas(gcf,figfile,'fig');
   end
    end
end




if 1
    % 7) plot normalized histogram sig units, SEM
     % ------------------------------------------
     if any(plotfigs == 7)
    figure; hold on;
    if forppr==1, redimscreen_figforppr1; else redimscreen_figforppt1; end
  
    phasehist_mean=mean(allthetahist,1);
    phasehist_sem=std(allthetahist,1)/sqrt(size(allthetahist,1));
    phasehist_mean = phasehist_mean(1:(end-1));
    bins_plot = bins(1:(end-1));
    bins_plot = bins_plot + (bins(2)-bins(1))/2;
    
    h = bar([bins_plot bins_plot+2*pi],[phasehist_mean phasehist_mean],'histc');
    set(h(1),'facecolor',clr)
    set(h(1),'edgecolor',clr)
    axis tight
    if strcmp(area,'PFC')
        ylim([0 90])
    else
        ylim([0 200]);
    end
    hold on
    
    % plot sem bars
    for jj=1:length(bins_plot)
        plot([bins_plot(jj),bins_plot(jj)],[phasehist_mean(jj)-phasehist_sem(jj) phasehist_mean(jj)+phasehist_sem(jj)],'k','LineWidth',1.5)
        plot([bins_plot(jj)+2*pi,bins_plot(jj)+2*pi],[phasehist_mean(jj)-phasehist_sem(jj) phasehist_mean(jj)+phasehist_sem(jj)],'k','LineWidth',1.5)
    end
    
    titlestring=sprintf('Phase hist of all spikes, sig units: %d',cntsig);
    title(titlestring,'FontSize',14,'FontWeight','bold')
    hold on
    plot([pi,pi],[0 99999],'k--','LineWidth',1.5)
    plot([-pi,-pi],[0 99999],'k--','LineWidth',1.5)
    plot([3*pi,3*pi],[0 99999],'k--','LineWidth',1.5)
    plot([0,0],[0 99999],'k:','LineWidth',1.5)
    plot([2*pi,2*pi],[0 99999],'k:','LineWidth',1.5)
    %set(gca, 'XTick', [-pi:pi:3*pi], 'XTickLabel',num2str([-180,0,180,0,-180]'));
    a = num2str([-180,0,180,0,180]'); a(3,:) = '+-pi';
    set(gca, 'XTick', [-pi:pi:3*pi], 'XTickLabel',a);
    set(gca,'XLim',[-pi 3*pi]);
    
     if savefig1==1,
        figfile = [figdir,area,'_Thetamod_PhaseHistAllSpksWithErr'];
        print('-dpdf', figfile); print('-djpeg', figfile); saveas(gcf,figfile,'fig');
     end
     end
end



if 1
    % 8) plot distribution of modulation depths
     % ------------------------------------
     if any(plotfigs == 8)
    figure; hold on;
    if forppr==1, redimscreen_figforppr1; else redimscreen_figforppt1; end

    hist(allm,10,clr);
    title(sprintf('Distribution of modulation depths, nunits: %d',cntsig))
    xlabel(['Modulation Depth'],'FontSize',xfont,'Fontweight','normal');
    ylabel(['No. of cells'],'FontSize',yfont,'Fontweight','normal');
    
    if savefig1==1,
        figfile = [figdir,area,'_Thetamod_ModlnDepthDistr'];
        print('-dpdf', figfile); print('-djpeg', figfile); saveas(gcf,figfile,'fig');
    end
     end
end



% if 1
%     % 9) No of sig phase locked cells over days: %tage and number
%      % ------------------------------------
%     figure; hold on;
%     if forppr==1, redimscreen_figforppr1; else redimscreen_figforppt1; end
% 
%     persig_days = 100*ncells_days_sig./ncells_days;
%     plot(persig_days,[clr 'o'],'MarkerSize',18,'LineWidth',2);
%     title(sprintf('No. of sig phase locked units'));
%     xlabel(['Day'],'FontSize',xfont,'Fontweight','normal');
%     ylabel(['Percentage of cells'],'FontSize',yfont,'Fontweight','normal');
%     set(gca,'YLim',[0 max(persig_days)+5]);
%     
%     if savefig1==1,
%         figfile = [figdir,area,'_Thetamod_PerSigDays'];
%         print('-dpdf', figfile); print('-djpeg', figfile); saveas(gcf,figfile,'fig');
%     end
%    
%     
%     figure; hold on;
%     if forppr==1, redimscreen_figforppr1; else redimscreen_figforppt1; end
% 
%     Nsig_days = ncells_days_sig;
%     plot(Nsig_days,[clr 'o'],'MarkerSize',18,'LineWidth',2);
%     title(sprintf('No. of sig phase locked units'));
%     xlabel(['Day'],'FontSize',xfont,'Fontweight','normal');
%     ylabel(['Number of cells'],'FontSize',yfont,'Fontweight','normal');
%     set(gca,'YLim',[0 max(Nsig_days)+2]);
% 
%     if savefig1==1,
%         figfile = [figdir,area,'_Thetamod_NSigDays'];
%         print('-dpdf', figfile); print('-djpeg', figfile); saveas(gcf,figfile,'fig');
%     end
%     
%     
% end
% 
% 
% 
% 
% 


















% 
% 
%     % plot individual phase histogram of all units
    
%     norm = 1;
%     
%     figure
%     titlestring=sprintf('%s %s phase hist of individual units // %s',animals{1},area);
%     title(titlestring,'FontSize',14,'FontWeight','bold')
%     counter=1;
%     %for k=1:length(caf.celloutput)
%     for k=1:length(modf.output{1,1})
%         if counter==81
%             counter=1;
%             figure
%             titlestring=sprintf('%s %s phase hist of individual units // %s',animals{1},area);
%             title(titlestring,'FontSize',14,'FontWeight','bold')
%         end
%         subplot(8,10,counter)
%         %bins_plot = caf.celloutput(k).bins(1:(end-1));
%         bins_plot = bins(1:(end-1));
%         bins_plot = bins_plot + (bins(2)-bins(1))/2;
%         phasehist = caf.celloutput(k).phasehist(1:(end-1));
%         phasehist_norm = phasehist/sum(phasehist);
%         if norm == 1
%             if size(phasehist_norm,1) < size(phasehist_norm,2)
%                 phasehist_norm = phasehist_norm';
%             end
%             %plot
%             h = bar([bins_plot bins_plot+2*pi],[phasehist_norm ; phasehist_norm],'histc');
%             title(num2str(caf.celloutput(k).index))
%             axis tight
%             ylim([0 .2])
%         else
%             if size(phasehist,1) < size(phasehist,2)
%                 phasehist = phasehist';
%             end
%             %plot
%             h = bar([bins_plot bins_plot+2*pi],[phasehist ; phasehist],'histc');
%             title(num2str(caf.celloutput(k).index),'FontSize',12,'FontWeight','bold')
%             axis tight
%             ylim([0 250])
%         end
%         
%         set(h(1),'facecolor',clr)
%         set(h(1),'edgecolor',clr)
%         
%         % plot guide lines
%         hold on
%         plot([pi,pi],[0 9999],'k--','LineWidth',1.5)
%         plot([-pi,-pi],[0 9999],'k--','LineWidth',1.5)
%         plot([3*pi,3*pi],[0 9999],'k--','LineWidth',1.5)
%         plot([0,0],[0 9999],'k:','LineWidth',1.5)
%         plot([2*pi,2*pi],[0 9999],'k:','LineWidth',1.5)
%         
%         counter=counter+1;
%     end
%     
% 
% 
% % 
% % % bar
% % count = histc(allspikephases, bins);
% % out = bar(bins, count, 'hist');
% % set(out,'facecolor','k')
% % title('aggregate theta modulation');
% % 
% % % lineplot
% % dischargeprob=count./sum(count);
% % plot(bins(1:(end-1)),dischargeprob(1:(end-1)),'k','LineWidth',2);
% % 
% % [m ph] = modulation(allspikephases);
% 
% 
% 



