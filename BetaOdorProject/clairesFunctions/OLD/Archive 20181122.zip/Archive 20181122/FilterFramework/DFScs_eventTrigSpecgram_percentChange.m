% 
%----- Params -----%
animals = {'CS31','CS33','CS34','CS35'};  %CHANGE _direct PATH IN 'animaldef.m' FOR DIFFERENT COMPUTERS
%animals = {'CS33'};

regions = {'PFC','CA1','OB'};
%dataDir = 'E:\AnalysesAcrossAnimals\'; %home computer
dataDir = 'D:\OdorPlaceAssociation\AnalysesAcrossAnimals\'; %lab computer
% dataDir = ['D:\OdorPlaceAssociation\',animals{1},'Expt\', animals{1},'_direct\'];
%dataDir = 'D:\OdorPlaceAssociation\SG7Expt\SG7_direct\';


savefile = 1;

Triggers = 'odorTriggers';
%Triggers = 'laserTriggers';
%Triggers = 'stemTimes';
%Triggers = 'rewardTimes';
 
switch Triggers
    case 'odorTriggers'
        trigstr = '';
    case 'stemTimes'
        trigstr = '_stem';
    case 'laserTriggers'
        trigstr = '_laser';
    case 'rewardTimes'
        trigstr = '_reward';
end

%trigtypes = {'incorrectTriggers'}; trigstr = '_incorrect';
%trigtypes = {'correctTriggers'}; trigstr = '_correct';
trigtypes = {'allTriggers'};

reforgnd = 'gnd'; refstr = '';
%reforgnd = 'ref'; refstr = 'ref_';
%freqband = 'mid'; fpass = [0 100];  movingwin = [400 20]/1000; %mid = 0-100 Hz
freqband = 'low'; fpass = [0 40]; movingwin = [1000 20]/1000;  %low = 0-40 Hz
%freqband = 'floor'; fpass = [0 10]; movingwin = [2000 20]/1000; %floor = 0-10 Hz
%eegspecfile = ['eeg',reforgnd,'spec',freqband]; %(eg eegrefspeclow, eeggndspecmid, etc)
win = [1 2];
tapers = [1 1];

binsizestr = [num2str(movingwin(2)*1000),'msBins'];

winstring = [num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms'];
taperstring = ['tapers',num2str(tapers(1)),'-', num2str(tapers(2))];

filenametitle = ['eventTrigSpecgramData_'];
filenameparams = ['_percentChange',trigstr,'_',freqband,'_', refstr, winstring,'_',taperstring,'_', binsizestr, '.mat'];

varargstr = {'trigtypes',trigtypes, 'gnd', 1, 'win', win, 'tapers',tapers, 'movingwin', movingwin,'fpass',fpass};


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for r = 1:length(regions)
    
region = regions{r};

%----- Select Data -----%
runepochfilter = 'isequal($environment, ''odorplace'')';
%runepochfilter = 'isequal($environment, ''laseroff'')';

switch region
    case 'PFC'
        tetfilter = '(isequal($area, ''PFC''))';
    case 'CA1'
        tetfilter = '(isequal($area, ''CA1''))';
    case 'OB'
        tetfilter = '(isequal($area, ''OB''))';
end

%----- Iterator -----%
   
iterator = 'cs_eeganal'; 
    
%----- Filter creation -----%
    
psf = createfilter('animal',animals,'epochs',runepochfilter,'eegtetrodes', tetfilter, 'iterator', iterator);
   
    
%----- Set analysis function -----%
    
out = setfilterfunction(psf, 'DFAcs_eventTrigSpecgram_percentChange',{'eeg', Triggers},varargstr);
    
%----- Run analysis -----%
out_all = runfilter(out);

    

disp(['Done with ',region]);



for t = 1:length(trigtypes)
        trigtype = trigtypes{t};
        
        newdata = [];
        for a = 1:length(animals)
            data = [out_all(a).output{1,1}.(trigtype)];
            data = data(find(~cellfun(@isempty,{data.Smean})));
            data = cat(3, data.Smean);
            
            data = mean(data,3);
            newdata(:,:,a) = data;
        end
        
        MeanSpec = mean(newdata,3);
        eventTrigSpecgramData.(trigtype)= MeanSpec;
end

eventTrigSpecgramData.ReforGnd = reforgnd;
eventTrigSpecgramData.freqband = freqband;
eventTrigSpecgramData.trigtypes = trigtypes;
eventTrigSpecgramData.region = region;
eventTrigSpecgramData.win = win;
eventTrigSpecgramData.tapers = tapers;
eventTrigSpecgramData.movingwin = movingwin;

if savefile == 1
filename = [filenametitle, region, filenameparams];
    
save([dataDir,filename],'eventTrigSpecgramData');
end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
