%----------------------------------------------------------------------%
%This function takes TriggeredSpiking files, which have spike times
%around odor triggers, and selectivity index for each cell. Compares the
%selectivity index to a shuffled distribution (shuffles trial labels
%left/right) to get a zscore for each cell. Can use this to determine which
%cells show significant selectivity to one odor over another

%cs_getCellSelectivity('E:\AnalysesAcrossAnimals\', 'TriggeredSpiking_CA1_-500-1000ms.mat', 1000)
%cs_getCellSelectivity('E:\AnalysesAcrossAnimals\', 'TriggeredSpiking_PFC_-500-1000ms.mat', 1000)

%Enter saveDir with trailing slash
%----------------------------------------------------------------------%

function [fractionSelective] = cs_getCellSelectivity(dataDir, triggeredSpikingFile, iterations)
%----- Load file and get params -----%
load(triggeredSpikingFile);

allanimals = triggeredSpiking.data;
region = triggeredSpiking.region;

win = triggeredSpiking.win;
binsize = triggeredSpiking.binsize;
bins = (-win(1):binsize:win(2)-binsize);
binsaftertrig = find(bins>=0);

winstr = ['_',num2str(-win(1)*1000), '-',num2str(win(2)*1000),'ms'];

%eventually all cells from all animals will go into a single data
%structure, keeps track of how many cells have been done
totalspikingcells = 0; 
totalcells = 0;

%----- Loop over animals -----%
for a = 1:length(allanimals)
    animal = triggeredSpiking.data(a).animal{1,1};
    allSpikingData = allanimals(a).output{1,1};
    allSI = [allSpikingData.selectivityIndex]';
    totalcells = totalcells + length(allSI);
    
    %only use cells that had high enough firing rates. This threshold is
    %set when generating TriggeredSpiking files in
    %DFAcs_odorSelectivityPSTH.m
    goodCellIndx = find(~isnan(allSI)); 
    
%----- Go through all cells and make a shuffled distribution for each one -----% 
    for c = 1:length(goodCellIndx)
        totalspikingcells = totalspikingcells +1;
        cellnum = goodCellIndx(c);
        
        selectivityIndex = allSpikingData(cellnum).selectivityIndex;
        cellindex = allSpikingData(cellnum).index;

        leftSpikes = allSpikingData(cellnum).psthleftTriggers(:,binsaftertrig); %only take spikes after odor trigger
            leftFRtrials = sum(leftSpikes,2)./win(2);
        rightSpikes = allSpikingData(cellnum).psthrightTriggers(:,binsaftertrig);
            rightFRtrials = sum(rightSpikes,2)./win(2);
        
            
        leftones = ones(size(leftSpikes,1),1);
        rightzeros = zeros(size(rightSpikes,1),1);
        
        indicators = [leftones;rightzeros]; %make one list of 1's and 0's to shuffle
        allTrials = [leftFRtrials; rightFRtrials];
        

%----- Do the shuffle -----%
      shuffIndexDist = zeros(iterations,1);
        for i = 1:iterations
            shuffledRL = indicators(randperm(length(indicators)));
            newLeft = mean(allTrials(shuffledRL == 1));
            newRight = mean(allTrials(shuffledRL == 0));
            
            newIndex = (newLeft - newRight)/(newLeft + newRight);
            shuffIndexDist(i) = newIndex;
        end
        
        shuffMean = mean(shuffIndexDist);
        shuffStd = std(shuffIndexDist);
        
        trueIndexZ = (selectivityIndex - shuffMean)/shuffStd;
        
        cellSelectivity(totalspikingcells).animal = animal;
        cellSelectivity(totalspikingcells).cellnum = cellnum;
        cellSelectivity(totalspikingcells).cellindex = cellindex;
        cellSelectivity(totalspikingcells).selectivityIndex = selectivityIndex;
        cellSelectivity(totalspikingcells).zscore = trueIndexZ;
        cellSelectivity(totalspikingcells).psthleftTriggers = allSpikingData(cellnum).psthleftTriggers;
        cellSelectivity(totalspikingcells).psthrightTriggers = allSpikingData(cellnum).psthrightTriggers;
        cellSelectivity(totalspikingcells).leftSpikeTimes = allSpikingData(cellnum).spikesleftTriggers;
        cellSelectivity(totalspikingcells).rightSpikeTimes = allSpikingData(cellnum).spikesrightTriggers;
        cellSelectivity(totalspikingcells).bins = bins;
    end
end



selIndxAllCells = [cellSelectivity.zscore];
selectiveCells = find(abs(selIndxAllCells) >= 2); %significant if zscore is greater than 3



fractSpiking = totalspikingcells/totalcells;
fractSpikingSelective = length(selectiveCells)/totalspikingcells;

selLeft = selIndxAllCells(selIndxAllCells >= 2);
selRight = selIndxAllCells(selIndxAllCells <= -2);

fractLeft = length(selLeft)/length(selectiveCells);
fractRight = length(selRight)/length(selectiveCells);

selectivityFractions.fractSpiking = fractSpiking;
selectivityFractions.fractSelective = fractSpikingSelective;
selectivityFractions.fractLeft = fractLeft;
selectivityFractions.fractRight = fractRight;
selectivityFractions.selectiveCells = [cellSelectivity(selectiveCells)];

save([dataDir,'selectivityFractions_',region,winstr,'.mat'],'selectivityFractions');
save([dataDir,'cellSelectivityData_',region,winstr,'.mat'],'cellSelectivity');
end
