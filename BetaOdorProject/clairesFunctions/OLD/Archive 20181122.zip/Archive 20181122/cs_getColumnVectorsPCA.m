% This script creates a structure containing the firing rate of every cell
% on each individual trial. For every trial, there will be column vectors
% with the firing rates ef every cell during every time bin. Each cell
% across all animals is given an id number. [animal#, day, tetrode, cell]

clear all

%topDir = 'E:\';
%topDir = 'D:\OdorPlaceAssociation\';
topDir = 'F:\Data\OdorPlaceAssociation\';


trigtype = 'rightTriggers';
win = [0 .6];
binsize = 0.1;
bins = [-win(1):binsize:win(2)];

animals = {'CS31','CS33','CS34'};  
region = 'PFC';

% ---- create cell filter -----%
switch region
    case 'CA1'
        cellfilter = ['((strcmp($area, ''CA1'')) && ($numspikes > 100))'];
    case 'PFC'
        cellfilter = ['((strcmp($area, ''PFC'')) && ($numspikes > 100))'];
    case 'PFC+CA1'
        cellfilter = ['((strcmp($area, ''CA1'') && ($numspikes > 100))  ||  (strcmp($area, ''PFC'') && ($numspikes > 100))'];
        
end

%load(['E:\AnalysesAcrossAnimals\TriggeredSpiking_',region,'.mat']);
%load(['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\TriggeredSpiking_',region,'.mat']);
load(['F:\Data\OdorPlaceAssociation\AnalysesAcrossAnimals\TriggeredSpiking_',region,'_-500-1000ms_50msBins.mat']);

totaltrials = 0;
for a = 1:length(animals)
    animal = animals{a};
    
    dataDir = [topDir,animal, 'Expt\',animal,'_direct\'];
    odorTrigFiles = dir([dataDir,animal,'odorTriggers*']);
    
    datafileAnimals = {triggeredSpiking.animals};
    animnum = find(strcmp(datafileAnimals{1,1}, animal));
    an = animnum;

    spikingdata = triggeredSpiking.data(an).output{1,1};
    
    cellinfo = loaddatastruct(dataDir,animal,'cellinfo');
    
    %----- do for each day that there is a trigger file for -----%
    for d = 1:length(odorTrigFiles)
        odorTrigFile = odorTrigFiles(d).name;
        load([dataDir,odorTrigFile]);
        daystr = getTwoDigitNumber(d);
        
        if exist([dataDir,animal,'spikes',daystr,'.mat'], 'file') %added this because i didn't have spikes files for all days for CS33/CS34, might cause problems in the future
            load([dataDir,animal,'spikes',daystr,'.mat']);
        
            for e = 1:length(odorTriggers{1,d})
                if ~isempty(odorTriggers{1,d}{1,e})
                    triggers = odorTriggers{1,d}{1,e}.(trigtype);
                    epoch = e;

                    disp(['Doing animal ',animal ' day ', daystr, ' epoch ', num2str(epoch)]);
                    cells = evaluatefilter(cellinfo{1,d}{1,epoch}, cellfilter);
                    
                    
                %---- loop over all trials -----%
                for t = 1:length(triggers) 
                    totaltrials = totaltrials +1;
                    trialwin = [(triggers(t) - win(1)) (triggers(t) + win(2))]; 

                    FRbins = []; 
                    
                    %----- find find the spiking for EVERY cell during that epoch -----%
                    for c = 1:length(cells)
                        cell = cells(c,:);
                        cellindex = [an d cell(1,:)]; %in this case, the index represents animal number, day, tetrode, cell. No epoch. 

                        f = find(ismember(vertcat(spikingdata.index),cellindex(2:4),'rows'));
                        if ~isnan(spikingdata(f).selectivityIndex) %only takes cells that actually spiked during interval, based on average over all trials

                            if exist('allcells','var') %create the file on the first iteration
                       
                                %----- Assign a cell id number -----%
                                if ~any(ismember(vertcat(allcells.cellindex),cellindex, 'rows'))
                                    allcells(length(allcells) +1).cellindex = cellindex;

                                    cellnum = max([allcells.cellnum])+1;
                                    allcells(length(allcells)).cellnum = cellnum;

                                else 

                                    cellnum = allcells(ismember(vertcat(allcells.cellindex),cellindex, 'rows')).cellnum;
                                end
                            else
                                allcells(1).cellindex = cellindex;
                                allcells(1).cellnum = 1;
                                cellnum = 1;
                            end
                            
                            %----- find spikes in trigger window -----%
                            cellspikes = spikes{1,d}{1,epoch}{1,cell(1)}{1,cell(2)}.data(:,1);

                            spikesInWin = cellspikes(cellspikes >= trialwin(1) & cellspikes <= trialwin(2));

                            spikesInWin = spikesInWin - triggers(t); 

                            hist = histcounts(spikesInWin, bins);
                            FRtrial = hist./binsize; %calc firing rate

                            %----- Smooth over time -----%
                            FRtrial = smooth(FRtrial)';
                            
                            FRbins = [FRbins ; FRtrial];
                            
                            
                            
                            
                        end


                    end

                    trialsAllCells(a).Animals.(['Day_',daystr])(totaltrials).FRvectorsAllCells = FRbins;
                end
                end
                totaltrials = 0;
                
            end
        end
    end
    
end




spikeColumnVectors.animals = animals;
spikeColumnVectors.data = trialsAllCells;
%spikeColumnVectors.allcellindicies = allcells;
spikeColumnVectors.win = win;
spikeColumnVectors.binsize = binsize;
spikeColumnVectors.numbins = (win(1) + win(2))/binsize;






filename = ['spikingColumnVectors_',region, '_',trigtype];

%save(['E:\AnalysesAcrossAnimals\',filename],'spikeColumnVectors');
save(['D:\OdorPlaceAssociation\AnalysesAcrossAnimals\',filename],'spikeColumnVectors')


%----- Fix -----%
%since each trial will now have a different subset of cells, especially for
%different animals, need to combine all into one big matrix with all cells
%for each trial
%NOT SURE IF THIS IS CORRECT
% for tr = 1:length(trialsAllCells)
%     trialdata = trialsAllCells(tr).FRvectorsAllCells;
%     cellsintrial = trialdata(:,1);
%     
%     allcellnum = [allcells.cellnum]';
%     
%     cellsnotintrial = allcellnum(~ismember(allcellnum,cellsintrial));
%     cellsnotintrialzeros = [cellsnotintrial, zeros(length(cellsnotintrial), size(trialdata,2)-1)];
%     
%     allcellstrial = sortrows([trialdata ; cellsnotintrialzeros], 1);
%     
%     trialsAllCells(tr).FRvectorsAllCells = allcellstrial(:,2:end);
% end
%     
%     
%     
% %-----Save-----%
% spikeColumnVectors.animals = animals;
% spikeColumnVectors.data = trialsAllCells;
% spikeColumnVectors.allcellindicies = allcells;
% spikeColumnVectors.win = win;
% spikeColumnVectors.binsize = binsize;
% 
% 
% filename = ['spikingColumnVectors_',region, '_',trigtype];
% 
% save(['E:\AnalysesAcrossAnimals\',filename],'spikeColumnVectors');