
%topDir = 'D:\OdorPlaceAssociation\';
topDir = 'F:\Data\OdorPlaceAssociation\';
betaregions = {'CA1','PFC','OB'};
cellregions = {'CA1','PFC'};

for r = 1:length(betaregions)
    
    region = betaregions{r};
    disp(['Doing ', region]);
    tag = ['betaPhaseLocked_',region];
    
    load([topDir,'AnalysesAcrossAnimals\betaModv2_',region,'.mat'])
    
    
     p = vertcat(betaMod.prayl); %find cells that are beta modulated
     betaModCells = betaMod(p < 0.05);
     
     prevanimal = '';
     for c = 1:length(betaModCells)
         disp(['Doing ', num2str(c), ' of ', num2str(length(betaModCells))]);
         
         animal = betaModCells(c).animal;
         cellind = betaModCells(c).index;
         
         if ~strcmp(animal, prevanimal)
             load([topDir,animal,'Expt\',animal,'_direct\',animal,'cellinfo.mat'])
         end
         
         
         day = cellind(1); tet = cellind(2); cell = cellind(3);
         for e = 1:length(cellinfo{day})
             cellinfo{day}{e}{tet}{cell}.(tag) = 1;
         end
         
         save([topDir,animal,'Expt\',animal,'_direct\',animal,'cellinfo.mat'],'cellinfo');
         
         prevanimal = animal;
         
     end
end