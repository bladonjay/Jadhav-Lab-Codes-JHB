cellregions = {'CA1','PFC'};
 for r = 1:length(cellregions)
     region = cellregions{r};
     
     totalcells = 0;
     for a = 1:length(animals)
         animal = animals{a};
         animalstrs = {newdata.animal};
         animalcells = newdata(strcmp(animalstrs,animal));


         load([topDir,animal,'Expt\',animal,'_direct\',animal,'tetinfo.mat'])
         tetfilter = ['((strcmp($area, ''',region,''')))'];
         tets = evaluatefilter(tetinfo{1,1}{1,2}, tetfilter);
         
         cellinds = vertcat(animalcells.index);
         celltets = cellinds(:,2);
         good = (ismember(celltets,tets, 'rows'));
         cellsinregion(totalcells+1:(totalcells+sum(good))) = animalcells(good);
         totalcells = length(cellsinregion);
     end
     
     eval(['placeFields_',region,'= cellsinregion;']);
     clear cellsinregion
 end