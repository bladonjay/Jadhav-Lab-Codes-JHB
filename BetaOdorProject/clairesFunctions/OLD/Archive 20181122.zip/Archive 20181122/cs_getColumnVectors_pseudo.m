% Claire Symanski 4/2/2018
% 
% This function creates matrices for use with PCA. It combines cells over all
% animals to create a pseudopopulation, which assumes that all cells were
% recorded simultaneously. 
% Outputs two different types of matrices: 
% 
% "AllTrials" - each cell on every trial is counted as a different
% dimension. i.e. cell 1 trial 1, then cell 1 trial 2, etc.
% 
% "Mean" - takes average number of spikes in each timebin for each cell
% first, then combines into one matrix. Fewer dimensions since it does not
% take every individual trial separately.



function cs_getColumnVectors_pseudo(regions, win, savedata)

[topDir, ~] = cs_setPaths();

dataDir = [topDir,'AnalysesAcrossAnimals\'];

winstr = [num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms'];

for r = 1:length(regions)
    region = regions{r};
    
    
%load(['E:\AnalysesAcrossAnimals\TriggeredSpiking_',region,'.mat']);
    load([dataDir, 'cellSelectivityData_',region,'_',winstr,'.mat']);

% All cells all trials
    leftAllTrials = vertcat(cellSelectivity.psthleftTriggers);
    rightAllTrials = vertcat(cellSelectivity.psthrightTriggers);
    

% Mean FR only
    for c = 1:length(cellSelectivity)
        leftMean(c,:) = mean(cellSelectivity(c).psthleftTriggers);
        rightMean(c,:) = mean(cellSelectivity(c).psthrightTriggers);
    
         
    end
        leftMean = leftMean / 0.05; %is this binsize?
        rightMean = rightMean / 0.05;
    
    zscores = [cellSelectivity.zscore];
    inds = find(abs(zscores)>=2);
    
    selectiveCells = cellSelectivity(inds);
    for s = 1:length(selectiveCells)
        sel_leftMean(s,:) = mean(cellSelectivity(s).psthleftTriggers);
        sel_rightMean(s,:) = mean(cellSelectivity(s).psthrightTriggers);
        
    end
        sel_leftMean = sel_leftMean / 0.05;
        sel_rightMean = sel_rightMean / 0.05;

    filename = ['columnVectors_',region, '_', winstr];

    if savedata == 1
        save([dataDir,filename],'leftAllTrials','rightAllTrials','leftMean','rightMean','sel_leftMean','sel_rightMean')
    end
end


