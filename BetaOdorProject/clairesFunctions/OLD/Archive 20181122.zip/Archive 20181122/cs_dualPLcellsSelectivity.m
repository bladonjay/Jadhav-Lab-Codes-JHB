load([dataDir,'phaseLockedSelectiveCells_CA1.mat'])
CA1plsel = phaseLockedSelectiveCells;
CA1inds = vertcat(phaseLockedSelectiveCells(1).indWithAnimal); 

load([dataDir,'phaseLockedSelectiveCells_PFC.mat'])
PFCplsel = phaseLockedSelectiveCells;
PFCinds = vertcat(phaseLockedSelectiveCells(1).indWithAnimal);

load([dataDir, 'phaseLockedtoCA1andPFC.mat']);

CA1selectiveDualPL = intersect(CA1phaseLockedtoBoth,CA1inds,'rows');
CA1fraction = length(CA1selectiveDualPL)/length(CA1phaseLockedtoBoth);

PFCselectiveDualPL = intersect(PFCphaseLockedtoBoth,PFCinds,'rows');
PFCfraction = length(PFCselectiveDualPL)/length(PFCphaseLockedtoBoth);



