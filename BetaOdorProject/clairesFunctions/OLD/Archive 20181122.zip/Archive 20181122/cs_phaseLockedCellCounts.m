function cs_phaseLockedCellCounts(dataDir)

animals = {'CS31','CS33','CS34','CS35'};

load([dataDir,'betaModv2_CA1.mat']);
CA1_CA1cells_all =betaMod_CA1cells;
CA1_PFCcells_all =betaMod_PFCcells;

CA1_CA1cells_all_inds = vertcat(betaMod_CA1cells.index);
CA1_PFCcells_all_inds = vertcat(betaMod_PFCcells.index);



load([dataDir,'betaModv2_PFC.mat']);
PFC_CA1cells_all =betaMod_CA1cells;
PFC_PFCcells_all =betaMod_PFCcells;

PFC_CA1cells_all_inds = vertcat(betaMod_CA1cells.index);
PFC_PFCcells_all_inds = vertcat(betaMod_PFCcells.index);




load([dataDir,'betaModv2_OB.mat']);
OB_CA1cells_all =betaMod_CA1cells;
OB_PFCcells_all =betaMod_PFCcells;

OB_CA1cells_all_inds = vertcat(betaMod_CA1cells.index);
OB_PFCcells_all_inds = vertcat(betaMod_PFCcells.index);



%----- CA1 -----%
CA1CA1animals = {CA1_CA1cells_all.animal};
animalinds = [];
for a = 1:length(animals) %create index that includes animal
    an = animals{a};
    animalinds(find(strcmp(CA1CA1animals,an))) = a;
end
CA1CA1cellinds = [animalinds', CA1_CA1cells_all_inds];

p = [CA1_CA1cells_all.prayl];
CA1CA1sigcellinds =  CA1CA1cellinds(find(p < 0.05),:);


PFCCA1animals = {PFC_CA1cells_all.animal};
animalinds = [];
for a = 1:length(animals) %create index that includes animal
    an = animals{a};
    animalinds(find(strcmp(PFCCA1animals,an))) = a;
end
PFCCA1cellinds = [animalinds', PFC_CA1cells_all_inds];

p = [PFC_CA1cells_all.prayl];
PFCCA1sigcellinds =  PFCCA1cellinds(find(p < 0.05),:);

OBCA1animals = {OB_CA1cells_all.animal};
animalinds = [];
for a = 1:length(animals) %create index that includes animal
    an = animals{a};
    animalinds(find(strcmp(OBCA1animals,an))) = a;
end
OBCA1cellinds = [animalinds', OB_CA1cells_all_inds];

p = [OB_CA1cells_all.prayl];
OBCA1sigcellinds =  OBCA1cellinds(find(p < 0.05),:);

allCA1Cells = unique(vertcat(CA1CA1cellinds,PFCCA1cellinds, OBCA1cellinds),'rows');
allsigCA1cells = unique(vertcat(CA1CA1sigcellinds,PFCCA1sigcellinds, OBCA1sigcellinds),'rows');

CA1phaseLockedFraction = length(allsigCA1cells)/length(allCA1Cells);
CA1counts = [length(allsigCA1cells) length(allCA1Cells)];

%----- PFC ------%
CA1PFCanimals = {CA1_PFCcells_all.animal};
animalinds = [];
for a = 1:length(animals) %create index that includes animal
    an = animals{a};
    animalinds(find(strcmp(CA1PFCanimals,an))) = a;
end
CA1PFCcellinds = [animalinds', CA1_PFCcells_all_inds];

p = [CA1_PFCcells_all.prayl];
CA1PFCsigcellinds =  CA1PFCcellinds(find(p < 0.05),:);


PFCPFCanimals = {PFC_PFCcells_all.animal};
animalinds = [];
for a = 1:length(animals) %create index that includes animal
    an = animals{a};
    animalinds(find(strcmp(PFCPFCanimals,an))) = a;
end
PFCPFCcellinds = [animalinds', PFC_PFCcells_all_inds];

p = [PFC_PFCcells_all.prayl];
PFCPFCsigcellinds =  PFCPFCcellinds(find(p < 0.05),:);

OBPFCanimals = {OB_PFCcells_all.animal};
animalinds = [];
for a = 1:length(animals) %create index that includes animal
    an = animals{a};
    animalinds(find(strcmp(OBPFCanimals,an))) = a;
end
OBPFCcellinds = [animalinds', OB_PFCcells_all_inds];

p = [OB_PFCcells_all.prayl];
OBPFCsigcellinds =  OBPFCcellinds(find(p < 0.05),:);

allPFCCells = unique(vertcat(CA1PFCcellinds,PFCPFCcellinds, OBPFCcellinds),'rows');
allsigPFCcells = unique(vertcat(CA1PFCsigcellinds,PFCPFCsigcellinds, OBPFCsigcellinds),'rows');

PFCphaseLockedFraction = length(allsigPFCcells)/length(allPFCCells);
PFCcounts = [length(allsigPFCcells) length(allPFCCells)];


save([dataDir,'phaseLockedCellFractions'],'CA1counts','PFCcounts','CA1phaseLockedFraction','PFCphaseLockedFraction');