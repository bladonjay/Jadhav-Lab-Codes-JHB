%tag cells with selectivity index #, then can find these cells again and
%plot. 


%cs_odorSelectivity_v2('F:\Data\OdorPlaceAssociation\','F:\Figures\', [0.5 1], 0.05);
function cs_odorSelectivity_v2(topDir, figDir, win,binsize)
animals = {'CS31','CS33','CS34','CS35'};
regions = {'CA1','PFC'};
winsize = win(2) + win(1);

for r = 1:length(regions)
region = regions{r};
    %find cells that meet selection criteria (pyramidal cells that are odor selective in area of
    %interest)
    npCellsSelectivity = []; inds =[];
    i_npCellSelectivity = [];
    for a = 1:length(animals)
        animal = animals{a};
        animDir = [topDir, animal, 'Expt\',animal,'_direct\'];
        
        load([animDir,animal,'cellinfo.mat'])
        
        %cellfilter = ['isequal($area,''',region,'''))'];
        cellfilter = ['((isequal($area,''',region, ... 
            ''')) && (strcmp($selectivity, ''leftSelective'') || strcmp($selectivity, ''rightSelective'')))'];
        
        cells = evaluatefilter(cellinfo,cellfilter);
        
        noeps = cells(:,[1 3 4]);
        cells = unique(noeps,'rows');
        
        days = unique(cells(:,1));
        for d = 1:length(days)
            day = days(d);
            daystr = getTwoDigitNumber(day);
            
            daycells = cells(cells(:,1) == day,:);
            
            load([animDir,animal,'spikes',daystr,'.mat'])
            load([animDir,animal,'odorTriggers',daystr,'.mat'])
            runeps = find(~cellfun(@isempty,odorTriggers{day}));
            
           
            for c = 1:size(daycells,1)

                correctleftspikes = []; 
                correctrightspikes = [];
                incorrectleftspikes = [];
                incorrectrightspikes = [];
                
                cell = daycells(c,:);
                
                for ep = 1:length(runeps)
                    epoch = runeps(ep);
                    
                    if ~isempty(spikes{cell(1)}{epoch}{cell(2)}{cell(3)})
                        epspikes = spikes{cell(1)}{epoch}{cell(2)}{cell(3)}.data(:,1);
                        
                        [correct_left, correct_right, incorrect_left, incorrect_right] = cs_getSpecificTrialTypeInds(odorTriggers{day}{epoch});
                        %triginds = sort([correct_left; correct_right]);

                        trigs = odorTriggers{day}{epoch}.allTriggers;
                        
                        for t = 1:length(trigs)
                        trigwin = [trigs(t)-win(1), trigs(t)+win(2)];
                        winspikes = epspikes(epspikes > trigwin(1) & epspikes <= trigwin(2));
                        bins = (trigs(t)-win(1):binsize:trigs(t)+win(2));
                        binspikecount = histcounts(winspikes,bins);
                        
                            if ismember(t, correct_left)
                                correctleftspikes = [correctleftspikes; binspikecount];
                            elseif ismember(t, correct_right)
                                correctrightspikes = [correctrightspikes; binspikecount];
                            elseif ismember(t, incorrect_left)
                                incorrectleftspikes = [incorrectleftspikes; binspikecount];
                            elseif ismember(t, incorrect_right)
                                incorrectrightspikes = [incorrectrightspikes; binspikecount];
                            end
                        
                        end
                        
                    end

                end
                
                %sumspikes = sum(sum([correctleftspikes; correctrightspikes]));
                
                %if sumspikes >= length(trigs)
                    cleftbinfr = mean(correctleftspikes,1)./binsize;
                    crightbinfr = mean(correctrightspikes,1)./binsize;
                    
                    selectivity = (cleftbinfr - crightbinfr)./(cleftbinfr + crightbinfr);
                    
                    npCellsSelectivity = [npCellsSelectivity;selectivity];
                    
                    inds = [inds; a, cell];
                    
                    if isempty(incorrectleftspikes)
                        incorrectleftspikes = 0;
                    end
                    if isempty(incorrectrightspikes)
                        incorrectrightspikes = 0;
                    end
                    
                    ileftbinfr = mean(incorrectleftspikes,1)./binsize;
                    irightbinfr = mean(incorrectrightspikes,1)./binsize;
                    
                    i_selectivity = (ileftbinfr - irightbinfr)./(ileftbinfr + irightbinfr);
                    i_npCellSelectivity = [i_npCellSelectivity; i_selectivity]; 
                    
                %end
                
            end
            
        end
       

    end
    npCellsSelectivity(isnan(npCellsSelectivity))=0;
    smoothed = zeros(size(npCellsSelectivity));
    bins = -win(1):binsize:win(2);
    trigbins = (bins >= 0 & bins < 0.6); 
    mn = mean(npCellsSelectivity(:,trigbins), 2);
    [mn2,sortmean] = sort(mn,'descend');
    
    std = 1.5;
    s = gaussian(std,(4*std));
    for c = 1:size(npCellsSelectivity,1)
         smoothed(c,:) = filter2(s,npCellsSelectivity(c,:)); 
    end
    smoothed = smoothed(sortmean,:);
    figure,
    set(gcf,'Position',[300 100 300 500]);
    imagesc([-(win(1)):binsize:win(2)], [length(npCellsSelectivity):1],smoothed);
    colorbar
    [cmap]=buildcmap('rkg'); 
    colormap(cmap) %will use the output colormap
    colorbar('YTick', [-1 0 1]);
    caxis([-1 1])
    title([region, ' Correct Trials']);
    xlabel('Time from odor onset (s)');
    ylabel('Cell Number');
    
    %save
       figfile = [figDir,'4a_OdorSelectivity_',region,'_Correct'];
       saveas(gcf,figfile,'fig');
       print('-dpdf', figfile);
       print('-djpeg',figfile);
    
    
    %Compare to Incorrect using same cell order
    i_npCellSelectivity(isnan(i_npCellSelectivity))=0;
    i_smoothed = zeros(size(i_npCellSelectivity));
    for c = 1:size(i_npCellSelectivity,1)
         i_smoothed(c,:) = filter2(s,i_npCellSelectivity(c,:)); 
    end
    i_smoothed = i_smoothed(sortmean,:);
    figure,
    set(gcf,'Position',[300 100 300 500]);
    imagesc([-(win(1)):binsize:win(2)], [length(i_npCellSelectivity):1],i_smoothed);
    colorbar
    colorbar('YTick', [-1 0 1]);
    caxis([-1 1])
    [cmap]=buildcmap('rkg'); 
    colormap(cmap) %will use the output colormap
    title([region, ' Incorrect Trials']);
    xlabel('Time from odor onset (s)');
    ylabel('Cell Number');
    
    %save
       figfile = [figDir,'4a_OdorSelectivity_',region,'_Incorrect'];
       saveas(gcf,figfile,'fig');
       print('-dpdf', figfile);
       print('-djpeg',figfile);
    
end