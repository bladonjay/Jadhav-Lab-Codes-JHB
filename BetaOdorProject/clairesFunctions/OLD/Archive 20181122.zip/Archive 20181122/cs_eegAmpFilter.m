
function cs_eegAmpFilter(animalID, minAmp, maxAmp)
%Filters out all high amplitude events from raw eeg to reduce noise
%CS 4/26/2017

eegDirectory = ['E:\Data\OdorPlaceAssociation\',animalID,'_direct\EEG\'];
cd(eegDirectory)

eegfiles = dir('CS31eeg*'); %find all raw eeg files in directory

for i = 1:length(eegfiles)
    eegfilename = eegfiles(i,1).name;
    eegfile = load(eegfilename);
    
    day = str2double(eegfilename(8:9)); %find day epoch tetrode for each file
    epoch = str2double(eegfilename(11:12));
    tetrode = str2double(eegfilename(14:15));
    
    eegdata = eegfile.eeg{1,day}{1,epoch}{1,tetrode}.data; 
    
    mininds = find(eegdata < minAmp);
    eegdata(mininds) = minAmp;
    
    maxinds = find(eegdata > maxAmp);
    eegdata(maxinds) = maxAmp;
    
    eegfile.eeg{1,day}{1,epoch}{1,tetrode}.data = eegdata;
    printstring = ['Doing day ', num2str(day), ', epoch ', num2str(epoch), ', tetrode ',num2str(tetrode)];
    disp(printstring)
    ampfilteeg = eegfile;
    
    savefilename = [animalID, 'ampfilteeg',eegfilename(8:9),'-',eegfilename(11:12),'-',eegfilename(14:15),'.mat'];
    save(savefilename, 'ampfilteeg');
end
    