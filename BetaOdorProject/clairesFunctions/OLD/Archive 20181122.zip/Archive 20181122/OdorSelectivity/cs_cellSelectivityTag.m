%function cs_selectivityTag(cellinfo, cellind, spikes, lefttrigs, righttrigs, win, iterations)

%combine spiketimes across run epochs
%combine trig times across run epochs

%tag cells with selectivity index #, then can find these cells again and
%plot. 

%topDir = 'F:\Data\OdorPlaceAssociation\';
topDir = 'D:\OdorPlaceAssociation\';
animals = {'CS31','CS33','CS34','CS35'};
regions = {'CA1','PFC'};
win = [0 1];
iterations = 1000;

winsize = win(2) + win(1);

for r = 1:length(regions)
region = regions{r};
    %find cells that meet selection criteria (pyramidal cells in area of
    %interest)
    npCellsSelectivity = []; inds =[];
    i_npCellSelectivity = [];
    total = 0;
    for a = 1:length(animals)
        animal = animals{a};
        animDir = [topDir, animal, 'Expt\',animal,'_direct\'];
        
        load([animDir,animal,'cellinfo.mat'])
        
        %cellfilter = ['isequal($area,''',region,'''))'];
        cellfilter = ['((strcmp($type, ''pyr'')) && (isequal($area,''',region,''')))'];
        cells = evaluatefilter(cellinfo,cellfilter);
        
        noeps = cells(:,[1 3 4]);
        cells = unique(noeps,'rows');
        
        days = unique(cells(:,1));
        for d = 1:length(days)
            day = days(d);
            daystr = getTwoDigitNumber(day);
            
            daycells = cells(cells(:,1) == day,:);
            
            load([animDir,animal,'spikes',daystr,'.mat'])
            load([animDir,animal,'odorTriggers',daystr,'.mat'])
            runeps = find(~cellfun(@isempty,odorTriggers{day}));
            
            
            trigs_all= []; correct_left_all = []; correct_right_all = [];
            for ep = 1:length(runeps)
                epoch = runeps(ep);
                [correct_left, correct_right, ~, ~] = cs_getSpecificTrialTypeInds(odorTriggers{day}{epoch});
                trigs = odorTriggers{day}{epoch}.allTriggers;
                
            correct_left_all = [correct_left_all; trigs(correct_left)];
            correct_right_all = [correct_right_all; trigs(correct_right)];
            trigs_all = [trigs_all ; trigs];
            
            end
            
            frallcellsL = []; frallcellsR = [];
            for c = 1:length(daycells)

                leftspikes = []; 
                rightspikes = [];
%                 incorrectleftspikes = [];
%                 incorrectrightspikes = [];
                
                cell = daycells(c,:);
                
                %remove fields if they exist
                for e = 1:length(cellinfo{day})
                    if length(cellinfo{cell(1)}{e}) >= cell(2)
                        if length(cellinfo{cell(1)}{e}{cell(2)}) >= cell(3)
                            if isfield(cellinfo{cell(1)}{e}{cell(2)}{cell(3)},'selectivity')
                               cellinfo{cell(1)}{e}{cell(2)}{cell(3)} = rmfield(cellinfo{cell(1)}{e}{cell(2)}{cell(3)}, 'selectivity');
                            end
                             if isfield(cellinfo{cell(1)}{e}{cell(2)}{cell(3)},'SI')
                               cellinfo{cell(1)}{e}{cell(2)}{cell(3)} = rmfield(cellinfo{cell(1)}{e}{cell(2)}{cell(3)}, 'SI');
                            end
                        end
                    end
                end

                runspikes = []; 
                
                for ep = 1:length(runeps)
                    epoch = runeps(ep);
                    
                    if ~isempty(spikes{cell(1)}{epoch}{cell(2)}{cell(3)})
                        runspikes = [runspikes; spikes{cell(1)}{epoch}{cell(2)}{cell(3)}.data(:,1)];                             
                    end
                    
                    
                end
                
                for t = 1:length(correct_left_all)
                    trig = correct_left_all(t);
                        trigwin = [trig-win(1), trig+win(2)];
                        winspikes =sum(runspikes > trigwin(1) & runspikes <= trigwin(2));
                        %bins = (trig-win(1):binsize:trig+win(2));
                        %binspikecount = histcounts(winspikes,bins);
                        
                        leftspikes = [leftspikes; winspikes];     
                end
                
                for t = 1:length(correct_right_all)
                    trig = correct_right_all(t);
                        trigwin = [trig-win(1), trig+win(2)];
                        winspikes = sum(runspikes > trigwin(1) & runspikes <= trigwin(2));
                        %bins = (trig-win(1):binsize:trig+win(2));
                        %binspikecount = histcounts(winspikes,bins);
                        
                        rightspikes = [rightspikes; winspikes];     
                end
                
                
                sumspikes = sum([leftspikes; rightspikes]);
                
                if sumspikes >= length(trigs_all)
                    leftfr = mean(leftspikes)/winsize;
                    rightfr = mean(rightspikes)/winsize;
                    
                    
                    
                    selectivity = (leftfr - rightfr)/(leftfr + rightfr);
                end
                
                      
                %do the shuffle 
                     
                    leftones = ones(size(leftspikes,1),1);
                    rightzeros = zeros(size(rightspikes,1),1);

                    indicators = [leftones;rightzeros];
                    allTrials = [leftspikes; rightspikes];

                    shuffIndexDist = zeros(iterations,1);
                    for i = 1:iterations
                        shuffledRL = indicators(randperm(length(indicators)));
                        newLeft = mean(allTrials(shuffledRL == 1))/winsize;
                        newRight = mean(allTrials(shuffledRL == 0))/winsize;

                        newIndex = (newLeft - newRight)/(newLeft + newRight);
                        shuffIndexDist(i) = newIndex;
                    end

                    shuffMean = mean(shuffIndexDist);
                    shuffStd = std(shuffIndexDist);

                    trueIndexZ = (selectivity - shuffMean)/shuffStd;
                    
                    
                        
                    if trueIndexZ >= 2 
                        for e = 1:length(cellinfo{day})
                            if length(cellinfo{cell(1)}{e}{cell(2)}) >= cell(3)
                                cellinfo{cell(1)}{e}{cell(2)}{cell(3)}.selectivity = 'leftSelective';
                                cellinfo{cell(1)}{e}{cell(2)}{cell(3)}.SI = selectivity;
                            end
                        end
                        total = total+1;
                    elseif trueIndexZ <= -2
                        for e = 1:length(cellinfo{day})
                            if length(cellinfo{cell(1)}{e}{cell(2)}) >= cell(3)
                                cellinfo{cell(1)}{e}{cell(2)}{cell(3)}.selectivity = 'rightSelective';
                                cellinfo{cell(1)}{e}{cell(2)}{cell(3)}.SI = selectivity;
                            end
                        end
                        total = total+1;
                    end
                end
              
                
        
            end
        end
        save([topDir,animal,'Expt\',animal,'_direct\',animal,'cellinfo.mat'],'cellinfo');
    end
end

cs_listSelectiveCells