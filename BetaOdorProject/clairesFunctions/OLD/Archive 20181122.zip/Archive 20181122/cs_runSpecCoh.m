DFScs_eventTrigSpecgram
DFScs_eventCoherence


cs_plotSpecgram('eventTrigSpecgramData_OB_low_-1000-2000ms_tapers1-1_20msBins.mat')
cs_plotSpecgram('eventTrigSpecgramData_PFC_low_-1000-2000ms_tapers1-1_20msBins.mat')
cs_plotSpecgram('eventTrigSpecgramData_CA1_low_-1000-2000ms_tapers1-1_20msBins.mat')

cs_plotCoherence('Coherence_CA1-OB.mat')
cs_plotCoherence('Coherence_CA1-PFC.mat')
cs_plotCoherence('Coherence_PFC-OB.mat')

DFScs_odorSelectivityPSTH

cs_getCellSelectivity('D:\OdorPlaceAssociation\AnalysesAcrossAnimals\', 'TriggeredSpiking_CA1_-500-1000ms_50msBins.mat', 10000)
cs_getCellSelectivity('D:\OdorPlaceAssociation\AnalysesAcrossAnimals\', 'TriggeredSpiking_PFC_-500-1000ms_50msBins.mat', 10000)

cs_plotSelectivity({'CA1','PFC'}, 'D:\Figures\OdorSelectivity\')

cs_plotRasterPSTH('TriggeredSpiking_CA1_-500-1000ms_50msBins.mat')

cs_plotRasterPSTH_specifiedCells('TriggeredSpiking_CA1_-500-1000ms_100msBins.mat', cellsToLookAt, 0)