function cs_avgBetaPower(animals, topDir, regions)

for a = 1:length(animals)
    animal = animals{a};
    dataDir = [topDir, animal, 'Expt\', animal, '_direct\'];
    load([dataDir, animal, 'tetinfo.mat'])
    
    dayfiles = dir([dataDir, animal, 'runTrialBounds*']);
    
    for r = 1:length(regions)
        region = regions{r};
        
        for d = 1:length(dayfiles)
            day = d;
            daystring = getTwoDigitNumber(day);
            load(dayfiles(d).name);
            runTrialBounds = runTrialBounds{1,day};
            epochs = find(~cellfun(@isempty, runTrialBounds));
        
            for ep = 1:length(epochs)
                epoch = epochs(ep);
                epstring = getTwoDigitNumber(epoch);
                tetfilter = ['((strcmp($area, ''',region,''')) && (strcmp($descrip2, ''betatet'')))'];
                tets = evaluatefilter(tetinfo{1,day}{1,epoch}, tetfilter);
                
                betaPowerAllTets = [];
                for t = 1:length(tets)
                    tet = tets(t);
                    tetstring = getTwoDigitNumber(tet);
                    load([dataDir,'EEG\',animal,'beta',daystring,'-',epstring,'-',tetstring,'.mat']);
                    beta = beta{day}{epoch}{tet};
                    betatimes = [beta.starttime:1/beta.filtersamprate:beta.endtime]';
                    betaPowerAllTets = [betaPowerAllTets, double(beta.data(:,3))]; %get envelope
                    
                end
                
                meanBetaPower = mean(betaPowerAllTets,2);
                meanBetaEpoch = [betatimes, meanBetaPower];
                
                meanBeta{1,day}{1,epoch} = meanBetaEpoch;
                
            end
            save([dataDir,animal,'meanBeta',region,daystring],'meanBeta');
            clear meanBeta
            
        end     
    end
end