wt_beta_phaselocking(topDir, animalprefix)
clear all;
close all;
%%
%addpath(genpath('/Users/wenbotang/Documents/Remote_HMM_files/Src_Matlab'))
%addpath('/Users/wenbotang/Documents/Remote_HMM_files/SleepCode')
%%
dir = ([topDir, animalprefix,'Expt\',animalprefix, '_direct\']);
%dir = ('F:\Data\OdorPlaceAssociation\CS33Expt\CS33_direct\');
%figdir = [dir,'/Beta_phaselock/'];
figopt = 0;
day = 3;
ep = 2; daystr = getTwoDigitNumber(day);
savedata = 1;
exclude_list = [];
%%
[ctxidx, hpidx] = WT_findcellindex_CS(dir, animalprefix, day, ep, exclude_list); %(tet, cell)
ctxnum = length(ctxidx(:,1));
hpnum = length(hpidx(:,1));
%%
%-----beta time----%
%load(sprintf('%s%sbetatime0%d.mat',dir,animalprefix,day));
%load(sprintf('%s%shighBeta.mat',dir,animalprefix));

%betalist = highBeta{day}{ep}.allTriggers.OB;
%betalist(:,1) = betatime{day}{ep}.starttime;
%betalist(:,2) = betatime{day}{ep}.endtime;

load([animalprefix, 'odorTriggers',daystr,'.mat']);
trigs = odorTriggers{day}{ep}.allTriggers;
betalist(:,1) = trigs;
betalist(:,2) = trigs + 2;

%-----load beta eeg using CA1Ref tetrode-----%
tetinfo = loaddatastruct(dir, animalprefix, 'tetinfo');
spikes = loaddatastruct(dir, animalprefix, 'spikes', day); % get spikes

for ttt = 1:length(tetinfo{day}{ep})
    if ~isempty(tetinfo{day}{ep}{ttt})
        if isfield(tetinfo{day}{ep}{ttt},'descrip')
           if strcmp(tetinfo{day}{ep}{ttt}.descrip,'hpcRef')
               reftet = ttt;
           end
        end
    end
end
%reftet = 10;               
tmpflist1 = sprintf('%s%sbeta%02d-%02d-%02d.mat', [dir,'EEG/'],animalprefix, day, ep, reftet);
load(tmpflist1);
t = geteegtimes(beta{day}{ep}{reftet});
tph = beta{day}{ep}{reftet}.data(:,2);% beta phase
        
%%
nbins = 24;
%------HP cells----%
for cell = 1:hpnum
    cind = hpidx(cell,:);
    s = spikes{day}{ep}{cind(1)}{cind(2)}.data(:,1);
    t = geteegtimes(beta{day}{ep}{reftet});
    sph = tph(lookup(s, t));  
    goodspikes = isExcluded(s, betalist);
    numgoodspikes = sum(goodspikes);
    sph = double(sph(find(goodspikes))) / 10000;  % If no spikes, this will be empty
    if length(sph)>1
        % Rayleigh and Modulation: Originally in lorenlab Functions folder
        stats = rayleigh_test(sph); % stats.p and stats.Z, and stats.n
        [m, ph] = modulation(sph);
        phdeg = ph*(180/pi);

        % Von Mises Distribution - From Circular Stats toolbox
        [betahat, kappa] = circ_vmpar(sph); % Better to give raw data. Can also give binned data.
        betahat_deg = betahat*(180/pi);
        [prayl, zrayl] = circ_rtest(sph); % Rayleigh test for non-uniformity of circular data
        % Make finer polar plot and overlay Von Mises Distribution Fit.
        % Circ Stats Box Von Mises pdf uses a default of 100 angles/nbin
        % -------------------------------------------------------------
        nbins = 50;
        bins = -pi:(2*pi/nbins):pi;
        count = histc(sph, bins);

        % Make Von Mises Fit
        alpha = linspace(-pi, pi, 50)';
        [pdf] = circ_vmpdf(alpha,betahat,kappa);
    else    
        stats=0;
        m=0;
        phdeg=0;
        kappa=0;
        betahat_deg=0;
        prayl=0;
        zrayl=0;
        alpha=0;
        pdf=0;
    end
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.index = cind;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.tetindex = reftet;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.sph = sph;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.Nspikes = numgoodspikes;
    % output stats also, although you will have to redo this after combining epochs
    % Rayleigh test
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.stats = stats;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.modln = m;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.phdeg = phdeg;
    % Von Mises Fit
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.kappa = kappa;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.betahat_deg = betahat_deg;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.prayl = prayl;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.zrayl = zrayl;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.alpha = alpha;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.vmpdf = pdf;
    
    if (figopt)
        if length(sph)>10
        % Plot
        % ----
        bins = -pi:(2*pi/nbins):pi;
        count = histc(sph, bins);
        figure; redimscreen_2horsubplots
        subplot(1,2,1);
        hold on;
        out = bar(bins, count, 'hist'); set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
        set(gca,'XLim',[-pi-0.5 pi]); ylabel('NSpikes'); set(out,'FaceColor','r');
        title(sprintf('cell %d %d, eegtet %d beta, mod %f, peakph %g, pval %f', cind, reftet, m, phdeg, stats.p));

        % Shantanu - add a plot with %tage of spikes
        % -------------------------------------------
        subplot(1,2,2);
        hold on;
        totalspks = sum(count);
        countper = (count./totalspks)*100;
        out = bar(bins, countper, 'hist');  set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
        set(gca,'XLim',[-pi-0.5 pi]); ylabel('% of Spikes'); set(out,'FaceColor','r');
        %figfile = [figdir,animalprefix,'_beta_phaselock1','_Day',num2str(day),'-Ep',num2str(ep),'_Reftet',num2str(reftet),'_cell',num2str(cind(1)),'_',num2str(cind(2))];
        %print('-djpeg', figfile);
        
        % Polar plot  - use rose or polar:
        % --------------------------------
        % [t,r] = rose(sph): input is angle in radians for each spike
        % polar(t,r);

        % My range is -pi to pi. This will plot from 0 to 2*pi, and it seems to do this automatically.
        % No need to adjust range %sphn = sph + pi;

        [t,r] = rose(sph);
        figure;  redimscreen_figforppt1;
        polar(t,r,'r'); hold on;
        % The peak phase angle
        lims = get(gca,'XLim');
        radius = lims(2);
        xx = radius .* cos(ph); yy = radius .* sin(ph);
        line([0 xx], [0 yy],'LineWidth',4,'Color','k'); %plot(xx,yy,'ko','MarkerSize',4);
        title(sprintf('cell %d %d, eegtet %d beta, mod %f, peakph %g, pval %f', cind, reftet, m, phdeg, stats.p));
        %figfile = [figdir,animalprefix,'_beta_phaselock2','_Day',num2str(day),'-Ep',num2str(ep),'_Reftet',num2str(reftet),'_cell',num2str(cind(1)),'_',num2str(cind(2))];
        %print('-djpeg', figfile);

        % Make finer polar plot and overlay Von Mises Distribution Fit.
        % Circ Stats Box Von Mises pdf uses a default of 100 angles/nbin
        % -------------------------------------------------------------

        figure; redimscreen_2horsubplots
        subplot(1,2,1);
        hold on;
        out = bar(bins, count, 'hist'); set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
        set(gca,'XLim',[-pi pi]); ylabel('NSpikes');
        set(out,'FaceColor','r'); set(out,'EdgeColor','r');
        %pdf = pdf.*(max(count)/max(pdf));
        % Instead of maximum - match values at a bin, maybe close to peak
        binnum = lookup(betahat,alpha);
        pdf = pdf.*(count(binnum)/pdf(binnum));
        plot(alpha,pdf,'k','LineWidth',3,'Color','k');
        title(sprintf('cell %d %d, eegtet %d beta, Kappa %f, prefang %g, pval %f', cind, reftet, kappa, betahat_deg, prayl));

        subplot(1,2,2); hold on;

        totalspks = sum(count);
        countper = (count./totalspks)*100;
        out = bar(bins, countper, 'hist');  set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
        set(gca,'XLim',[-pi pi]); ylabel('% of Spikes');
        set(out,'FaceColor','r'); set(out,'EdgeColor','r');
        pdf = pdf.*(countper(binnum)/pdf(binnum));
        plot(alpha,pdf,'k','LineWidth',3,'Color','k');
        title(sprintf('Nspikes %d', totalspks));
        %figfile = [figdir,animalprefix,'_beta_phaselock3','_Day',num2str(day),'-Ep',num2str(ep),'_Reftet',num2str(reftet),'_cell',num2str(cind(1)),'_',num2str(cind(2))];
       %print('-djpeg', figfile);
        end
    end
    close all

        
end
if savedata
    save(sprintf('%s/%sbeta_phaselock%02d.mat', dir, animalprefix, day), 'beta_phaselock')
end

clear beta_phaselock

%%
%------CTX cells----%
for cell = 1:ctxnum
    cind = ctxidx(cell,:);
    s = spikes{day}{ep}{cind(1)}{cind(2)}.data(:,1);
    t = geteegtimes(beta{day}{ep}{reftet});
    sph = tph(lookup(s, t));  
    goodspikes = isExcluded(s, betalist);
    numgoodspikes = sum(goodspikes);
    sph = double(sph(find(goodspikes))) / 10000;  % If no spikes, this will be empty
    if length(sph)>1
        % Rayleigh and Modulation: Originally in lorenlab Functions folder
        stats = rayleigh_test(sph); % stats.p and stats.Z, and stats.n
        [m, ph] = modulation(sph);
        phdeg = ph*(180/pi);

        % Von Mises Distribution - From Circular Stats toolbox
        [betahat, kappa] = circ_vmpar(sph); % Better to give raw data. Can also give binned data.
        betahat_deg = betahat*(180/pi);
        [prayl, zrayl] = circ_rtest(sph); % Rayleigh test for non-uniformity of circular data
        % Make finer polar plot and overlay Von Mises Distribution Fit.
        % Circ Stats Box Von Mises pdf uses a default of 100 angles/nbin
        % -------------------------------------------------------------
        nbins = 50;
        bins = -pi:(2*pi/nbins):pi;
        count = histc(sph, bins);

        % Make Von Mises Fit
        alpha = linspace(-pi, pi, 50)';
        [pdf] = circ_vmpdf(alpha,betahat,kappa);
    else    
        stats=0;
        m=0;
        phdeg=0;
        kappa=0;
        betahat_deg=0;
        prayl=0;
        zrayl=0;
        alpha=0;
        pdf=0;
    end
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.index = cind;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.tetindex = reftet;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.sph = sph;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.Nspikes = numgoodspikes;
    % output stats also, although you will have to redo this after combining epochs
    % Rayleigh test
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.stats = stats;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.modln = m;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.phdeg = phdeg;
    % Von Mises Fit
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.kappa = kappa;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.betahat_deg = betahat_deg;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.prayl = prayl;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.zrayl = zrayl;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.alpha = alpha;
    beta_phaselock{day}{ep}{cind(1)}{cind(2)}.vmpdf = pdf;
    
    if (figopt)
        if length(sph)>10
        % Plot
        % ----
        bins = -pi:(2*pi/nbins):pi;
        count = histc(sph, bins);
        figure; redimscreen_2horsubplots
        subplot(1,2,1);
        hold on;
        out = bar(bins, count, 'hist'); set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
        set(gca,'XLim',[-pi-0.5 pi]); ylabel('NSpikes'); set(out,'FaceColor','r');
        title(sprintf('cell %d %d, eegtet %d beta, mod %f, peakph %g, pval %f', cind, reftet, m, phdeg, stats.p));

        % Shantanu - add a plot with %tage of spikes
        % -------------------------------------------
        subplot(1,2,2);
        hold on;
        totalspks = sum(count);
        countper = (count./totalspks)*100;
        out = bar(bins, countper, 'hist');  set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
        set(gca,'XLim',[-pi-0.5 pi]); ylabel('% of Spikes'); set(out,'FaceColor','r');
%         figfile = [figdir,animalprefix,'_beta_phaselock1','_Day',num2str(day),'-Ep',num2str(ep),'_Reftet',num2str(reftet),'_cell',num2str(cind(1)),'_',num2str(cind(2))];
%         print('-djpeg', figfile);
        % Polar plot  - use rose or polar:
        % --------------------------------
        % [t,r] = rose(sph): input is angle in radians for each spike
        % polar(t,r);

        % My range is -pi to pi. This will plot from 0 to 2*pi, and it seems to do this automatically.
        % No need to adjust range %sphn = sph + pi;

        [t,r] = rose(sph);
        figure;  redimscreen_figforppt1;
        polar(t,r,'r'); hold on;
        % The peak phase angle
        lims = get(gca,'XLim');
        radius = lims(2);
        xx = radius .* cos(ph); yy = radius .* sin(ph);
        line([0 xx], [0 yy],'LineWidth',4,'Color','k'); %plot(xx,yy,'ko','MarkerSize',4);
        title(sprintf('cell %d %d, eegtet %d beta, mod %f, peakph %g, pval %f', cind, reftet, m, phdeg, stats.p));
%         figfile = [figdir,animalprefix,'_beta_phaselock2','_Day',num2str(day),'-Ep',num2str(ep),'_Reftet',num2str(reftet),'_cell',num2str(cind(1)),'_',num2str(cind(2))];
%         print('-djpeg', figfile);

        % Make finer polar plot and overlay Von Mises Distribution Fit.
        % Circ Stats Box Von Mises pdf uses a default of 100 angles/nbin
        % -------------------------------------------------------------

        figure; redimscreen_2horsubplots
        subplot(1,2,1);
        hold on;
        out = bar(bins, count, 'hist'); set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
        set(gca,'XLim',[-pi pi]); ylabel('NSpikes');
        set(out,'FaceColor','r'); set(out,'EdgeColor','r');
        %pdf = pdf.*(max(count)/max(pdf));
        % Instead of maximum - match values at a bin, maybe close to peak
        binnum = lookup(betahat,alpha);
        pdf = pdf.*(count(binnum)/pdf(binnum));
        plot(alpha,pdf,'k','LineWidth',3,'Color','k');
        title(sprintf('cell %d %d, eegtet %d beta, Kappa %f, prefang %g, pval %f', cind, reftet, kappa, betahat_deg, prayl));

        subplot(1,2,2); hold on;

        totalspks = sum(count);
        countper = (count./totalspks)*100;
        out = bar(bins, countper, 'hist');  set(gca, 'XTick', [-pi, -pi/2, 0, pi/2, pi]);
        set(gca,'XLim',[-pi pi]); ylabel('% of Spikes');
        set(out,'FaceColor','r'); set(out,'EdgeColor','r');
        pdf = pdf.*(countper(binnum)/pdf(binnum));
        plot(alpha,pdf,'k','LineWidth',3,'Color','k');
        title(sprintf('Nspikes %d', totalspks));
%         figfile = [figdir,animalprefix,'_beta_phaselock3','_Day',num2str(day),'-Ep',num2str(ep),'_Reftet',num2str(reftet),'_cell',num2str(cind(1)),'_',num2str(cind(2))];
%         print('-djpeg', figfile);
        end
    end
%     close all

        
end
if savedata
    save(sprintf('%s/%sbeta_phaselock_ctx%02d.mat', dir, animalprefix, day), 'beta_phaselock')
end
       


