function [binstats, binp] = cs_calcEnsembleDistance(dataDir, animal, region, day)
%[binstats, binp] = cs_calcEnsembleDistance('E:\AnalysesAcrossAnimals\', 'CS34', 'CA1', 4)

daystring = getTwoDigitNumber(day);
daystring = ['Day_',daystring];

load([dataDir,'ensembleActivity_',animal,'_',region,'.mat'])

numbins = ensembleActivity.leftTriggers.numbins;
    
leftData = ensembleActivity.leftTriggers.signals;
numTrialsLeft = length(leftData)/numbins;

rightData = ensembleActivity.rightTriggers.signals;
numTrialsRight = length(rightData)/numbins;

% allPC1L = zeros(numTrialsLeft,numbins); 
% allPC1R = zeros(numTrialsLeft, numbins);
allpairedDist = [];
for t = 1:numTrialsLeft
        columnStart = (numbins*t) - (numbins-1);
        columnEnd =  (numbins*t);
    if (t <= numTrialsLeft) && (t <= numTrialsRight) 
        trialL = leftData(:,columnStart:columnEnd);
        trialR = rightData(:,columnStart:columnEnd);
        
        
%         allPC1L(t,:) = leftData(1,columnStart:columnEnd);
%         allPC1R(t,:) = rightData(1,columnStart:columnEnd);
%         figure,
%         plot(trialL(1,:), 'bo')
%         hold on
%         plot(trialR(1,:), 'ro')
%         
%         pause
%         close all
         trialDist = zeros(1,numbins);
        for b = 1:numbins
            leftBin = trialL(:,b);
            rightBin = trialR(:,b);
%         bindist = leftBin(1) - rightBin(1);
            bindist = sqrt((leftBin(1) - rightBin(1))^2 + (leftBin(2) - rightBin(2))^2 + (leftBin(3) - rightBin(3))^2 ...
                + (leftBin(4) - rightBin(4))^2 + (leftBin(5) - rightBin(5))^2);

            trialDist(b) = bindist;
        end
    
        
        allpairedDist(t,:) = trialDist;
    end
    
   
end

% meanL = mean(allPC1L,1);
% meanR = mean(allPC1R,1); 
% 
% dist = meanL-meanR; 

binstats = zeros(1,numbins);
binp = zeros(1,numbins);

alpha = 0.05 / numbins;

% meanDist = mean(allpairedDist,1);
% stdDist = std(allpairedDist,1);
% 
% figure,
% plot(meanDist,'o-')
% hold on
% patch([1:length(meanDist) fliplr(1:length(meanDist))], [(meanDist + stdDist) fliplr(meanDist - stdDist)],'r','FaceAlpha',0.2)
for b = 1:numbins
    
%bonferroni correction, since i'm doing a comparison for each bin. 
%not sure if this is the right way to do it? 
[h,p] = ttest(allpairedDist(:,b),0,alpha); 

binstats(b) = h;
binp(b) = p;
end

end


       