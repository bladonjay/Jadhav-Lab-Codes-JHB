load('E:\CS31Expt\CS31_direct\EEG\CS31beta03-02-24.mat')
beta = beta{1, 3}{1, 2}{1, 24}  ;
load('CS31odorTriggers03.mat')
odorTriggers = odorTriggers{1, 3}{1, 2}.correctTriggers  ;

trigger = odorTriggers(5);

window = [1.5 1.5];
start = trigger-window(1);
stop = trigger+window(1);

timerange = beta.timerange;
betatime = [timerange(1):1/1500:timerange(2)];
betatime = betatime';

betaamp = beta.data(:,1);
betaamp = double(betaamp);

betatimes = (betatime >= start & betatime<= stop);
betainwin = betaamp(betatimes);

stop = stop-trigger;
start = start-trigger;
windowtimes = [start:1/1500:stop];
windowtimes = windowtimes(1:end-1);

figure
plot(windowtimes,betainwin, 'k','LineWidth',2);
hold on
plot([0 0], [-1000 1000], 'r--','LineWidth',2);

set(gcf, 'Position', [2000 400 900 600]);
                set(gca,'fontsize',20);
box off

xlabel('Time (seconds)');
ylabel('Beta amplitude (mV)');
