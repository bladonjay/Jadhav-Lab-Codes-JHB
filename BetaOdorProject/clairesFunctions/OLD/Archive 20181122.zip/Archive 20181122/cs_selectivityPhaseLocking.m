
function cs_selectivityPhaseLocking(dataDir,win)

animals = {'CS31','CS33','CS34','CS35'};
cellareas = {'CA1','PFC'};
betaareas = {'CA1','PFC','OB'};

for s = 1:length(cellareas)
    cellarea = cellareas{s};
    load([dataDir,'cellSelectivityData_',cellarea,'_',num2str(-win(1)*1000),'-',num2str(win(2)*1000),'ms.mat']);
    z = vertcat(cellSelectivity.zscore);
    selectiveCells = cellSelectivity(abs(z) > 2); %find cells that are selective
    selInd = vertcat(selectiveCells.cellindex);
    for a = 1:length(animals) %create cell index that includes animal
        an = animals{a};
        selanimals = {selectiveCells.animal}';
        animalinds(find(strcmp(selanimals,an))) = a;
    end
    selInd = [animalinds', selInd];
    clear animalinds 
    
    betaModIndAll = [];
    for b = 1:length(betaareas)
        betaarea = betaareas{b};
        load([dataDir,'betaModv2_',betaarea,'.mat'])
        eval(['betaMod = betaMod_',cellarea,'cells;']);
        eval(['clear betaMod_*;'])
        
        p = vertcat(betaMod.prayl); %find cells that are beta modulated
        betaModCells = betaMod(p < 0.05);
        
        
        betaModInd = vertcat(betaModCells.index);
        modanimals = {betaModCells.animal}';
        for a = 1:length(animals) %create index that includes animal
            an = animals{a};
            animalinds(find(strcmp(modanimals,an))) = a;
        end
        betaModIndAll(end+1:end+length(animalinds),1:4) = [animalinds', betaModInd];
        clear animalinds
    end
    
    betaModIndAll = unique(betaModIndAll,'rows');

    phaseLockedSelectiveCells = selectiveCells(ismember(selInd, betaModIndAll, 'rows'));
    indswithanimal = intersect(selInd, betaModIndAll, 'rows');
    [phaseLockedSelectiveCells.indWithAnimal] = deal(indswithanimal);
    
    fractionOverlap = length(phaseLockedSelectiveCells)/length(selInd);
    
    save([dataDir,'phaseLockedSelectiveCells_',cellarea,'.mat'],'phaseLockedSelectiveCells','fractionOverlap');
    
end
