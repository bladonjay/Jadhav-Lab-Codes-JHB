function [template] = createepochtemplate(prefix)

topRawDir= ['E:\Data\OdorPlaceAssociation\',prefix,'\'];

cd(topRawDir);
rawDir=dir();
   rawDir= {rawDir(3:end).name};
numDays= length(rawDir);

template =[];
for d = 1:numDays
    dirname = rawDir{1,d};
    
    cd([topRawDir,dirname])

    files = dir('*.rec');
    numEpochs = length(files);
    
    daytemplate = [];
    for ep = 1:numEpochs
        daytemplate(ep,:) = [d,ep];
    end
    
    template = [template; daytemplate];
    
    clear daytemplate
end

dataDir = ['E:\Data\OdorPlaceAssociation\',prefix,'_direct\'];
cd(dataDir)

filename = [dataDir,prefix,'epochtemplate'];
save(filename, 'template')
