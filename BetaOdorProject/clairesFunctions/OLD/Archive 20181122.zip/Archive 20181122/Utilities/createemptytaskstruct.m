function createemptytaskstruct(directoryname,fileprefix, index, runeps)
%creates task struct without linear coord position data 

%index -- matrix where each row represents a different epoch, 1st column is
%day, 2nd column is epoch

%Assign run epochs by input argument, all other epochs are assigned sleep
%by default

cd(directoryname);

% load([fileprefix,'epochtemplate.mat'])
% index = template;

days = unique((index(:,1)),'rows');

for i = 1:size(index(:,1))
    
    for d = 1:size(days)    
        day = days(d);
            
                daystr = getTwoDigitNumber(day);

                dayrows = find(index(:,1) == day);
                epochs = index(dayrows,2);
                
                for e = 1:length(epochs)
                    epoch = epochs(e);
                    
                    if ismember(epoch, runeps)
                        epochtype = 'run';
                    else
                        epochtype = 'sleep';
                    end
                
                    task{1,day}{1,epoch}.type = epochtype;
                end


        savename = [directoryname,filesep,fileprefix,'task',daystr];
        save(savename, 'task');

        clear task
    end
end
