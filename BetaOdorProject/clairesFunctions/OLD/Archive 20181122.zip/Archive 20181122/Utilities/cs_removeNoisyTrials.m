%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Claire - Feb 2017
% Loads trigger times file, and finds the raw eeg within time window around
% each trigger. Excludes any trigger times from the trigger file in which there is a
% large jump in voltage and saves new trigger time list as new file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [goodTrials] = cs_removeNoisyTrials(prefix, days, epochs, tet, trigtype, timewin, do_wrtgnd) 

%directoryname = ['E:\Data\OdorPlaceAssociation\', prefix, '_direct\'];
directoryname = ['D:\OdorPlaceAssociation\', prefix, '_direct\'];
cd(directoryname);

tetstring = getTwoDigitNumber(tet);

for d = 1:length(days)
    day = days(d);
    daystring = getTwoDigitNumber(day);

    for e = 1:length(epochs)
        epoch = epochs(e);
        epochstring = getTwoDigitNumber(epoch);
        
        if exist([prefix,'eeg',daystring,'-',epochstring,'-',tetstring,'.mat']) == 2 
            %added this so it won't error out if different number of epochs on different days
        
            % % Load EEG File
            if do_wrtgnd == 1

                    EEGfile = load([prefix, 'eeg', daystring, '-', epochstring, '-', tetstring, '.mat']);
                    eegdata = EEGfile.eeg{1,day}{1,epoch}{1,tet}.data;
                    starttime = EEGfile.eeg{1,day}{1,epoch}{1,tet}.starttime;
                    endtime = EEGfile.eeg{1,day}{1,epoch}{1,tet}.endtime;
                    samprate = EEGfile.eeg{1,day}{1,epoch}{1,tet}.samprate;

            else
                    EEGfile = load([prefix, 'eegref', daystring, '-', epochstring, '-', tetstring, '.mat']);
                    eegdata = EEGfile.eegref{1,day}{1,epoch}{1,tet}.data;
                    starttime = EEGfile.eegref{1,day}{1,epoch}{1,tet}.starttime;
                    endtime = EEGfile.eegref{1,day}{1,epoch}{1,tet}.endtime;
                    samprate = EEGfile.eegref{1,day}{1,epoch}{1,tet}.samprate;
            end
            
        
            eegtimes = [starttime:(1/samprate):endtime]';
            
            % % Load Triggers File
            
            cd(directoryname)
            load([prefix,'odorTriggers', daystring '.mat']);
            
            switch trigtype
                case 'odor'
                    %trigfile = load(['odorTriggers', daystring, '-', epochstring, '.mat']);
                    
                    %triggers = trigfile.OdorTriggers_all;
                    triggers = odorTriggers{1,day}{1,epoch}.allTriggers;
                case 'novelodor'
                    trigfile = load(['OdorTriggers', daystring, '-', epochstring, '.mat']);
                    triggers = trigfile.OdorTriggers_all;
                case 'reward'
                    rewardfile = load(['RewardTimes', daystring, '-', epochstring, '.mat']);
                    triggers = rewardfile.RewardTimes;
                case 'corrTrigs'
%                     corrtrigfile = load(['corrTrigs', daystring, '-', epochstring, '.mat']);
%                     triggers = corrtrigfile.CorrectTrialTriggers;
                    triggers = odorTriggers{1,day}{1,epoch}.correctTriggers;
                case 'incorrTrigs'
%                     incorrtrigfile = load(['incorrTrigs', daystring, '-', epochstring, '.mat']);
%                     triggers = incorrtrigfile.IncorrectTrialTriggers;
                    triggers = odorTriggers{1,day}{1,epoch}.incorrectTriggers;
            end


            goodTrials = [];
            for t = 1:length(triggers) 
                trigtime = triggers(t);
                triggeredTimeWindowStart = trigtime - timewin(1,1);
                triggeredTimeWindowEnd = trigtime + timewin(1,2);
                triggeredEEGtimes = eegtimes(eegtimes>triggeredTimeWindowStart & eegtimes<triggeredTimeWindowEnd);
                eegTimeInds = find(eegtimes>triggeredTimeWindowStart & eegtimes<triggeredTimeWindowEnd);
                triggeredEEG = eegdata(eegTimeInds);

                last = triggeredEEG(2:end);
                first = triggeredEEG(1:end-1);
                diff = last - first;
                
                %Finds times where there is a large jump between adjacent
                %eeg times - (probably noise)
                bad = find(abs(diff) > 1000); %can change this threshold if necessary

                if isempty(bad), %if there are no large jumps, keep this trial
                    goodTrials(end+1,1) = trigtime;
                end
            end

        %save(['Good_OdorTriggers',daystring, '-', epochstring],'goodTrials');
        end
    end
        

end
