low = 10;
high = 40;

srate = 1500;
d = designeegfilt(srate,low,high);
kernel = d;
lowgammafilter.kernel = kernel;
lowgammafilter.samprate = srate;
lowgammafilter.descript = [num2str(low),'-',num2str(high),' Hz low gamma / beta filter'];
filterfile = ['E:\DataAnalysis\cs_analysis\lowgammafilter.mat'];
save(filterfile, 'lowgammafilter');