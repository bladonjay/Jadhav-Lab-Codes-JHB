function createtriggerstruct(directoryname,fileprefix, days, runepochs)

cd(directoryname);

behavdirect = [directoryname,'\Behavior\'];



for d = 1:length(days)
    cd(behavdirect)
    triggers_all = [];
    day = days(d);
    daystring = getTwoDigitNumber(day);
    
    OdorTriggers = dir(['OdorTriggers',daystring,'*.mat']);
    CorrTrigs = dir(['CorrTrigs',daystring,'*.mat']);
    IncorrTrigs = dir(['IncorrTrigs',daystring,'*.mat']);
    
    for ep = 1:length(OdorTriggers)
        epoch = runepochs(ep);
        odor = load(OdorTriggers(ep).name);
        corr = load(CorrTrigs(ep).name);
        incorr = load(IncorrTrigs(ep).name);
        
        odortriggers = odor.OdorTriggers_all;
        corrtriggers = corr.CorrectTrialTriggers;
        incorrtriggers = incorr.IncorrectTrialTriggers;
        
        odortriggers{day}{epoch} = odortriggers;
        eventtriggers{day}{epoch}.corrtriggers = corrtriggers;
        eventtriggers{day}{epoch}.incorrtriggers = incorrtriggers;
    end
    
    cd(directoryname)
    
    savename = [directoryname,filesep,fileprefix,'eventtriggers',daystring];
    save(savename, 'eventtriggers');
     
    clear eventtriggers
    
end