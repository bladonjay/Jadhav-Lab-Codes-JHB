function cs_cellSelectivityBins(triggeredSpikingFile)

figdir = 'E:\Figures\';

load(triggeredSpikingFile)

allanimals = triggeredSpiking.data;
region = triggeredSpiking.region;

win = triggeredSpiking.win;
binsize = triggeredSpiking.binsize;
bins = (-win(1):binsize:win(2));
%binsaftertrig = find(bins>=0);

winstr = ['_',num2str(-win(1)*1000), '-',num2str(win(2)*1000),'ms'];

%eventually all cells from all animals will go into a single data
%structure, keeps track of how many cells have been done


iterations = 1000; 
for b = 1:length(bins)
    totalspikingcells = 0; 
    totalcells = 0;
    binSI = [];
%----- Loop over animals -----%
for a = 1:length(allanimals)
    animal = triggeredSpiking.data(a).animal{1,1};
    allSpikingData = allanimals(a).output{1,1};
    allSI = [allSpikingData.selectivityIndex]';
    totalcells = totalcells + length(allSI);
    
    
    %only use cells that had high enough firing rates. This threshold is
    %set when generating TriggeredSpiking files in
    %DFAcs_odorSelectivityPSTH.m
    goodCellIndx = find(~isnan(allSI)); 
    
%----- Go through all cells and make a shuffled distribution for each one -----% 
    for c = 1:length(goodCellIndx)
        totalspikingcells = totalspikingcells +1;
        cellnum = goodCellIndx(c);
        
        Lspikes = allSpikingData(cellnum).psthleftTriggers(:,b);
        Rspikes = allSpikingData(cellnum).psthrightTriggers(:,b);
        
        
        LtrigFR = Lspikes/binsize;
        RtrigFR = Rspikes/binsize;
        
        meanLtrigFR = mean(LtrigFR);
        meanRtrigFR = mean(RtrigFR);
        
        selectivityIndex = (meanLtrigFR - meanRtrigFR)/(meanRtrigFR + meanLtrigFR);
        
       
        cellindex = allSpikingData(cellnum).index;
        
        
        leftones = ones(length(Lspikes),1);
        rightzeros = zeros(length(Rspikes),1);
        
        indicators = [leftones;rightzeros]; %make one list of 1's and 0's to shuffle
        allTrials = [LtrigFR; RtrigFR];
        

%----- Do the shuffle -----%
      shuffIndexDist = zeros(iterations,1);
        for i = 1:iterations
            shuffledRL = indicators(randperm(length(indicators)));
            newLeft = mean(allTrials(shuffledRL == 1));
            newRight = mean(allTrials(shuffledRL == 0));
            
            newIndex = (newLeft - newRight)/(newLeft + newRight);
            shuffIndexDist(i) = newIndex;
        end
        
        shuffMean = mean(shuffIndexDist);
        shuffStd = std(shuffIndexDist);
        
        trueIndexZ = (selectivityIndex - shuffMean)/shuffStd;
        
        binSI(totalspikingcells,1) = trueIndexZ; 
        
    end
end

allBinsSI(:,b) = binSI;
end
totalNumSelective = 0;
binFractions = zeros(1,length(bins)-1);
for b = 1:length(bins)-1
    selectiveCellsBin = find(abs(allBinsSI(:,b)) >= 2);
    allBinsSI(selectiveCellsBin,:) = [];
    numInBin = length(selectiveCellsBin);
    totalNumSelective = totalNumSelective+numInBin;
    fractionSelectiveBin = totalNumSelective/totalspikingcells;
    binFractions(1,b) = fractionSelectiveBin;
end
    

% for b = 1:length(bins)-1
%     selectiveCellsBin = find(abs(allBinsSI(:,b)) >= 2);
%     
%     fractionSelectiveBin = length(selectiveCellsBin)/totalspikingcells;
%     binFractions(1,b) = fractionSelectiveBin;
% end

newbins = bins(1:end-1)+(binsize/2);

figure, hold on
switch region
    case 'PFC'
        bar(newbins(2:end),binFractions(2:end), 'FaceColor', [rgb('DodgerBlue')], 'LineWidth',2, 'EdgeColor',[rgb('MidnightBlue')])
    case 'CA1'
        bar(newbins(2:end),binFractions(2:end), 'FaceColor', [rgb('Crimson')], 'LineWidth',2, 'EdgeColor',[rgb('DarkRed')])
end
axis([0 (bins(end-1)+0.1) 0 0.6]);

xticks([0 0.1 0.2 0.3 0.4 0.5])
xlabel('Time from odor onset (seconds)');
ylabel('Fraction odor selective cells');

set(gca,'fontsize',20);

set(gcf, 'Position', [2000 350 900 600]);

figtitle = ['selectivityFractionsBins_',region];

newfigfile = [figdir,'NicePPTFigures\',figtitle];
saveas(gcf,newfigfile,'fig');
print('-dpng', newfigfile);

end