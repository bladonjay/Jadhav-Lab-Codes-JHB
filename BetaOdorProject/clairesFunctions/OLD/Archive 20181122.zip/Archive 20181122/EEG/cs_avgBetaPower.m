function cs_avgBetaPower(animals, topDir, regions)

for a = 1:length(animals)
    animal = animals{a};
    dataDir = [topDir, animal, 'Expt\', animal, '_direct\'];
    load([dataDir, animal, 'tetinfo.mat'])
    
    dayfiles = dir([dataDir, animal, 'runTrialBounds*']);
    
    for r = 1:length(regions)
        region = regions{r};
        
        for d = 1:length(dayfiles)
            day = days(d);
            load(dayfiles(d).name);
            runTrialBounds = runTrialBounds{1,day};
            epochs = find(~cellfun(@isempty, runTrialBounds));
        
            for ep = 1:length(epochs)
                epoch = epochs(ep);
                tetfilter = ['((strcmp($area, ''',region,''')) && (strcmp($descrip2, ''betatet'')))'];
                tets = evaluatefilter(tetinfo{1,day}{1,epoch}, tetfilter);
                
                betaPowerAllTets = [];
                for t = 1:length(tets)
                    tet = tets(t);
                    tetstr = getTwoDigitNumber(tet);
                    
                    
                end
            end
        end
        
            
    end
end