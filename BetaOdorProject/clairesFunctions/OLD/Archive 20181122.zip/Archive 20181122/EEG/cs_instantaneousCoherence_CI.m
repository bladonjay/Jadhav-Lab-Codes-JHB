function cs_instantaneousCoherence_CI(animals, topDir, regions, figDir)

%for each pair of regions, calculate instantaneous coherence 200ms after
%trigger- across all epochs and animals

for r = 1:length(regions)
    region = regions{r};
    
    c_allData = [];
    i_allData = [];
    
    for a = 1:length(animals)
        animal = animals{a};
        
        coherencefiles = dir([topDir,animal,'Expt\',animal,'_direct\',animal,'coherence',region,'*']);
        odorfiles = dir([topDir,animal,'Expt\',animal,'_direct\',animal,'odorTriggers*']);
        
        for d = 1:length(coherencefiles)
            day = d; 
            load([topDir,animal,'Expt\',animal,'_direct\',coherencefiles(d).name])
            load([topDir,animal,'Expt\',animal,'_direct\',odorfiles(d).name])
            
            coherence = coherence{1,d};
%             pos = pos{1,d};
            odorTriggers = odorTriggers{1,d};
            epochs = find(~cellfun(@isempty, coherence));
            
            for ep = 1:length(epochs)
                epoch = epochs(ep);
                cohtimes = coherence{1,epoch}.time;
                freqs = coherence{1,epoch}.freqs;
                coherence_tmp = coherence{1,epoch}.coherence;
                c_trigs = odorTriggers{1,epoch}.correctTriggers;
                i_trigs = odorTriggers{1,epoch}.incorrectTriggers;
                
                c_trigs = c_trigs+0.2; %200ms after trigger
                i_trigs = i_trigs+0.2;
                
                c_trigsinds = find(cohtimes == c_trigs);
                i_trigsinds = find(cohtimes == i_trigs);
               
                %find index of nearest coherence times to trigger times
                TMP = bsxfun(@(x,y) abs(x-y), c_trigs(:), reshape(cohtimes,1,[]));
                [~, indx] = min(TMP,[],2) ;
                c_newCoh = coherence_tmp(:,indx);
                
                TMP = bsxfun(@(x,y) abs(x-y), i_trigs(:), reshape(cohtimes,1,[]));
                [~, indx] = min(TMP,[],2) ;
                i_newCoh = coherence_tmp(:,indx);
                
                c_allData = [c_allData, c_newCoh];
                i_allData = [i_allData, i_newCoh];
            end
        end
                
    
    end
    c_mean = mean(c_allData,2)';
    c_sem = std(c_allData,0,2)/sqrt(size(c_allData,2));
    
    i_mean = mean(i_allData,2)';
    i_sem = std(i_allData,0,2)/sqrt(size(i_allData,2));
    
    mn = [c_mean; i_mean];
    sem = [c_sem'; i_sem'];
    
    uE = mn + sem;
    lE = mn - sem;
    yP = [lE,fliplr(uE)];
    xP=[freqs,fliplr(freqs)];
    
    
    figure, hold on
    plot(freqs, c_mean, 'b-');
    plot(freqs, i_mean, 'r-');
    
    patch(xP,yP(1,:),1, 'facecolor', 'b', 'edgecolor','none', 'facealpha',0.2)
    patch(xP,yP(2,:),1, 'facecolor', 'r', 'edgecolor','none', 'facealpha',0.2)
    
    title(region)
    xlabel('Frequency (Hz)')
    ylabel('Coherence')
    legend({'Correct','Incorrect'})
    
    figfile = [figDir,'2b_CohAsFuncOfFreq_CorrIncorr_',region];
    print('-djpeg', figfile);
    print('-dpng', figfile);
    saveas(gcf,figfile,'fig');
end



