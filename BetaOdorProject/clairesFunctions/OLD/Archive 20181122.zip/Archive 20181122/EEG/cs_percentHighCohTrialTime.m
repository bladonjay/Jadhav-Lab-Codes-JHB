function cs_percentHighCohTrialTime(topDir, animals, regions, figDir)

for r = 1:length(regions)
    region = regions{r};
    
    highbetatimes_odorwin = [];
    Nhighbetaepochs = 0;
    for a = 1:length(animals)
        allbetatrigtimes = [];
        animal = animals{a};
        
        coherencefiles = dir([topDir,animal,'Expt\',animal,'_direct\',animal,'coherence',region,'*']);
        
        for d = 1:length(coherencefiles)
            day = d; 
            load([topDir,animal,'Expt\',animal,'_direct\',coherencefiles(d).name])
            load([topDir,animal,'Expt\',animal,'_direct\',animal,'odorTriggers',getTwoDigitNumber(d),'.mat']);
            
            coherence = coherence{1,d};
            epochs = find(~cellfun(@isempty, coherence));
            for ep = 1:length(epochs)
                
                epoch = epochs(ep);
                
                betaFreqs = find((coherence{1,epoch}.freqs > 15) & (coherence{1,epoch}.freqs < 35));
                betaCoh = coherence{1,epoch}.coherence(betaFreqs,:);
                betaCoh = mean(betaCoh,1);
                epochmean = mean(betaCoh);
                epochstd = std(betaCoh);
                
                binlength = 1/coherence{1,epoch}.binlength;
                N = 0.1/binlength; %number of samples in 100ms bins
                meanbins = arrayfun(@(x) mean(betaCoh(x:x+N-1)),1:N:length(betaCoh)-N+1)';
                bintimes = coherence{1,epoch}.time(1:N:length(coherence{1,epoch}.time)-N+1);
                
                     if length(meanbins) < length(bintimes)% check if time vectors are matched
                            bintimes = bintimes(1:length(meanbins));
                     end
                
                highbetabins = find(meanbins >= (2*epochstd)+epochmean);
                highbetatimes = bintimes(highbetabins);
                
                triggers = odorTriggers{d}{epoch}.allTriggers;
                timewins = [triggers - 1, triggers + 2];
                
                
                for t = 1:length(triggers)
                    highbetainwin = highbetatimes(highbetatimes >= timewins(t,1) & highbetatimes < timewins(t,2));
                    adjustedtimes = highbetainwin - triggers(t);
                    
                    highbetatimes_odorwin = [highbetatimes_odorwin, adjustedtimes];
                    
                end    
                %Nhighbetaepochs = Nhighbetaepochs + length(highbetatimes);
                
                
            end
            
        end
        
    end
    hist = histcounts(highbetatimes_odorwin,(timewins(1,1):binlength:timewins(1,2))-triggers(1));
    Nhighbetaepochs = length(highbetatimes_odorwin);
    percentage = hist/Nhighbetaepochs;
    %create "histogram" to determine how many high beta times occur within
    %each bin around trigger window
    
    
end
%load coherence files
%take only beta band
%split into 100ms bins, save start times for bins
%find mean coh in each bin
%find mean and std across whole epoch
%find bins that are 2std above mean
%load odor trigger files
%find all bins that occur in window around odor trigger
%assign each bin to bin in window
%histogram? 