
function cs_detectOscillatoryEpisodes(topDir, animals, regions)

for a = 1:length(animals)
    animal = animals{a};
    
    dataDir = [topDir,animal,'Expt\',animal,'_direct\'];
    cd(dataDir)
    
    %get tetinfo file
    tetinfofile = dir([animal,'tetinfo.mat']);
    load(tetinfofile.name);
    
    trigfiles = dir([animal,'odorTriggers*']);
    trigfiles = {trigfiles.name};
    
    for f = 1:length(trigfiles)
        load(trigfiles{f});
        day = length(odorTriggers);
        daystr = getTwoDigitNumber(day);
        epochs = find(~cellfun(@isempty,odorTriggers{1,day}));
        
        disp(['Doing ', animal,' Day', daystr]); 
       for e = 1:length(epochs)
            epoch = epochs(e);
            triggers = odorTriggers{1,day}{1,epoch}.allTriggers;
        
            for r = 1:length(regions)
               region = regions{r};
               tetfilter = ['((strcmp($area, ''',region,''')) && (strcmp($descrip2, ''betatet'')))'];
               tets = evaluatefilter(tetinfo{1,day}{1,epoch}, tetfilter);
               
               epstr = getTwoDigitNumber(epoch);
               
               for t = 1:length(tets)
                   tet = tets(t);
                   tetstr = getTwoDigitNumber(tet);
                   load([dataDir,'EEG\',animal,'beta',daystr,'-',epstr,'-',tetstr,'.mat']);
                   beta = beta{day}{epoch}{tet};
                   betatimes = [beta.starttime:1/beta.filtersamprate:beta.endtime]';
                   betaphaseAllTets(:,t) = double(beta.data(:,2));
                   betaAllTets(:,t) = double(beta.data(:,3));
               end
               
               meanBetaPhase = mean(betaphaseAllTets,2);
               meanBetaPower = mean(betaAllTets,2); 
               stdBetaPowerEpoch = std(meanBetaPower);
               meanBetaPowerEpoch = mean(meanBetaPower);
               
               
               Fs = beta.samprate;
               
               highbetaepisodes = []; wininds =[]; wintimes = [];
               highbeta_region = [];
               episodeinds = [];
               for tr = 1:length(triggers)
                   trigger = triggers(tr);
%                    baselinetimes = [(trigger - 0.5), trigger];
%                    baselinebeta = betaAllTets(betatimes > baselinetimes(1) & betatimes < baselinetimes(2));
%                    meanBaseline = mean(baselinebeta);
%                    stdBaseline = std(baselinebeta);
                   
                   odortime = [trigger - 1, trigger + 2];
                   trigbeta = meanBetaPower(betatimes > odortime(1) & betatimes < odortime(2),:);
                   betaind = find(betatimes > odortime(1) & betatimes < odortime(2));
                   %trigbetaphase = betaphaseAllTets(betatimes > odortime(1) & betatimes < odortime(2),:);
                   trigbetatimes = betatimes(betatimes > odortime(1) & betatimes < odortime(2));
                   
                   %meanbeta = mean(trigbeta,2);
                   %meanbeta = filter(ones(1,250)/250, 1, meanbeta); %avg across 250 datapoints to smooth
                   
                   highbetaind = betaind(trigbeta > (meanBetaPowerEpoch+2*(stdBetaPowerEpoch)),1); %gets the index for entire epoch
                   
                   if ~isempty(highbetaind)
                        for b = 1:length(highbetaind)
                            betawin(1) = highbetaind(b) - Fs*0.08;
                            betawin(2) = highbetaind(b) + Fs*0.08;
                            
                            highbetaepisodes = [highbetaepisodes; meanBetaPower(betawin(1):betawin(2))'];
                            wininds = [wininds; betawin(1):betawin(2)];
                            wintimes = [wintimes; betatimes(betawin(1): betawin(2))'];
                            
                        end
                   end
                   
                   if ~isempty(highbetaepisodes)
                       [maxima, m_ind] = max(highbetaepisodes, [], 2);
                       [highbetavals, u_ind] = unique(maxima,'stable');
                       wintimes_unique = wintimes(u_ind, :);
                       winind_unique = wininds(u_ind,:);
                       linearInd = sub2ind(size(wintimes_unique),[1:length(u_ind)]',m_ind(u_ind));
                       highbetatimes = wintimes_unique(linearInd);
                       highbetaind = winind_unique(linearInd);
                       
                       %separate into distinct episodes with at least 100ms
                       %between them
                       winstart = highbetatimes(1);
                       for p = 1:length(highbetatimes)
                           timepoint = highbetatimes(p);
                           win = [timepoint, timepoint + 0.1]; %look 100ms ahead
                           closepoints = find((highbetatimes > win(1)) & (highbetatimes <= win(2)));
                           if isempty(closepoints)
                               winend = win(1);
                               chunk = [winstart, winend];
                               chunkvals = highbetavals((highbetatimes >= winstart) & (highbetatimes <= winend));
                               chunkmax = max(chunkvals);
                               episodeind = highbetaind(highbetavals == chunkmax);
                               episodeinds = [episodeinds; episodeind]; %finds epoich-wide index of timepoints of high beta instances
                               %find local maximum in this chunk
                               
                               if p < length(highbetatimes)
                                    winstart = highbetatimes(p+1);
                               end 
                           end
                       end
                   end     
               end
               highBetaEpisodes = [betatimes(episodeinds)-0.2, betatimes(episodeinds)+0.2]; %create 400ms windows around beta maxima
               
               highBetaTemp.(region) = highBetaEpisodes;
               betaPhaseTemp.(region) = [betatimes, meanBetaPhase];
               
               clear betaAllTets
               clear betaphaseAllTets
               
               
            end
            betaPhase{1,day}{1,epoch} = betaPhaseTemp;
            highBeta{1,day}{1,epoch} = highBetaTemp;
            
       end
       
       
       
    end
    
    filename = [animal,'highBeta'];
    save([dataDir,filename],'highBeta')
    clear highBeta
    
    filename = [animal,'betaPhase'];
    save([dataDir,filename],'betaPhase')
    clear betaPhase
end