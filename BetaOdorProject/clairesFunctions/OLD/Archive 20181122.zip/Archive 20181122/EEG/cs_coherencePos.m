function cs_coherencePos(animals, topDir, regions, figDir)

for r = 1:length(regions)
    region = regions{r};
    
    allData = [];
    
    for a = 1:length(animals)
        animal = animals{a};
        
        coherencefiles = dir([topDir,animal,'Expt\',animal,'_direct\',animal,'coherence',region,'*']);
        posfiles = dir([topDir,animal,'Expt\',animal,'_direct\',animal,'pos*']);
        
        for d = 1:length(coherencefiles)
            day = d; 
            load([topDir,animal,'Expt\',animal,'_direct\',coherencefiles(d).name])
            load([topDir,animal,'Expt\',animal,'_direct\',posfiles(d).name])
            
            coherence = coherence{1,d};
            pos = pos{1,d};
            epochs = find(~cellfun(@isempty, coherence));
            
            for ep = 1:length(epochs)
                
                epoch = epochs(ep);
                betaFreqs = find((coherence{1,epoch}.freqs > 15) & (coherence{1,epoch}.freqs < 30));
                meanBetaCoh = mean(coherence{1,epoch}.coherence(betaFreqs,:));
                
                cohTimes = coherence{1,epoch}.time;
                posTimes = pos{1,epoch}.data(:,1);
                newPos = round(pos{1,epoch}.data(:,2:3)); %round to 1cm bins
                
                %frame rate for pos is much slower than samp rate for coherence.
                %Interpolate to get new beta power. 
                interpCoh = interp1(cohTimes, meanBetaCoh, posTimes');

                meanCohPos = accumarray(newPos+1,interpCoh,[],@mean);
                [xsize] = max([size(meanCohPos,1), size(allData,1)]);
                [ysize] = max([size(meanCohPos,2), size(allData,2)]);
                
                %put new data in the middle of existing matrix, padded with
                %zeros on edges.
                meanCoh_adjusted = zeros(xsize,ysize);
                xstart = round((xsize - size(meanCohPos,1))/2)+1;   
                ystart = round((ysize - size(meanCohPos,2))/2)+1;
                meanCoh_adjusted(xstart:(xstart+size(meanCohPos,1)-1), ystart:(ystart+size(meanCohPos,2)-1)) = meanCohPos;
                
                allData_adjusted = zeros(xsize,ysize,size(allData,3));
                xstart = round((xsize - size(allData,1))/2)+1;   
                ystart = round((ysize - size(allData,2))/2)+1;
                allData_adjusted(xstart:(xstart+size(allData,1)-1), ystart:(ystart+size(allData,2)-1),:) = allData;
                
                
                allData_adjusted(:,:,size(allData_adjusted,3)+1) = meanCoh_adjusted;
                allData = allData_adjusted;
                    
                
                        
            end
                
        end
    end
    allData = mean(allData,3);
    std = 2; g = gaussian2(std,(4*std)); 
    smoothedData = filter2(g,(allData)); % 
    
    figure,
    imagesc(smoothedData)
    colormap(jet)
    title(region)
    colorbar
    
    figfile = [figDir,'1f_BetaCohPos_',region];

    print('-djpeg', figfile);
    print('-dpng', figfile);
    saveas(gcf,figfile,'fig');
end

%for each region, for each animal, for each epoch(?) load pos, load betapower

% interpolate (?) pos times with beta times

%plot in a similar way to place fields - occupancy normalized? 