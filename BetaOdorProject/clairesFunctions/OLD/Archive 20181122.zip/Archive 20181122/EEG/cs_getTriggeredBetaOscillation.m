function cs_getTriggeredBetaOscillation(dataDir, animal, day, epoch, tet, trial)

daystr = getTwoDigitNumber(day);
epochstr = getTwoDigitNumber(epoch);
tetstr = getTwoDigitNumber(tet);

load([dataDir, 'EEG\',animal,'beta',daystr,'-',epochstr,'-',tetstr,'.mat']);
beta = beta{1, day}{1, epoch}{1, tet}  ;
load([dataDir, animal, 'odorTriggers', daystr, '.mat'])
odorTriggers = odorTriggers{1, day}{1, epoch}.correctTriggers  ;

trigger = odorTriggers(trial);

window = [1.5 1.5];
start = trigger-window(1);
stop = trigger+window(1);

timerange = beta.timerange;
betatime = [timerange(1):1/1500:timerange(2)];
betatime = betatime';

betaamp = beta.data(:,1);
betaamp = double(betaamp);

betatimes = (betatime >= start & betatime<= stop);
betainwin = betaamp(betatimes);

stop = stop-trigger;
start = start-trigger;
windowtimes = [start:1/1500:stop];
windowtimes = windowtimes(1:end-1);

figure
plot(windowtimes,betainwin, 'k','LineWidth',2);
hold on
plot([0 0], [-1000 1000], 'r--','LineWidth',2);

set(gcf, 'Position', [2000 400 900 600]);
                set(gca,'fontsize',20);
box off

xlabel('Time (seconds)');
ylabel('Beta amplitude (mV)');
end
