%% METADATA

% have Trodes, usrlocal, Src_matlab, matclust, TrodesToMatlab, and Pipeline in path
% To extract matclust files for clustering, run createAllMatclustFiles.m (located in TrodesToMatlab)

% path and animal metadata
topRawDir= 'E:\Data\OdorPlaceAssociation\CS15\'; % raw directory (contains one folder for each day of an experiment ONLY)
dataDir= 'E:\Data\OdorPlaceAssociation\CS15_direct\';    % data directory
animID= 'CS15';     % your animals name

% tetrode metadata (which tetrode is in which area, which is reference)
 hpc   = [2 3 4 12 13 14 15 16 17 18 19 20 21 22 25 27 28 29];
 Ref=  26;
 ppc   = [1 7 8 9 10 23 30 31 32];
 Ref=   26; 
 
 % experiment metadata
 cd(topRawDir);
 rawDir=dir();
    rawDir= {rawDir(3:end).name};
 numDays= length(rawDir);
 % The above code assumes raw directory contains one folder for each day of experiment ONLY

 %% DAY DEPENDENT NON EEG- pos, lfp, spikes, dio, task, linpos
 for sessionNum=1:numDays;
     
     % CONVERT RAW DATA TO BASIC FF DATA
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     % TO DO: add mcz_posinterp vargin to mcz_createNQPosFiles
     % TO DO: test frame pulsing for more accurate position
     % mcz_createNQPosFiles_diodeNumChanges(   [topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum)
     % mcz_createNQPosFiles( rawDir{sessionNum}, dataDir, animID, sessionNum, dioFramePulseChannelName)
     %mcz_createNQLFPFiles( [topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum)
     %mcz_createNQSpikesFiles(rawDir{sessionNum}, dataDir, animID, sessionNum)
     %mcz_createNQDIOFiles(   [topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum)
     %mcz_createNQDIOFilesFromStateScriptLogs(rawDir{sessionNum}, dataDir, animID, sessionNum)
     
     % FF BEHAVIOR METADATA STRUCTURES
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %createtaskstruct(   dataDir,animID, [sessionNum #; sessionNum #], 'getcoord_wtrack');
     %sj_updatetaskstruct(dataDir,animID,sessionNum,[#], 'sleep');
     %sj_updatetaskenv(   dataDir,animID,sessionNum,[#], 'wtr1');
     %sj_updatetaskenv(   dataDir,animID,sessionNum,[#], 'wtr2');
     
     % FF SECONDARY DATA STRUCTURES
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %sj_lineardayprocess(dataDir,animID,sessionNum,'welldist',15)
     
 end
 %% DAY INDEPENDENT- cellinfo, tetinfo
 
 % FF CELL AND TET METADATA STRUCTURES
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %createtetinfostruct(dataDir,animID);
 %mcz_createcellinfostruct(dataDir,animID);
 
 % CELL AND TET METADATA POPULATION
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 sj_addtetrodedescription(dataDir,prefix,riptetlist,'riptet');
%  sj_addtetrodelocation(dataDir,animID,hpc,'CA1');
%  sj_addtetrodelocation(dataDir,animID,ppc,'PPC');
%  sj_addtetrodedescription(dataDir,animID,Ref,'Ref');
 %sj_addtetrodedescription(dataDir,animID,pfcRef,'PFCRef');
 %sj_addcellinfotag2(dataDir,animID);

 %% EEG PRIMARY PIPELINE
 
%refData -- an EX32 matrix with the local reference for each tetrode, where
%unused or reference tetrodes have a ref of zero. E is 1:total # of epochs
% TODO- add changes over days? 
 
% filtering/filter path


% filtPath= ['C:\Users\csymansk\Documents\MATLAB\DataAnalysis\usrlocal\filtering\'];
% 
 for sessionNum=1:numDays;
%     
% refData(1,:)=[26 26 26 26 0 0 26 26 26 26 0 0 0 0 26 26 26 26 26 26 26 26 26 0 26 26 26 26 26 26 26 26];
% refData(2,:)=[26 26 26 26 0 0 26 26 26 26 0 0 0 0 26 26 26 26 26 26 26 26 26 0 26 26 26 26 26 26 26 26];
% refData(3,:)=[26 26 26 26 0 0 26 26 26 26 0 0 0 0 26 26 26 26 26 26 26 26 26 0 26 26 26 26 26 26 26 26];
% refData(4,:)=[26 26 26 26 0 0 26 26 26 26 0 0 0 0 26 26 26 26 26 26 26 26 26 0 26 26 26 26 26 26 26 26];
% refData(5,:)=[26 26 26 26 0 0 26 26 26 26 0 0 0 0 26 26 26 26 26 26 26 26 26 0 26 26 26 26 26 26 26 26];
% refData(6,:)=[26 26 26 26 0 0 26 26 26 26 0 0 0 0 26 26 26 26 26 26 26 26 26 0 26 26 26 26 26 26 26 26];
% refData(7,:)=[26 26 26 26 0 0 26 26 26 26 0 0 0 0 26 26 26 26 26 26 26 26 26 0 26 26 26 26 26 26 26 26];
% 
%      mcz_createRefEEG([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, refData);
%      % EEG wrt ground only
%   mcz_deltadayprocess([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, 'f', [filtPath 'deltafilter.mat']);
%   mcz_thetadayprocess([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, 'f', [filtPath 'thetafilter.mat']);
%      % EEG wrt ground and local reference
%   mcz_gammadayprocess([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, 'f', [filtPath 'gammafilter.mat']);
%  mcz_rippledayprocess([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, 'f', [filtPath 'ripplefilter.mat']);
%  
 end 
