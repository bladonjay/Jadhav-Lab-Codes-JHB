ExtractAll('SG7Expt','SG7')

Preprocess_SG7