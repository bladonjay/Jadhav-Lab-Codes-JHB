%% METADATA

% have Trodes, usrlocal, Src_matlab, matclust, TrodesToMatlab, and Pipeline in path
% To extract matclust files for clustering, run createAllMatclustFiles.m (located in TrodesToMatlab)

% path and animal metadata
topRawDir= 'D:\OdorPlaceAssociation\EK2Expt\EK2\'; % raw directory (contains one folder for each day of an experiment ONLY)
dataDir= 'D:\OdorPlaceAssociation\EK2Expt\EK2_direct\';    % data directory
animID= 'EK2';     % your animals name

% tetrode metadata (which tetrode is in which area, which is reference)
 CA1   = [13 14 17 18 19];
 hpcRef=  12;
 PFC   = [1 2 9 10 11];
 pfcRef=   20;
 OB = [3 4 7 8];
 
 % experiment metadata
 cd(topRawDir);
 rawDir=dir();
    rawDir= {rawDir(3:end).name};
 numDays= length(rawDir);
 % The above code assumes raw directory contains one folder for each day of experiment ONLY

 
     
     
 
 %% DAY DEPENDENT NON EEG- pos, lfp, spikes, dio, task, linpos
 for sessionNum=1:numDays;
     
     
     % CONVERT RAW DATA TO BASIC FF DATA
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     % ability to reference added 12/09/16 
     % varargin added 01/30/17
     % varargin for you to use! If you do not specify, these are the defaults 
     % that are passed in from mcz_createNQPosFiles! 
    
    % params for sj_addvelocity
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %posfilt = gaussian(30*0.5, 60); % gaussian smoothing for velocity filter
    
    % extra params
    %%%%%%%%%%%%%%
    %dioFramePulseChannelName=[]; % default strobing channel not used

    % params for mcz_posinterp
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    diodenum = [2 2 2 2 2];                  % number of diodes/indicators used
    diode = .5;                     % use average between front and back diodes
    reversex = 0;                   % don't flip pos along x
    reversey = 0;                   % don't flip pos along y
    maxv= 300;                      % maximum velocity in cm/s
    maxdevpoints= 30;
    bounds= [0 0 ; 1000 1000];      % bounds of video
    pinterp = 1;                    % do interpolate
    maxpinterp = 1e100;             % allow interpolation of any number of points
    maxdinterp = 1e100;             % allow interpolation over any distance
      
     %mcz_createNQPosFiles(    [topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, [], 'diodenum', diodenum)

    % TRANSITION TO THIS WHEN USING RANGE DURING POSITION TRACKING INSTEAD OF VIDEO+FIRST FRAME METHOD
     mcz_createNQPosFiles_new([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, [])
% 
     mcz_createNQLFPFiles(    [topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum)
     %mcz_createNQSpikesFiles([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum)
     mcz_createNQDIOFiles(    [topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum)
%      mcz_createNQDIOFilesFromStateScriptLogs([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum)
     
     
     
     % FF SECONDARY DATA STRUCTURES
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %riptet = [18,20,31];
     % sj_extractripples(dataDir, animID, sessionNum, riptet, 0.015, 2)

 end
 
%  mcz_createNQSpikesFiles([topRawDir rawDir{3}], dataDir, animID, sessionNum)
 % FF BEHAVIOR METADATA STRUCTURES
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     createtaskstruct(   dataDir,animID, [1 2; 2 2; 3 2; 4 2], 'getcoord_Tmaze'); %index - [day1 epoch1; day1 epoch2; etc]
%     createtaskstruct_nopos( dataDir,animID, [1 2; 1 4; 2 2; 2 4; 3 2; 3 4]); 
for sessionNum= 1:4 
%      sj_lineardayprocess(dataDir,animID,sessionNum) %get linpos (need createtaskstruct first)
     %sj_updatetaskstruct(dataDir,animID,sessionNum,[2,4], 'run'); % one
%      %line for each day - need to fix so it works regardless of
%      % number of epochs per day
     sj_updatetaskenv(   dataDir,animID,sessionNum,[2], 'odorplace');
 end


     
     
     %sj_updatetaskenv(   dataDir,animID,sessionNum,[#],
     %'wtr2');
 %% DAY INDEPENDENT- cellinfo, tetinfo
 
 odorPlaceTaskDays = [1,2,3];
save([dataDir,animID,'odorPlaceTaskDays.mat'],'odorPlaceTaskDays'); %change numbers in matrix to correct days

 
 % FF CELL AND TET METADATA STRUCTURES
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 createtetinfostruct(dataDir,animID);
 mcz_createcellinfostruct(dataDir,animID); %must have spikes
 
 % CELL AND TET METADATA POPULATION
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 riptet = [18,20,31];
 
%  sj_addtetrodedescription(dataDir,animID,riptet,'riptet');
     sj_addtetrodedescription(dataDir,animID,hpcRef,'hpcRef');
     sj_addtetrodedescription(dataDir,animID,pfcRef,'pfcRef');
      sj_addtetrodelocation(dataDir,animID,CA1,'CA1');
     sj_addtetrodelocation(dataDir,animID,PFC,'PFC');
      sj_addtetrodelocation(dataDir,animID,OB,'OB');
      
     % betatets = [8, 11, 12, 14, 16, 18, 20, 24, 26, 28, 31, 32];
%cssj_addtetrodedescription2(dataDir,'CS35',betatets,'betatet');
%   
%  sj_addtetrodedescription(dataDir,animID,Ref,'Ref');
 %sj_addtetrodedescription(dataDir,animID,pfcRef,'PFCRef');
 %sj_addcellinfotag2(dataDir,animID);
 
%sj_extractripples(dataDir, animID, sessionNum, riptet, 0.015, 2)

 %% EEG PRIMARY PIPELINE
 
%refData -- an EX32 matrix with the local reference for each tetrode, where
%unused or reference tetrodes have a ref of zero. E is 1:total # of epochs
% TODO- add changes over days? 
 
% filtering/filter path

%Creates refData array with different numbers of copies of refDataTemplate
%on different days according to number of epochs- siplifies so script
%doesn't have to be run multiple times for different days. 


%Create epoch index (number of epochs per day)
 epochIndex = [];
 for sessionNum= 1:numDays
     cd(topRawDir);
     dayDir = rawDir{sessionNum};
     cd(dayDir)
     recfiles = dir(['*.rec']);
     numEpochs = length(recfiles);
     epochIndex(sessionNum) = numEpochs;
 end
 
refDataTemplate = [19 19 19 19 0 0 22 22 22 22 22 0 22 22 22 22 19 19 0 19 22 0 22 22 22 22 19 19 19 19 19 19];
refData = {};
for sessionNum = 1:numDays
    dayrefData = repmat(refDataTemplate,epochIndex(sessionNum),1);
    refData{1,sessionNum} = dayrefData;
end

filtPath= ['D:\DataAnalysis\usrlocal\filtering\'];
addpath('D:\OdorPlaceAssociation\CS35Expt\CS35_direct\EEG');
for sessionNum= 1:3
% 
% %one for each epoch    %DONT USE IF NUMBER OF EPOCHS IS DIFFERENT FOR DIFFERENT
% DAYS
%  refData(1,:)=[2 0 2 2 0 0 11 11 11 11 11 0 11 11 11 11 2 2 2 2 11 11 11 11 11 11 0 2 2 2 2 2];
%  refData(2,:)=[2 0 2 2 0 0 11 11 11 11 11 0 11 11 11 11 2 2 2 2 11 11 11 11 11 11 0 2 2 2 2 2];
%  refData(3,:)=[2 0 2 2 0 0 11 11 11 11 11 0 11 11 11 11 2 2 2 2 11 11 11 11 11 11 0 2 2 2 2 2];
%  refData(4,:)=[2 0 2 2 0 0 11 11 11 11 11 0 11 11 11 11 2 2 2 2 11 11 11 11 11 11 0 2 2 2 2 2];
%  refData(5,:)=[2 0 2 2 0 0 11 11 11 11 11 0 11 11 11 11 2 2 2 2 11 11 11 11 11 11 0 2 2 2 2 2];

mcz_createRefEEG([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, refData{sessionNum});
%      % EEG wrt ground only
%mcz_deltadayprocess([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, 'f', [filtPath 'deltafilter.mat']);
 disp(['doing day ',num2str(sessionNum), ' theta']);
 mcz_thetadayprocess([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, 'f', [filtPath 'thetafilter.mat']);
% 
disp(['doing day ',num2str(sessionNum), ' beta']);
mcz_betadayprocess([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, 'f', [filtPath 'betafilter.mat']);

%      % EEG wrt ground and local reference
disp(['doing day ',num2str(sessionNum), ' gamma']);
mcz_gammadayprocess([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, 'f', [filtPath 'gammafilter.mat']);
% 
disp(['doing day ',num2str(sessionNum), ' ripple']);
mcz_rippledayprocess([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, 'f', [filtPath 'ripplefilter.mat']);

% disp(['doing day ',num2str(sessionNum), ' betaRef']);
% mcz_betadayprocess_Ref([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, 'f', [filtPath 'betafilter.mat']);


%mczcs_lowgammadayprocess([topRawDir rawDir{sessionNum}], dataDir, animID, sessionNum, 'f', [filtPath 'lowgammafilter.mat']);
end
% 
sjcs_baselinespecgram('EK2', [1 2 3 4], 1, [1 2 3 4 7 8 9 10 11 12 13 14 17 18 19 20], 1)
