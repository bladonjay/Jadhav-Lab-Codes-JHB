%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loads trigger times file and plots raw EEG for each trial around the
% trigger at specified time window
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function cs_eventTrigEEG(prefix, day, epoch, tet, trigtype, filter, timewin, subplotsize, do_wrtgnd) 

directoryname = ['E:\Data\OdorPlaceAssociation\', prefix,'_direct\'];
cd(directoryname)

if (day<10)
    daystring = ['0',num2str(day)];
else
    daystring = num2str(day);
end

if (epoch<10)
    epochstring = ['0',num2str(epoch)];
else
    epochstring = num2str(epoch);
end

if (tet<10)
    tetstring = ['0',num2str(tet)];
else
    tetstring = num2str(tet);
end

if do_wrtgnd == 1
    
    switch filter
        case 'none'
            EEGfile = load([prefix, 'eeg', daystring, '-', epochstring, '-', tetstring, '.mat']);
                eegdata = EEGfile.eeg{1,day}{1,epoch}{1,tet}.data;
                starttime = EEGfile.eeg{1,day}{1,epoch}{1,tet}.starttime;
                endtime = EEGfile.eeg{1,day}{1,epoch}{1,tet}.endtime;
                samprate = EEGfile.eeg{1,day}{1,epoch}{1,tet}.samprate;
        case 'lowgamma'
            EEGfile = load([prefix, 'lowgamma', daystring, '-', epochstring, '-', tetstring, '.mat']);
                eegdata = EEGfile.lowgamma{1,day}{1,epoch}{1,tet}.data;
                starttime = EEGfile.lowgamma{1,day}{1,epoch}{1,tet}.starttime;
                endtime = EEGfile.lowgamma{1,day}{1,epoch}{1,tet}.endtime;
                samprate = EEGfile.lowgamma{1,day}{1,epoch}{1,tet}.samprate;
    end
else
    EEGfile = load([prefix, 'eegref', daystring, '-', epochstring, '-', tetstring, '.mat']);
        eegdata = EEGfile.eegref{1,day}{1,epoch}{1,tet}.data;
        starttime = EEGfile.eegref{1,day}{1,epoch}{1,tet}.starttime;
        endtime = EEGfile.eegref{1,day}{1,epoch}{1,tet}.endtime;
        samprate = EEGfile.eegref{1,day}{1,epoch}{1,tet}.samprate;
end

eegtimes = [starttime:(1/samprate):endtime]';

if isa(trigtype, 'char')
    
    switch trigtype
        case 'odor'
            trigfile = load(['OdorTriggers', daystring, '-', epochstring, '.mat']);
            triggers = trigfile.OdorTriggers_all;
        case 'reward'
            rewardfile = load(['RewardTimes', daystring, '-', epochstring, '.mat']);
            triggers = rewardfile.RewardTimes;
    end
else
    triggers = trigtype;
end


figure,

for t = 1:length(triggers),
    trigtime = triggers(t);
    triggeredTimeWindowStart = trigtime - timewin(1,1);
    triggeredTimeWindowEnd = trigtime + timewin(1,2);
    triggeredEEGtimes = eegtimes(eegtimes>triggeredTimeWindowStart & eegtimes<triggeredTimeWindowEnd);
    eegTimeInds = find(eegtimes>triggeredTimeWindowStart & eegtimes<triggeredTimeWindowEnd);
    triggeredEEG = eegdata(eegTimeInds);
    
    last = triggeredEEG(2:end);
    first = triggeredEEG(1:end-1);
    diff = last - first;
    
    bad = find(abs(diff) > abs(1000));
   
    %if isempty(bad),
        normalizedEEGtimes = (triggeredEEGtimes - trigtime);
        
        
    
        subplot(subplotsize(1), subplotsize(2), t)
    
    
        plot(normalizedEEGtimes,triggeredEEG)
        axis([-timewin(1) timewin(2) -1000 1000])
        hold on
        ypts = ((-1000):1000);
        xpts = zeros(size(ypts));
        plot(xpts , ypts, 'k--', 'Linewidth',2);
    %end
end
end
    
