function cs_separateBetaModRegions(betaModFile)

load(betaModFile)

cellregions = {'CA1','PFC'};
for r = 1:length(cellregions)
    region = cellregions{r};
    load(['cellSelectivityData_', region, '_0-1000ms.mat']);

    cellinds = vertcat(cellSelectivity.cellindex);
    plinds = vertcat(betaMod.index);

    keepcells = betaMod(ismember(plinds,cellinds, 'rows'));
    eval(['betaMod_',region,'cells = keepcells;']);
end

save(betaModFile,'betaMod_CA1cells','betaMod_PFCcells');

