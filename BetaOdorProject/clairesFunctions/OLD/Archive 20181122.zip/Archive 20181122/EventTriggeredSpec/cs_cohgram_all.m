% Claire - Feb 2017 
% Creates a mean coherogram across all days and all epochs, using all possible
% pairs of tetrodes from two brain regions.
% uses wbcs_trigcohgram_multitaper.m

function cs_cohgram_all(prefix, days, epochs, region1, region2, trigtype, do_wrtgnd, timewin)

switch prefix
    case 'CS15'
        directoryname = 'E:\Data\OdorPlaceAssociation\CS15_direct';
        switch region1
                case 'hpc'
                    tets1 = [2, 3, 4, 15, 16, 19, 25, 27];
                case 'ppc'
                    tets1 = [7, 8, 9, 10, 31];
        end
        switch region2
                case 'hpc'
                    tets2 = [2, 3, 4, 15, 16, 19, 25, 27];
                case 'ppc'
                    tets2 = [7, 8, 9, 10, 31];
        end
    case 'CS31'
        directoryname = 'E:\Data\OdorPlaceAssociation\CS31_direct';
        switch region1
                case 'hpc'
                    tets1 = [17, 18, 19, 30, 31, 32];
                case 'pfc'
                    tets1 = [7, 8, 9, 12, 14, 16, 21, 25, 26];
                case 'ob'
                    tets1 = [24];
        end
        switch region2
                case 'hpc'
                    tets2 = [17, 18, 19, 30, 31, 32]; 
                case 'pfc'
                    tets2 = [7, 8, 9, 12, 14, 16, 21, 25, 26];
                case 'ob'
                    tets2 = [24];
        end
end

%create a big list of tetrode pairs
[t1, t2] = meshgrid(tets1, tets2);
tetsall = cat(2,t1',t2');
tetpairslist = reshape(tetsall,[],2);

coh_AllTets = [];
coh_AllDays = [];

for t = 1:length(tetpairslist(:,1))
    tet1 = tetpairslist(t,1);
    tet2 = tetpairslist(t,2);
    
    for d = 1:length(days)
        day = days(d);
        
        if strcmp(prefix, 'CS15') == 1  %for CS15, epochs 2 and 4 on day 4 were familiar odor, epoch 6 was novel odor
            if day == 4 
                if strcmp(trigtype, 'novelodor') == 1
                    epochs = [6];
                else 
                    epochs = [2, 4];
                end
            end
        end
        
        disp(['Doing tets ' num2str(tet1), '-', num2str(tet2), ', day ', num2str(day)]); 
        %loops over the coherogram code for each day. Calls each epoch
        %separately and finds mean within the trigcohgram function
        [ETA, win, f1] = wbcs_trigcohgram_multitaper(prefix, day, epochs, tet1, tet2, trigtype, do_wrtgnd, 0, timewin); 
        
        coh_AllDays(:,:,d) = ETA; 
        
    end
    
    meanAcrossDays = mean(coh_AllDays,3);
    coh_AllTets(:,:,t) = meanAcrossDays;
end
meanETA = mean(coh_AllTets,3); %mean acros all days and tet pairs
N = length(f1);

figdir = 'E:\Figures\Cohgrams\';
figure,
    
    imagesc(win, 1:N, meanETA);
    
    set(gcf,'Position',[100 100 1200 895]);
    colormap(jet)
    colorbar
    set(gca,'YDir','normal')
    set(gca,'YTick',0:10:N);
    set(gca,'YTicklabel',round(f1(0:10:end)));
    
    hold on
    ypts = f1;
    xpts = 0*ones(size(ypts));
    plot(xpts , ypts, 'k--','Linewidth',3);
    
    set(0,'defaultaxeslinewidth',2);
    set(0,'defaultaxesfontsize',20);
    
    switch trigtype
        case 'odor'
            Titlestring = 'Coherogram aligned to odor onset';
        case 'novelodor'
            Titlestring = 'Coherogram aligned to odor onset - novel odors';
        case 'corrTrigs'
            Titlestring = 'Coherogram aligned to odor on correct trials only';
        case 'incorrTrigs'
            Titlestring = 'Coherogram aligned to odor on incorrect trials only';
    end
    if do_wrtgnd==1
        %title([Titlestring, ' ', region1, '-', region2, ' wrtgnd'], 'FontSize',18);
        title('')
        figfile = [figdir,prefix,'cohgram_',trigtype,'_',region1,'-',region2,'_GND'];
    else
        title([Titlestring, ' ', region1, '-', region2, ' ref'], 'FontSize',18);
        figfile = [figdir,prefix,'cohgram_',trigtype,'_',region1,'-',region2,'_REF'];
    end
    ylabel('Freq (Hz)','FontSize',20,'Fontweight','normal');
    xlabel('Time(s)','FontSize',20,'Fontweight','normal');
    
    
    print('-djpeg', figfile);
    print('-dpdf', figfile);
    saveas(gcf,figfile,'fig');
end