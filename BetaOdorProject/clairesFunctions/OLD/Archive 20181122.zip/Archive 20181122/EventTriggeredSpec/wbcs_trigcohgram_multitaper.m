function [ETA, win, f1] = wbcs_trigcohgram_multitaper(prefix, day, epochs, tet1, tet2, trigtype, do_wrtgnd, figopt, timewin, varargin)
% Wenbo: Dec 2016, wavelet method to get ripple-triggered time-frequency
% coherence between tet1 and tet 2
% using Morlet wavelet, half length = 20 (default)

% Claire: Edited Feb 2017 to use any trigger type and to work with new
% data (eeg and eegref files)

addpath(genpath('C:\Users\wbtang\Documents\MATLAB\toolbox'))

if nargin<1
    keyboard
    error('Please enter Expt Prefix and Day No!');
end
if nargin<2
    keyboard
    error('Please enter Day No!');
end
if nargin<3
    epochs = 1; 
end
if nargin<4
    tet1 = 1; 
end
if nargin<5
    tet2 = 1; 
end
if nargin<6
    do_wrtgnd=1; % Whether to also do with respect to ground
end

if nargin<7
    figopt=0; 
end


%-------multitaper params----------%
movingwin = [1000 100]/1000; cwin = movingwin;
params.Fs = 1500;
params.err = [2 0.05];
params.fpass = [0 40];
params.tapers = [3 5]; % Should I put this in or let it use default tapers
winstart = -(timewin(1,1));
winend = timewin(1,2);

%-------self-defined params----------%
%set variable options
for option = 1:2:length(varargin)-1
    switch varargin{option}
        case 'movingwin'
            movingwin = varargin{option+1};
        case 'fpass'
            params.fpass = varargin{option+1};
    end
end

if params.fpass(2) == 400
    savetag = '';
    movingwin = [100 10]/1000; cwin = movingwin;
end
if params.fpass(2) == 100
    savetag = 'mid';
    movingwin = [400 40]/1000; cwin = movingwin;
end
if params.fpass(2) == 40
    savetag = 'low';
    movingwin = [1000 100]/1000; cwin = movingwin;
end
if params.fpass(2) == 10
    savetag = 'floor';
    movingwin = [4000 400]/1000;
end

        
% SET DATA
% -------------------------------------------
switch prefix
    case 'HPa'
        directoryname = 'D:\HPExp_data\HPa_direct\HPa_direct\';
    case 'HPb'
        directoryname = 'D:\HPExp_data\HPb_direct\';
    case 'HPc'
        directoryname = 'D:\HPExp_data\HPc_direct\';
    case 'CS15'
        directoryname = 'E:\Data\OdorPlaceAssociation\CS15_direct\';
    case 'CS31'
        directoryname = 'D:\OdorPlaceAssociation\CS31_direct\';
    case 'CS34'
        directoryname = 'E:\CS31Expt\CS31_direct\';
end

dir2=directoryname;

daystring = getTwoDigitNumber(day);
tetstring1 = getTwoDigitNumber(tet1);
tetstring2 = getTwoDigitNumber(tet2);


% STA_all = [];
for ep=1:length(epochs)
    epoch = epochs(ep);
    epstring = getTwoDigitNumber(epoch);
    epoch = str2num(epstring);
    
     if exist([prefix,'eeg',daystring,'-',epstring,'-',tetstring1,'.mat']) == 2
         
         triggers_tet1 = cs_removeNoisyTrials(prefix, day, epoch, tet1, trigtype, timewin, do_wrtgnd);
         triggers_tet2 = cs_removeNoisyTrials(prefix, day, epoch, tet2, trigtype, timewin, do_wrtgnd);
         triggers = intersect(triggers_tet1, triggers_tet2);


        cd([directoryname,'EEG\']);
        if do_wrtgnd==1
                curreeggndfile = [dir2,'EEG\',prefix,'eeg',daystring,'-',epstring,'-',tetstring1];
                load(curreeggndfile);
                lfp1 = (eeg{day}{epoch}{tet1}.data)';
                time1 = geteegtimes(eeg{day}{epoch}{tet1}) ; % construct time array
                fs = eeg{day}{epoch}{tet1}.samprate;
                clear eeggnd

                curreeggndfile = [dir2,'EEG\',prefix,'eeg',daystring,'-',epstring,'-',tetstring2];
                load(curreeggndfile);
                lfp2 = (eeg{day}{epoch}{tet2}.data)';
                time2 = geteegtimes(eeg{day}{epoch}{tet2}) ; % construct time array
                clear eeggnd
                if ~all(time2 == time1)% check if time vectors are matched
                    lfp2 = interp1(time2,lfp2,time1,'nearest');
                end
        else
                curreegfile = [dir2,'EEG\',prefix,'eegref', daystring,'-',epstring,'-',tetstring1];
                load(curreegfile);
                lfp1 = (eegref{day}{epoch}{tet1}.data)';
                time1 = geteegtimes(eegref{day}{epoch}{tet1}) ; % construct time array
                fs = eegref{day}{epoch}{tet1}.samprate;
                clear eeg

                curreegfile = [dir2,'EEG\',prefix,'eegref',daystring,'-',epstring,'-',tetstring2];
                load(curreegfile);
                lfp2 = (eegref{day}{epoch}{tet2}.data)';
                time2 = geteegtimes(eegref{day}{epoch}{tet2}) ; % construct time array
                clear eeg
                if ~all(time2 == time1)% check if time vectors are matched
                    lfp2 = interp1(time2,lfp2,time1,'nearest');
                end
        end
        %-------cohgram----------%
        [Coh,Phi,~,~,~,t,f1] = cohgramc(lfp1',lfp2',movingwin,params);
        t = t + time1(1);
        Coh = Coh';
        Phi = Phi';    

        %-------SWR-triggered cohgram----------%
        fs_c = round(1/(t(2)-t(1)));
        N = length(Coh(:,1)); %number of freqs
        win = winstart:1/fs_c:winend;
        winidx = round(win.*fs_c);
        ETA = zeros(N,length(win));
        for j = 1:length(triggers)
            if triggers(j) > (t(1) + 2) && triggers(j) < (t(end) - 2)% throw away the first  and last 2s
                [junk, trigidx] = min(abs(t - triggers(j)));
                ETA = ETA + Coh(:,trigidx+winidx);
            end
        end
        ETA = ETA./j;
        ETA_all(:,:,ep) = ETA;
     end
end

if length(epochs) > 1
    ETA = mean(ETA_all,3); % Mean across epochs
end


% ------------------------------------------------
% PLOT
% -------------------------------------------------

if figopt ==1
    figdir = ['E:\Figures\Cohgrams\'];
    set(0,'defaultaxesfontweight','normal'); set(0,'defaultaxeslinewidth',2);
    set(0,'defaultaxesfontsize',16);
    tfont = 18; % title font
    xfont = 16;
    yfont = 16;
    clr = {'b','r','g','c','m','y','k','r'};

    figure,
    set(gcf,'Position',[100 100 1120 840])
    
    imagesc(win, 1:N, ETA)
    
    colormap(jet)
    colorbar
    set(gca,'YDir','normal')
    set(gca,'YTick',1:10:length(Coh(:,1)));
    set(gca,'YTicklabel',round(f1(1:10:end)));
    hold on
    ypts = f1;
    xpts = 0*ones(size(ypts));
    plot(xpts , ypts, 'k--','Linewidth',3);
    
    switch trigtype
        case 'odor'
            Titlestring = 'Coherogram aligned to odor onset';
        case 'novelodor'
            Titlestring = 'Coherogram aligned to odor onset - novel odors';
        case 'corrTrigs'
            Titlestring = 'Coherogram aligned to odor on correct trials only';
        case 'incorrTrigs'
            Titlestring = 'Coherogram aligned to odor on incorrect trials only';
    end
    if do_wrtgnd==1
        title([Titlestring, ' ', tetstring1, ' ', tetstring2, ' wrtgnd']);
%        title(['Tet ',num2str(tet1),'-Tet ',num2str(tet2),' Cohgram wrt GND aligned to ', 'ripple'],'FontSize',18,'Fontweight','normal');
       figfile = [figdir,prefix,'_Day',num2str(day),'-Ep',num2str(epoch),'_Tet',num2str(tet1),'_Tet',num2str(tet2),'_fpass',num2str(params.fpass(2)),'_',trigtype,'_','GND'];
    else
        title([Titlestring, ' ', tetstring1, ' ', tetstring2, ' ref']);
        %title(['Tet ',num2str(tet1),'-Tet ',num2str(tet2),' Cohgram aligned to ','ripple'],'FontSize',18,'Fontweight','normal');
        figfile = [figdir,prefix,'_Day',num2str(day),'-Ep',num2str(epoch),'_Tet',num2str(tet1),'_Tet',num2str(tet2),'_fpass',num2str(params.fpass(2)),'_',trigtype,'_','REF'];
    end
    print('-djpeg', figfile);
    print('-dpdf', figfile);
    saveas(gcf,figfile,'fig');
end

% ------------------------------------------------
% Save
% -------------------------------------------------
eegtrigcoh{day}{epoch}{tet1}{tet2}.Ctime = win;
eegtrigcoh{day}{epoch}{tet1}{tet2}.Cfreq = f1;
eegtrigcoh{day}{epoch}{tet1}{tet2}.Cmean = ETA';

% eegcoh{day}{epoch}{tet1}{tet2}.Ctime = t; % too big, dont save
% eegcoh{day}{epoch}{tet1}{tet2}.Cfreq = f1;
% % eegcohwavelet{day}{epoch}{tet1}{tet2}.Rsq = Rsq;
% eegcoh{day}{epoch}{tet1}{tet2}.Coh = Coh;
% eegcoh{day}{epoch}{tet1}{tet2}.Phi = Phi;

% if do_wrtgnd==1 
%     savefile = [figdir,prefix,'eegtrigcoh',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2,'_fpass-',num2str(params.fpass(2))];
% %     savefile_all = [figdir,prefix,'eegcoh',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2,'_fpass-',num2str(params.fpass(2))];
% 
% else
%     savefile = [figdir,prefix,'eegtrigcoh',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2,'_fpass-',num2str(params.fpass(2)),'-REF'];
% %     savefile_all = [figdir,prefix,'eegcoh',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2,'_fpass-',num2str(params.fpass(2)),'-REF'];
% end
% 
% save(savefile,'eegtrigcoh');
% % save(savefile_all,'eegcoh');
% 
% if do_wrtgnd==1 
%     disp(['Save ', 'eegtrigcoh',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2,'_fpass-',num2str(params.fpass(2))])
% else
%     disp(['Save ', 'eegtrigcoh',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2,'_fpass-',num2str(params.fpass(2)),'-REF'])
% end