function wbcs_HPexpt_odortrigspecgram_wavelet(prefix, day, epochs, tet, do_wrtgnd, figopt, varargin)
% Wenbo: Dec 2016, wavelet method to get ripple-triggered spectrogram
% using Morlet wavelet, half length = 7 (default)

%add the TFTB toolbox in path:
addpath(genpath('C:\Program Files\MATLAB\R2017a\toolbox\tftb\'))

if nargin<1
    keyboard
    error('Please enter Expt Prefix and Day No!');
end
if nargin<2
    keyboard
    error('Please enter Day No!');
end
if nargin<3
    epochs = 1; 
end
if nargin<4
    tet = 1; 
end

if nargin<5
    do_wrtgnd=1; % Whether to also do with respect to ground
end

if nargin<6
    figopt=0; 
end


%-------wavelet params----------%
 
fmin = 0.001;% f = fmin*fs
fmax = 1/5; % 300 Hz   %samprate = 1500, 1/5*fs = 300. 
N = 84;% 84 wavelets
half_width = 7; % Morlet wavelet, half length 7 cycles

%-------self-defined wavelet params----------%
for option = 1:2:length(varargin)-1
    switch varargin{option}
          case 'half_width'
              half_width = varargin{option+1};
          case 'fmin' %FMIN,FMAX : respectively lower and upper frequency bounds of the analyzed signal.
              fmin =  varargin{option+1};
          case 'fmax'
              fmax =  varargin{option+1};
          case 'N' %number of analyzed voices
              N =  varargin{option+1};
    end
end

        
% SET DATA
% -------------------------------------------
%change the directory accordingly
switch prefix
    case 'ER1'
        directoryname = 'D:\SingledayExp_data\ER1_NEW_direct2\';
    case 'KL8'
        directoryname = 'D:\SingledayExp_data\KL8_direct';
    case 'CS33'
        directoryname = 'D:\OdorPlaceAssociation\CS33Expt\CS33_direct\';
end

dir2=directoryname;

if (day<10)
    daystring = ['0',num2str(day)];
else
    daystring = num2str(day);
end

epochstring = [];
for i = 1:length(epochs)
    epochstring = [epochstring,'-0',num2str(epochs(i))];
end


if (tet<10)
    tetstring = ['0',num2str(tet)];
else
    tetstring = num2str(tet);
end

% STA_all = [];
for ep=1:length(epochs)
    epoch = epochs(ep);
    % Nrippleamp EW - Get relevant ripple triggers directly
    % if you don't have ripplemap, use your own ripple time file
%     ripampfile = sprintf('%s/%srippleamp%02d.mat', directoryname, prefix, day);
%     load(ripampfile);
%     rip_starttime = rippleamp{day}{epoch}(:,1);
%     triggers = rip_starttime;
    odorTriggersFile = sprintf('%s/%sodorTriggers%02d.mat', directoryname, prefix, day);
    load(odorTriggersFile);
    triggers = odorTriggers{day}{epoch}.allTriggers;
    
    cd([directoryname,'/EEG/']);
    if epoch<10
           sep = ['0',num2str(epoch)];
    else
           sep = num2str(epoch);
    end
    if do_wrtgnd==1
           
            curreeggndfile = [dir2,'/EEG/',prefix,'eeg',daystring,'-',sep,'-',tetstring];
            load(curreeggndfile);
            lfp = (eeg{day}{epoch}{tet}.data)';
            time = geteegtimes(eeg{day}{epoch}{tet}) ; % construct time array
            fs = eeg{day}{epoch}{tet}.samprate;
            clear eeg

    else
            curreegfile = [dir2,'/EEG/',prefix,'eegref', daystring,'-',sep,'-',tetstring];
            load(curreegfile);
            lfp = (eegref{day}{epoch}{tet}.data)';
            time = geteegtimes(eegref{day}{epoch}{tet}) ; % construct time array
            fs = eegref{day}{epoch}{tet}.samprate;
            clear eegref
    end
    %-------wavelet scalogram----------%
    [tfr,t,f,wt]=tfrscalo(lfp',1:length(lfp),half_width,fmin,fmax,N);% Morlet wavelet, half length = 7 (default)
    ff = f.*fs;
    power  = abs(tfr);
    % Zscore
    powerZ=(power-repmat(mean(power')',1,length(power(1,:))))./repmat(std(power')',1,length(power(1,:)));
%             imagesc(time, 1:N, powerZ)  %plot spectrogram, don't
%             caxis([-3 3])
%             colormap(jet)
%             xlim([time(1) time(1)+6])% see 6s
%             set(gca,'YDir','normal')
%             set(gca,'YTick',1:10:length(power(:,1)));
%             set(gca,'YTicklabel',round(ff(1:10:end)));
   
     %-------SWR-triggered spec----------%
     winstart = -0.5;%-2s
     winend = 0.5;% 2s
     win = winstart:1/round(fs):winend;
     winidx = round(win.*round(fs));
     STA = zeros(N,length(win));
     for j = 1:length(triggers)
         if triggers(j) > (time(1) + 2) && triggers(j) < (time(end) - 2)% throw away the first  and last 2s
             [junk, trigidx] = min(abs(time - triggers(j)));
             STA = STA + powerZ(:,trigidx+winidx);
         end
     end
     STA = STA./j;
     STA_all(:,:,ep) = STA;
end

if length(epochs) > 1
    STA = mean(STA_all,3); % Mean across epochs
end


% ------------------------------------------------
% PLOT
% -------------------------------------------------

if figopt ==1
    figdir = [dir2,'/EEGSpec_wb/'];
    set(0,'defaultaxesfontweight','normal'); set(0,'defaultaxeslinewidth',2);
    set(0,'defaultaxesfontsize',16);
    tfont = 18; % title font
    xfont = 16;
    yfont = 16;
    clr = {'b','r','g','c','m','y','k','r'};

    %figure(100),
    figure
    %set(gcf,'Position',[820 660 560 420])
    imagesc(win, 1:N, STA)
    colormap(jet)
    set(gca,'YDir','normal')
    set(gca,'YTick',1:10:length(power(:,1)));
    set(gca,'YTicklabel',round(ff(1:10:end)));
    if do_wrtgnd==1 
       title(['Tet ',num2str(tet),' Specgram wrt GND aligned to ', 'odor'],'FontSize',18,'Fontweight','normal');
       %figfile = [figdir,prefix,'_Day',num2str(day),'-Ep',epochstring,'_Tet',num2str(tet),'_wavelet','_','ripple','_','GND'];
    else
        title(['Tet ',num2str(tet),' Specgram aligned to ','odor'],'FontSize',18,'Fontweight','normal');
        %figfile = [figdir,prefix,'_Day',num2str(day),'-Ep',epochstring,'_Tet',num2str(tet),'_wavelet','_','ripple','_','REF'];
    end
    %print('-djpeg', figfile);
    %saveas(gcf,figfile,'fig');
end

% ------------------------------------------------
% Save
% -------------------------------------------------
% eegtrigspecwavelet{day}{epoch}{tet}.Stime = win;
% eegtrigspecwavelet{day}{epoch}{tet}.Sfreq = ff;
% eegtrigspecwavelet{day}{epoch}{tet}.Smean = STA';
% if do_wrtgnd==1 
%     savefile = [figdir,prefix,'eegtrigspecwavelet',daystring,'-Ep',epochstring,'-Tet-',tetstring];
% else
%     savefile = [figdir,prefix,'eegtrigspecwavelet',daystring,'-Ep',epochstring,'-Tet-',tetstring,'-REF'];
% end
% 
% save(savefile,'eegtrigspecwavelet');
% if do_wrtgnd==1 
%     disp(['Save ', 'eegtrigspecwavelet',daystring,'-Ep',epochstring,'-Tet-',tetstring])
% else
%     disp(['Save ', 'eegtrigspecwavelet',daystring,'-Ep',epochstring,'-Tet-',tetstring,'-REF'])
% end