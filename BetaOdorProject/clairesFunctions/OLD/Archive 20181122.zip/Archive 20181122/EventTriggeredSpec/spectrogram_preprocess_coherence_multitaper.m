clc;
clear all;
close all;
addpath(genpath('C:\Users\wbtang\Documents\MATLAB\toolbox'))% time-frequency toolboxes
addpath(genpath('C:\Users\wbtang\Desktop\HMM\Src_Matlab'))
%%
animalprefix_list = {'HPc'};
day_list = 1:5;

%% 
nn = 1;
% hp-hp coherence
for theAnimal = 1:length(animalprefix_list)
    animalprefix = animalprefix_list{theAnimal};
    if strcmp(animalprefix,'HPa')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPa_direct/HPa_direct/');
        dir = ('D:\HPExp_data\HPa_direct\HPa_direct\');
    elseif strcmp(animalprefix,'HPb')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPb_direct/');
        dir = ('D:\HPExp_data\HPb_direct\');
    elseif strcmp(animalprefix,'HPc')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPc_direct/');
        dir = ('D:\HPExp_data\HPc_direct\');
    end
    tetinfo = loaddatastruct(dir, animalprefix, 'tetinfo');
    cellinfo = loaddatastruct(dir, animalprefix, 'cellinfo');
    for day = day_list
        if day == 1
            % epoch list
            eps =[1, 4, 6, 7]; %for Day 1 %PRE, W1, W1, POST-W1
        else
            eps = [1, 2, 4, 5]; %for Day 6 %PRE, W1, W2, POST-W2
        end
        
        for ep = eps
            % hp tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                               if isfield(tetinfo{day}{ep}{ttt},'descrip')
                                    if strcmp(tetinfo{day}{ep}{ttt}.descrip,'riptet')
                                        detect_tet_tmp = [detect_tet_tmp ttt];
                                    end
                                end
                        end
            end
            if ep > 1
                detect_tet = intersect(detect_tet_tmp,detect_tet);
            else 
                detect_tet = detect_tet_tmp;
            end
            
        end
        tetnum_hp = length(detect_tet);
        pairind = combnk(1:tetnum_hp,2);
        
        for i = 1:length(pairind(:,1))
            cid1 = pairind(i,1);
            cid2 = pairind(i,2);
            tet2 = detect_tet(cid2);
            tet1 = detect_tet(cid1);
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(1), tet1, tet2, 1, 1);%pre
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(1));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(2:3), tet1, tet2, 1, 1);%run
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(2));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(4), tet1, tet2, 1, 1);%post
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(4));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
        end
    end
end

%% 
nn = 1;
% hp-pfc coherence
for theAnimal = 1:length(animalprefix_list)
    animalprefix = animalprefix_list{theAnimal};
    if strcmp(animalprefix,'HPa')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPa_direct/HPa_direct/');
        dir = ('D:\HPExp_data\HPa_direct\HPa_direct\');
    elseif strcmp(animalprefix,'HPb')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPb_direct/');
        dir = ('D:\HPExp_data\HPb_direct\');
    elseif strcmp(animalprefix,'HPc')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPc_direct/');
        dir = ('D:\HPExp_data\HPc_direct\');
    end
    tetinfo = loaddatastruct(dir, animalprefix, 'tetinfo');
    cellinfo = loaddatastruct(dir, animalprefix, 'cellinfo');
    for day = day_list
        if day == 1
            % epoch list
            eps =[1, 4, 6, 7]; %for Day 1 %PRE, W1, W1, POST-W1
        else
            eps = [1, 2, 4, 5]; %for Day 6 %PRE, W1, W2, POST-W2
        end
        
        for ep = eps
            % hp tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                               if isfield(tetinfo{day}{ep}{ttt},'descrip')
                                    if strcmp(tetinfo{day}{ep}{ttt}.descrip,'riptet')
                                        detect_tet_tmp = [detect_tet_tmp ttt];
                                    end
                                end
                        end
            end
            if ep > 1
                detect_tet1 = intersect(detect_tet_tmp,detect_tet1);
            else 
                detect_tet1 = detect_tet_tmp;
            end
            % ctx tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                                if strcmp(tetinfo{day}{ep}{ttt}.area,'PFC') % Cortical neurons first
                                     if max(length(cellinfo{day}{ep}) >= ttt)
                                        if ~isempty(cellinfo{day}{ep}{ttt})
                                            detect_tet_tmp = [detect_tet_tmp ttt];
                                        end
                                     end
                                end
                        end
            end
            if ep > 1
                detect_tet2 = intersect(detect_tet_tmp,detect_tet2);
            else 
                detect_tet2 = detect_tet_tmp;
            end
            
        end
        tetnum_hp = length(detect_tet1);
        tetnum_ctx = length(detect_tet2);
        C_ctx = repmat(1:tetnum_ctx,tetnum_hp,1);
        C_ctx = reshape(C_ctx,1,[]);
        C_hp = repmat(1:tetnum_hp,1,tetnum_ctx);
        pairind = [C_ctx' C_hp'];% (ctx, hp)
        
        for i = 1:length(pairind(:,1))
            cid_ctx = pairind(i,1);
            cid_hp = pairind(i,2);
            tet2 = detect_tet2(cid_ctx);
            tet1 = detect_tet1(cid_hp);
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(1), tet1, tet2, 1, 1);%pre
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(1));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(2:3), tet1, tet2, 1, 1);%run
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(2));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(4), tet1, tet2, 1, 1);%post
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(4));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
        end
    end
end

%% 
nn = 1;
% hp-hp coherence ref
for theAnimal = 1:length(animalprefix_list)
    animalprefix = animalprefix_list{theAnimal};
    if strcmp(animalprefix,'HPa')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPa_direct/HPa_direct/');
        dir = ('D:\HPExp_data\HPa_direct\HPa_direct\');
    elseif strcmp(animalprefix,'HPb')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPb_direct/');
        dir = ('D:\HPExp_data\HPb_direct\');
    elseif strcmp(animalprefix,'HPc')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPc_direct/');
        dir = ('D:\HPExp_data\HPc_direct\');
    end
    tetinfo = loaddatastruct(dir, animalprefix, 'tetinfo');
    cellinfo = loaddatastruct(dir, animalprefix, 'cellinfo');
    for day = day_list
        if day == 1
            % epoch list
            eps =[1, 4, 6, 7]; %for Day 1 %PRE, W1, W1, POST-W1
        else
            eps = [1, 2, 4, 5]; %for Day 6 %PRE, W1, W2, POST-W2
        end
        
        for ep = eps
            % hp tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                               if isfield(tetinfo{day}{ep}{ttt},'descrip')
                                    if strcmp(tetinfo{day}{ep}{ttt}.descrip,'riptet')
                                        detect_tet_tmp = [detect_tet_tmp ttt];
                                    end
                                end
                        end
            end
            if ep > 1
                detect_tet = intersect(detect_tet_tmp,detect_tet);
            else 
                detect_tet = detect_tet_tmp;
            end
            
        end
        tetnum_hp = length(detect_tet);
        pairind = combnk(1:tetnum_hp,2);
        
        for i = 1:length(pairind(:,1))
            cid1 = pairind(i,1);
            cid2 = pairind(i,2);
            tet2 = detect_tet(cid2);
            tet1 = detect_tet(cid1);
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(1), tet1, tet2, 0, 1);%pre
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(1));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(2:3), tet1, tet2, 0, 1);%run
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(2));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(4), tet1, tet2, 0, 1);%post
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(4));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
        end
    end
end

%% 
nn = 1;
% hp-pfc coherence ref
for theAnimal = 1:length(animalprefix_list)
    animalprefix = animalprefix_list{theAnimal};
    if strcmp(animalprefix,'HPa')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPa_direct/HPa_direct/');
        dir = ('D:\HPExp_data\HPa_direct\HPa_direct\');
    elseif strcmp(animalprefix,'HPb')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPb_direct/');
        dir = ('D:\HPExp_data\HPb_direct\');
    elseif strcmp(animalprefix,'HPc')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPc_direct/');
        dir = ('D:\HPExp_data\HPc_direct\');
    end
    tetinfo = loaddatastruct(dir, animalprefix, 'tetinfo');
    cellinfo = loaddatastruct(dir, animalprefix, 'cellinfo');
    for day = day_list
        if day == 1
            % epoch list
            eps =[1, 4, 6, 7]; %for Day 1 %PRE, W1, W1, POST-W1
        else
            eps = [1, 2, 4, 5]; %for Day 6 %PRE, W1, W2, POST-W2
        end
        
        for ep = eps
            % hp tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                               if isfield(tetinfo{day}{ep}{ttt},'descrip')
                                    if strcmp(tetinfo{day}{ep}{ttt}.descrip,'riptet')
                                        detect_tet_tmp = [detect_tet_tmp ttt];
                                    end
                                end
                        end
            end
            if ep > 1
                detect_tet1 = intersect(detect_tet_tmp,detect_tet1);
            else 
                detect_tet1 = detect_tet_tmp;
            end
            % ctx tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                                if strcmp(tetinfo{day}{ep}{ttt}.area,'PFC') % Cortical neurons first
                                     if max(length(cellinfo{day}{ep}) >= ttt)
                                        if ~isempty(cellinfo{day}{ep}{ttt})
                                            detect_tet_tmp = [detect_tet_tmp ttt];
                                        end
                                     end
                                end
                        end
            end
            if ep > 1
                detect_tet2 = intersect(detect_tet_tmp,detect_tet2);
            else 
                detect_tet2 = detect_tet_tmp;
            end
            
        end
        tetnum_hp = length(detect_tet1);
        tetnum_ctx = length(detect_tet2);
        C_ctx = repmat(1:tetnum_ctx,tetnum_hp,1);
        C_ctx = reshape(C_ctx,1,[]);
        C_hp = repmat(1:tetnum_hp,1,tetnum_ctx);
        pairind = [C_ctx' C_hp'];% (ctx, hp)
        
        for i = 1:length(pairind(:,1))
            cid_ctx = pairind(i,1);
            cid_hp = pairind(i,2);
            tet2 = detect_tet2(cid_ctx);
            tet1 = detect_tet1(cid_hp);
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(1), tet1, tet2, 0, 1);%pre
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(1));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(2:3), tet1, tet2, 0, 1);%run
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(2));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(4), tet1, tet2, 0, 1);%post
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(4));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
        end
    end
end
%% high frequency
%%
nn = 1;
% hp-hp coherence
for theAnimal = 1:length(animalprefix_list)
    animalprefix = animalprefix_list{theAnimal};
    if strcmp(animalprefix,'HPa')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPa_direct/HPa_direct/');
        dir = ('D:\HPExp_data\HPa_direct\HPa_direct\');
    elseif strcmp(animalprefix,'HPb')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPb_direct/');
        dir = ('D:\HPExp_data\HPb_direct\');
    elseif strcmp(animalprefix,'HPc')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPc_direct/');
        dir = ('D:\HPExp_data\HPc_direct\');
    end
    tetinfo = loaddatastruct(dir, animalprefix, 'tetinfo');
    cellinfo = loaddatastruct(dir, animalprefix, 'cellinfo');
    for day = day_list
        if day == 1
            % epoch list
            eps =[1, 4, 6, 7]; %for Day 1 %PRE, W1, W1, POST-W1
        else
            eps = [1, 2, 4, 5]; %for Day 6 %PRE, W1, W2, POST-W2
        end
        
        for ep = eps
            % hp tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                               if isfield(tetinfo{day}{ep}{ttt},'descrip')
                                    if strcmp(tetinfo{day}{ep}{ttt}.descrip,'riptet')
                                        detect_tet_tmp = [detect_tet_tmp ttt];
                                    end
                                end
                        end
            end
            if ep > 1
                detect_tet = intersect(detect_tet_tmp,detect_tet);
            else 
                detect_tet = detect_tet_tmp;
            end
            
        end
        tetnum_hp = length(detect_tet);
        pairind = combnk(1:tetnum_hp,2);
        
        for i = 1:length(pairind(:,1))
            cid1 = pairind(i,1);
            cid2 = pairind(i,2);
            tet2 = detect_tet(cid2);
            tet1 = detect_tet(cid1);
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(1), tet1, tet2, 1, 1,'fpass',[0 400]);%pre
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(1));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(2:3), tet1, tet2, 1, 1,'fpass',[0 400]);%run
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(2));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(4), tet1, tet2, 1, 1,'fpass',[0 400]);%post
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(4));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
        end
    end
end

%% 
nn = 1;
% hp-pfc coherence
for theAnimal = 1:length(animalprefix_list)
    animalprefix = animalprefix_list{theAnimal};
    if strcmp(animalprefix,'HPa')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPa_direct/HPa_direct/');
        dir = ('D:\HPExp_data\HPa_direct\HPa_direct\');
    elseif strcmp(animalprefix,'HPb')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPb_direct/');
        dir = ('D:\HPExp_data\HPb_direct\');
    elseif strcmp(animalprefix,'HPc')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPc_direct/');
        dir = ('D:\HPExp_data\HPc_direct\');
    end
    tetinfo = loaddatastruct(dir, animalprefix, 'tetinfo');
    cellinfo = loaddatastruct(dir, animalprefix, 'cellinfo');
    for day = day_list
        if day == 1
            % epoch list
            eps =[1, 4, 6, 7]; %for Day 1 %PRE, W1, W1, POST-W1
        else
            eps = [1, 2, 4, 5]; %for Day 6 %PRE, W1, W2, POST-W2
        end
        
        for ep = eps
            % hp tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                               if isfield(tetinfo{day}{ep}{ttt},'descrip')
                                    if strcmp(tetinfo{day}{ep}{ttt}.descrip,'riptet')
                                        detect_tet_tmp = [detect_tet_tmp ttt];
                                    end
                                end
                        end
            end
            if ep > 1
                detect_tet1 = intersect(detect_tet_tmp,detect_tet1);
            else 
                detect_tet1 = detect_tet_tmp;
            end
            % ctx tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                                if strcmp(tetinfo{day}{ep}{ttt}.area,'PFC') % Cortical neurons first
                                     if max(length(cellinfo{day}{ep}) >= ttt)
                                        if ~isempty(cellinfo{day}{ep}{ttt})
                                            detect_tet_tmp = [detect_tet_tmp ttt];
                                        end
                                     end
                                end
                        end
            end
            if ep > 1
                detect_tet2 = intersect(detect_tet_tmp,detect_tet2);
            else 
                detect_tet2 = detect_tet_tmp;
            end
            
        end
        tetnum_hp = length(detect_tet1);
        tetnum_ctx = length(detect_tet2);
        C_ctx = repmat(1:tetnum_ctx,tetnum_hp,1);
        C_ctx = reshape(C_ctx,1,[]);
        C_hp = repmat(1:tetnum_hp,1,tetnum_ctx);
        pairind = [C_ctx' C_hp'];% (ctx, hp)
        
        for i = 1:length(pairind(:,1))
            cid_ctx = pairind(i,1);
            cid_hp = pairind(i,2);
            tet2 = detect_tet2(cid_ctx);
            tet1 = detect_tet1(cid_hp);
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(1), tet1, tet2, 1, 1,'fpass',[0 400]);%pre
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(1));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(2:3), tet1, tet2, 1, 1,'fpass',[0 400]);%run
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(2));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(4), tet1, tet2, 1, 1,'fpass',[0 400]);%post
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(4));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
        end
    end
end

%% 
nn = 1;
% hp-hp coherence ref
for theAnimal = 1:length(animalprefix_list)
    animalprefix = animalprefix_list{theAnimal};
    if strcmp(animalprefix,'HPa')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPa_direct/HPa_direct/');
        dir = ('D:\HPExp_data\HPa_direct\HPa_direct\');
    elseif strcmp(animalprefix,'HPb')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPb_direct/');
        dir = ('D:\HPExp_data\HPb_direct\');
    elseif strcmp(animalprefix,'HPc')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPc_direct/');
        dir = ('D:\HPExp_data\HPc_direct\');
    end
    tetinfo = loaddatastruct(dir, animalprefix, 'tetinfo');
    cellinfo = loaddatastruct(dir, animalprefix, 'cellinfo');
    for day = day_list
        if day == 1
            % epoch list
            eps =[1, 4, 6, 7]; %for Day 1 %PRE, W1, W1, POST-W1
        else
            eps = [1, 2, 4, 5]; %for Day 6 %PRE, W1, W2, POST-W2
        end
        
        for ep = eps
            % hp tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                               if isfield(tetinfo{day}{ep}{ttt},'descrip')
                                    if strcmp(tetinfo{day}{ep}{ttt}.descrip,'riptet')
                                        detect_tet_tmp = [detect_tet_tmp ttt];
                                    end
                                end
                        end
            end
            if ep > 1
                detect_tet = intersect(detect_tet_tmp,detect_tet);
            else 
                detect_tet = detect_tet_tmp;
            end
            
        end
        tetnum_hp = length(detect_tet);
        pairind = combnk(1:tetnum_hp,2);
        
        for i = 1:length(pairind(:,1))
            cid1 = pairind(i,1);
            cid2 = pairind(i,2);
            tet2 = detect_tet(cid2);
            tet1 = detect_tet(cid1);
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(1), tet1, tet2, 0, 1,'fpass',[0 400]);%pre
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(1));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(2:3), tet1, tet2, 0, 1,'fpass',[0 400]);%run
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(2));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(4), tet1, tet2, 0, 1,'fpass',[0 400]);%post
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(4));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
        end
    end
end

%% 
nn = 1;
% hp-pfc coherence ref
for theAnimal = 1:length(animalprefix_list)
    animalprefix = animalprefix_list{theAnimal};
    if strcmp(animalprefix,'HPa')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPa_direct/HPa_direct/');
        dir = ('D:\HPExp_data\HPa_direct\HPa_direct\');
    elseif strcmp(animalprefix,'HPb')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPb_direct/');
        dir = ('D:\HPExp_data\HPb_direct\');
    elseif strcmp(animalprefix,'HPc')
    %     dir = ('/Volumes/Seagate Backup/Mac_Backup/EEG/HPc_direct/');
        dir = ('D:\HPExp_data\HPc_direct\');
    end
    tetinfo = loaddatastruct(dir, animalprefix, 'tetinfo');
    cellinfo = loaddatastruct(dir, animalprefix, 'cellinfo');
    for day = day_list
        if day == 1
            % epoch list
            eps =[1, 4, 6, 7]; %for Day 1 %PRE, W1, W1, POST-W1
        else
            eps = [1, 2, 4, 5]; %for Day 6 %PRE, W1, W2, POST-W2
        end
        
        for ep = eps
            % hp tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                               if isfield(tetinfo{day}{ep}{ttt},'descrip')
                                    if strcmp(tetinfo{day}{ep}{ttt}.descrip,'riptet')
                                        detect_tet_tmp = [detect_tet_tmp ttt];
                                    end
                                end
                        end
            end
            if ep > 1
                detect_tet1 = intersect(detect_tet_tmp,detect_tet1);
            else 
                detect_tet1 = detect_tet_tmp;
            end
            % ctx tet list
            detect_tet_tmp = [];
            for ttt = 1:length(tetinfo{day}{ep})
                        if ~isempty(tetinfo{day}{ep}{ttt})
                                if strcmp(tetinfo{day}{ep}{ttt}.area,'PFC') % Cortical neurons first
                                     if max(length(cellinfo{day}{ep}) >= ttt)
                                        if ~isempty(cellinfo{day}{ep}{ttt})
                                            detect_tet_tmp = [detect_tet_tmp ttt];
                                        end
                                     end
                                end
                        end
            end
            if ep > 1
                detect_tet2 = intersect(detect_tet_tmp,detect_tet2);
            else 
                detect_tet2 = detect_tet_tmp;
            end
            
        end
        tetnum_hp = length(detect_tet1);
        tetnum_ctx = length(detect_tet2);
        C_ctx = repmat(1:tetnum_ctx,tetnum_hp,1);
        C_ctx = reshape(C_ctx,1,[]);
        C_hp = repmat(1:tetnum_hp,1,tetnum_ctx);
        pairind = [C_ctx' C_hp'];% (ctx, hp)
        
        for i = 1:length(pairind(:,1))
            cid_ctx = pairind(i,1);
            cid_hp = pairind(i,2);
            tet2 = detect_tet2(cid_ctx);
            tet1 = detect_tet1(cid_hp);
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(1), tet1, tet2, 0, 1,'fpass',[0 400]);%pre
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(1));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(2:3), tet1, tet2, 0, 1,'fpass',[0 400]);%run
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(2));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
            try
                wb_HPexpt_riptrigcohgram_multitaper(animalprefix, day, eps(4), tet1, tet2, 0, 1,'fpass',[0 400]);%post
            catch
                errmsg1{nn} = sprintf('Process day %d epoch %d failed!',day, eps(4));
                nn = nn + 1;
            end
            cd('C:\Users\wbtang\Desktop\HMM\Spectrogram_Analysis\');
        end
    end
end
