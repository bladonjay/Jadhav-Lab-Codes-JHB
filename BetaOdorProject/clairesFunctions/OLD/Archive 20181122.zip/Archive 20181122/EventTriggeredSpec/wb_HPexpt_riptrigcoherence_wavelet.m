function wb_HPexpt_riptrigcoherence_wavelet(prefix, day, epochs, tet1, tet2, do_wrtgnd, figopt, varargin)
% Wenbo: Dec 2016, wavelet method to get ripple-triggered time-frequency
% coherence between tet1 and tet 2
% using Morlet wavelet, half length = 7 (default)
addpath(genpath('C:\Users\wbtang\Documents\MATLAB\toolbox'))

if nargin<1
    keyboard
    error('Please enter Expt Prefix and Day No!');
end
if nargin<2
    keyboard
    error('Please enter Day No!');
end
if nargin<3
    epochs = 1; 
end
if nargin<4
    tet1 = 1; 
end
if nargin<5
    tet2 = 1; 
end
if nargin<6
    do_wrtgnd=1; % Whether to also do with respect to ground
end

if nargin<7
    figopt=0; 
end


%-------wavelet params----------%
fmin = 0.001;% f = fmin*fs
fmax = 1/5; % 300 Hz
N = 84;% 84 wavelets
half_width = 7; % Morlet wavelet, half length 7 cycles

%-------self-defined wavelet params----------%
for option = 1:2:length(varargin)-1
    switch varargin{option}
          case 'half_width' % half length of the Morlet wavelet
              half_width = varargin{option+1};
          case 'fmin' % lower frequency bound of the analyzed signal
              fmin =  varargin{option+1};
          case 'fmax' % upper frequency bound of the analyzed signal
              fmax =  varargin{option+1};
          case 'N' % number of analyzed voices
              N =  varargin{option+1};
    end
end

        
% SET DATA
% -------------------------------------------
switch prefix
    case 'ER1'
        directoryname = 'D:\SingledayExp_data\ER1_NEW_direct2\';
    case 'KL8'
        directoryname = 'D:\SingledayExp_data\KL8_direct';
end


dir2=directoryname;

if (day<10)
    daystring = ['0',num2str(day)];
else
    daystring = num2str(day);
end

epochstring = [];
for i = 1:length(epochs)
    epochstring = [epochstring,'-0',num2str(epochs(i))];
end


if (tet1<10)
    tetstring1 = ['0',num2str(tet1)];
else
    tetstring1 = num2str(tet1);
end

if (tet2<10)
    tetstring2 = ['0',num2str(tet2)];
else
    tetstring2 = num2str(tet2);
end

% STA_all = [];
for ep=1:length(epochs)
    epoch = epochs(ep);
    % Nrippleamp EW - Get relevant ripple triggers directly
    ripampfile = sprintf('%s/%srippledamp%02d.mat', directoryname, prefix, day);
    load(ripampfile);
    rip_starttime = rippleamp{day}{epoch}(:,1);
    triggers = rip_starttime;
    
    cd([directoryname,'/EEG/']);
    if epoch<10
           sep = ['0',num2str(epoch)];
    else
           sep = num2str(epoch);
    end
    if do_wrtgnd==1
            curreeggndfile = [dir2,'/EEG/',prefix,'eeg',daystring,'-',sep,'-',tetstring1];
            load(curreeggndfile);
            lfp1 = (eeg{day}{epoch}{tet1}.data)';
            time1 = geteegtimes(eeg{day}{epoch}{tet1}) ; % construct time array
            fs = eeg{day}{epoch}{tet1}.samprate;
            clear eeg
            
            curreeggndfile = [dir2,'/EEG/',prefix,'eeg',daystring,'-',sep,'-',tetstring2];
            load(curreeggndfile);
            lfp2 = (eeg{day}{epoch}{tet2}.data)';
            time2 = geteegtimes(eeg{day}{epoch}{tet2}) ; % construct time array
            clear eeg
            if ~all(time2 == time1)% check if time vectors are matched
                lfp2 = interp1(time2,lfp2,time1,'nearest');
            end
    else
            curreegfile = [dir2,'/EEG/',prefix,'eegref', daystring,'-',sep,'-',tetstring1];
            load(curreegfile);
            lfp1 = (eegref{day}{epoch}{tet1}.data)';
            time1 = geteegtimes(eegref{day}{epoch}{tet1}) ; % construct time array
            fs = eegref{day}{epoch}{tet1}.samprate;
            clear eegref
            
            curreegfile = [dir2,'/EEG/',prefix,'eegref',daystring,'-',sep,'-',tetstring2];
            load(curreegfile);
            lfp2 = (eegref{day}{epoch}{tet2}.data)';
            time2 = geteegtimes(eegref{day}{epoch}{tet2}) ; % construct time array
            clear eegref
            if ~all(time2 == time1)% check if time vectors are matched
                lfp2 = interp1(time2,lfp2,time1,'nearest');
            end
    end
    nanidx = find(isnan(lfp2));
    if ~isempty(nanidx)
        lfp2(nanidx) =  lfp2(nanidx -1);
    end
   %-------wavelet scalogram----------%
   [tfr1,t,f,wt1]=tfrscalo(lfp1',1:length(lfp1),half_width,fmin,fmax,N);% Morlet wavelet, half length = 7 (default)
   [tfr2,~,~,wt2]=tfrscalo(lfp2',1:length(lfp2),half_width,fmin,fmax,N);% Morlet wavelet, half length = 7 (default)
   %-----cross wavelet-----%
   tfr12 = conj(wt1).*wt2;
   %----smooth factor----%
   ff = f.*fs;
   % non-smoothed
   cfs1 = abs(wt1).^2;
   cfs2 = abs(wt2).^2;
   cfs12 = tfr12;
   
   Rsq = (cfs12)./sqrt(cfs1.*cfs2);% wavelet cross-spectrum
   Coh = abs(Rsq); % wavelet coherence
   Phi = angle(Rsq);% phase of wavelet cross-spectrum
    
   
     %-------SWR-triggered cohgram----------%
     winstart = -0.5;%-0.5s
     winend = 0.5;% 0.5s
     win = winstart:1/round(fs):winend;
     winidx = round(win.*round(fs));
     STA = zeros(N,length(win));
     for j = 1:length(triggers)
         if triggers(j) > (time1(1) + 2) && triggers(j) < (time1(end) - 2)% throw away the first  and last 2s
             [junk, trigidx] = min(abs(time1 - triggers(j)));
             STA = STA + Rsq(:,trigidx+winidx);
         end
     end
     STA = STA./j;
     STA = abs(STA);
     STA_all(:,:,ep) = STA;
end

if length(epochs) > 1
    STA = mean(STA_all,3); % Mean across epochs
end


% ------------------------------------------------
% PLOT
% -------------------------------------------------

if figopt ==1
    figdir = [dir2,'/EEGSpec_wb/'];
    set(0,'defaultaxesfontweight','normal'); set(0,'defaultaxeslinewidth',2);
    set(0,'defaultaxesfontsize',16);
    tfont = 18; % title font
    xfont = 16;
    yfont = 16;
    clr = {'b','r','g','c','m','y','k','r'};

    figure(100),
    set(gcf,'Position',[820 660 560 420])
    imagesc(win, 1:N, STA)
    colormap(jet)
    colorbar
    set(gca,'YDir','normal')
    set(gca,'YTick',1:10:length(Coh(:,1)));
    set(gca,'YTicklabel',round(ff(1:10:end)));
    if do_wrtgnd==1 
       title(['Tet ',num2str(tet1),'-Tet ',num2str(tet2),' Phase coherence wrt GND aligned to ', 'ripple'],'FontSize',18,'Fontweight','normal');
       figfile = [figdir,prefix,'_Day',num2str(day),'-Ep',epochstring,'_Tet',num2str(tet1),'_Tet',num2str(tet2),'_phicoh_wavelet','_','ripple','_','GND'];
    else
        title(['Tet ',num2str(tet1),'-Tet ',num2str(tet2),' Phase coherence aligned to ','ripple'],'FontSize',18,'Fontweight','normal');
        figfile = [figdir,prefix,'_Day',num2str(day),'-Ep',epochstring,'_Tet',num2str(tet1),'_Tet',num2str(tet2),'_phicoh_wavelet','_','ripple','_','REF'];
    end
    print('-djpeg', figfile);
    saveas(gcf,figfile,'fig');
end

% ------------------------------------------------
% Save
% -------------------------------------------------
eegtrigcohwavelet{day}{epoch}{tet1}{tet2}.Ctime = win;
eegtrigcohwavelet{day}{epoch}{tet1}{tet2}.Cfreq = ff;
eegtrigcohwavelet{day}{epoch}{tet1}{tet2}.Cmean = STA';

% eegcohwavelet{day}{epoch}{tet1}{tet2}.Ctime = time1; % too big, dont save
% eegcohwavelet{day}{epoch}{tet1}{tet2}.Cfreq = ff;
% % eegcohwavelet{day}{epoch}{tet1}{tet2}.Rsq = Rsq;
% eegcohwavelet{day}{epoch}{tet1}{tet2}.Coh = Coh;
% eegcohwavelet{day}{epoch}{tet1}{tet2}.Phi = Phi;


if do_wrtgnd==1 
    savefile = [figdir,prefix,'eegtrigphicohwavelet',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2];
%     savefile_all = [figdir,prefix,'eegcohwavelet',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2];

else
    savefile = [figdir,prefix,'eegtrigphicohwavelet',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2,'-REF'];
%     savefile_all = [figdir,prefix,'eegcohwavelet',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2,'-REF'];
end

save(savefile,'eegtrigcohwavelet');
% save(savefile_all,'eegcohwavelet');

if do_wrtgnd==1 
    disp(['Save ', 'eegtrigphicohwavelet',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2])
else
    disp(['Save ', 'eegtrigphicohwavelet',daystring,'-Ep',epochstring,'-Tet-',tetstring1,'-Tet-',tetstring2,'-REF'])
end