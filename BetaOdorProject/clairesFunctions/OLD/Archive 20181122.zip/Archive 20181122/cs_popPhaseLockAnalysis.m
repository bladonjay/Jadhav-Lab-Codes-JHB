function cs_popPhaseLockAnalysis(dataDir, figDir, tetareas, trigtype, numbins, plOnly)

%cs_popPhaseLockAnalysis('D:\OdorPlaceAssociation\AnalysesAcrossAnimals\', 'D:\Figures\', {'CA1','PFC','OB'}, 50, 1)
%cs_popPhaseLockAnalysis('F:\Data\OdorPlaceAssociation\AnalysesAcrossAnimals\', 'F:\Figures\', {'CA1','PFC','OB'}, 'correctTriggers', 50, 1)


bins = -pi:(2*pi/numbins):pi;

cellregions = {'CA1','PFC'};

if strcmp(trigtype,'allTriggers')
    trigstr = '';
else
    trigstr = ['_',trigtype];
end


for t = 1:length(tetareas)
    tet = tetareas{t};
    
    
    
    load([dataDir,'betaModv2_',tet,trigstr,'.mat'])
    
    
        
        for c = 1:length(cellregions)
            cellregion = cellregions{c};
            switch cellregion
                case 'CA1'
                    %color = [0.8594 0.0781 0.2344];
                    color = rgb('MediumPurple');
                case 'PFC'
                    %color = [0.1172 0.5625 1];
                    color = rgb('MediumAquamarine');
            end
            
            
            eval(['betaMod = betaMod_',cellregion,'cells;']);
           
            if plOnly == 1
                plstr = '_PhaseLocked';
                pvals = [betaMod.prayl];
                sig = betaMod(pvals < 0.05);
                spikephase = vertcat(sig.spikephase);
            else
                spikephase = vertcat(betaMod.spikephase);
            end
            
            count = histcounts(spikephase, numbins);
        
            %Rayleigh and Modulation: Originally in lorenlab Functions folder
            stats = rayleigh_test(spikephase); % stats.p and stats.Z, and stats.n
            [mod, ph] = modulation(spikephase);
            phdeg = ph*(180/pi); %convert to degrees 
    %      Von Mises Distribution - From Circular Stats toolbox
            [betahat, kappa] = circ_vmpar(spikephase); % Better to give raw data. Can also give binned data.
            betahat_deg = betahat*(180/pi);
            [prayl, zrayl] = circ_rtest(spikephase);

            alpha = linspace(-pi, pi, numbins)';
            [pdf] = circ_vmpdf(alpha,betahat,kappa);
        
            populationBetaMod.stats = stats;
            populationBetaMod.mod = mod;
            populationBetaMod.ph = ph;
            populationBetaMod.stats = phdeg;
            populationBetaMod.betahat = betahat;
            populationBetaMod.kappa = kappa;
            populationBetaMod.betahat = betahat;
            populationBetaMod.betahat_deg = betahat_deg;
            populationBetaMod.prayl = prayl;
            populationBetaMod.zrayl = zrayl;
            populationBetaMod.alpha = alpha;
            populationBetaMod.pdf = pdf;
            
            eval(['populationBetaMod_',cellregion,'cells = populationBetaMod;']);
            
            
           figure; 
           set(gcf, 'Position', [50 50 800 600]);
%         subplot(2,1,1);
%         hold on;

         newcount = [count,count(2:end)];
         bincenters = bins(2:end) - (bins(2)-bins(1))/2;
         newbins = [bincenters - pi, bincenters(2:end) + pi];
    
        out = bar(newbins, newcount, 'hist');
        xticks([-2*pi -pi 0 pi 2*pi ])
        xticklabels({'-2\pi','-\pi','0','\pi','2\pi'})
        %title([cellarea, ' to ', tet]);
        h = findobj(gca,'Type','patch');
        set(h,'EdgeColor',color); 
        
        hold on
        binnum = lookup(betahat,alpha);
        
        if count(binnum) == 0
            pdf = pdf.*(1/pdf(binnum));
        else
            pdf = pdf.*(count(binnum)/pdf(binnum));
        end
        
        newpdf = [pdf;pdf(2:end)];
        newalpha = [alpha-pi; alpha(2:end)+pi];
        plot(newalpha,newpdf,'k','LineWidth',3,'Color','k');
        
        
        plot([0 0], [0 newpdf(lookup(0,newalpha))], 'k--','LineWidth',2.5)
        plot([-pi -pi], [0 newpdf(lookup(-pi,newalpha))], 'k:','LineWidth',2.5)
        plot([pi pi], [0 newpdf(lookup(pi,newalpha))], 'k:','LineWidth',2.5)
        
        set(gca,'XLim',[-2*pi-0.5 2*pi]); set(gca,'YLim',[0 max(count)+0.5]); ylabel('Number of Spikes'); xlabel('Phase of Beta Oscillation'); set(out,'FaceColor',color);
        set(out, 'EdgeColor',color);
        set(gca,'fontsize',32);
        box off
        
        figtitle = [cellregion,'to',tet,'beta_population',trigstr];
        newfigfile = [figDir,'NicePPTFigures\',figtitle];
        saveas(gcf,newfigfile,'fig');
        print('-dpdf', newfigfile);
        print('-djpeg', newfigfile);
        
        end
        save([dataDir,'betaMod_population_',tet,trigstr,'.mat'],'populationBetaMod_CA1cells','populationBetaMod_PFCcells');
        pause
end



        
        
                
                
                
            
        
      