function cs_getAvgNosepokeDuration(animals)

%This function finds the average length of nosepokes for each animal on each day. Uses
%odorTriggers file for NP start, then finds the following NP downstate for
%NP off. 

%topDir should be TOP directory containing all animal expt folders

for a = 1:length(animals)
    animal = animals{a} ;
    
    dataDir = [topDir, animal, 'Expt\',animal,'_direct\'];
    cd(dataDir)
    
    odorTrigFiles = dir([animal,'odorTriggers*']);
    
    for f = 1:length(odorTrigFiles)
        
        file = odorTrigFiles(f).name;
        load(file)
        day = find(~cellfun(@isempty,odorTriggers));
        epochs = find(~cellfun(@isempty,odorTriggers{day})); 
        
        daystr = getTwoDigitNumber(day);
        load([animal,'DIO',daystr,'.mat'])
        
        for e = 1:length(epochs)
            disp(['Doing ', animal, ' Day ', daystr])
            epoch = epochs(e);
            
            triggers = odorTriggers{day}{epoch}.allTriggers;
            npDIOtime = dio{day}{epoch}{5}.time;
            npDIOstate = dio{day}{epoch}{5}.state;
            
            for t = 1:length(triggers)
                trig = triggers(t);
                [junk, timeInd] = min(abs(npDIOtime - trig));
                npTimes(t,1) = npDIOtime(timeInd);
                offTimes(t,1) = npDIOtime(timeInd+1);
                npState(t,1) = npDIOstate(timeInd);
            end
            
            check = all(npState);
            if check ~= 1
                warning('Trigger times may not be correct - aligned to DIO downstates');
                
            end
            
            meanEpochDuration(e) = mean(offTimes-npTimes);
            
        end
        
        meanDuration = mean(meanEpochDuration);
        npDuration{1,day} = meanDuration;
        
    end
    
    filename = [dataDir, animal,'npDuration.mat'];
    save(filename,'npDuration')
    
    cd(topDir)
    
end
