function makeTrajSubparts_slope ( dataDir, fileprefix, days, epochList, varargin )
%MAKETRAJSUBPARTS separates the track into parts for further analysis
%
%   Currently this is only for the T-maze and separates it into following zones ...
%   1. Nose-poke and turn around
%   2. Stem/run-down including choice point
%   3. Choice-point exit and outer arms
%
%   INPUTS
%   ------
%   1. 'dataDir'        -- chr string containing /path/to/animal_direct/folder
%   2. 'fileprefix'     -- chr string containing animal ID prefixed before processed files. E.g. 'JS11'
%   3. {days}           -- vector of days over which the function needs to run
%   4. {[runEpochs]}    -- cell array with vector(s) of run epochs, each vector containing the dayRunEpochs
%
%   Optional VARiable ARGument INputs
%   ---------------------------------
%   5. 'saveFigForRef'              -- chr flag to save generated figures for reference. Default = 'y'
%   6. 'plotDir'                    -- chr flag to enter sub-directory to save figures. Default = '/Plots'
%   7. 'classifier'                 -- chr flag to choose type of classification ...
%                                      choices being (1) manual 'manual' or (2) trajectory means 'trajMean'
%                                      Default = 'trajMean'
%
%   EXAMPLE:
%   makeTrajSubparts('/path/to/animal/direct', 'CS31', {3}, {[2 4 6]}, 'saveFigForRef', 'y', 'plotDir', '/Plots', 'classifier', 'trajMean' )
%
%   NOTE
%   ----
%   'dataDir' is to be put in MATLAB format **without** a trailing slash
%   'plotDir' should start with a slash as shown in example
%
%
%   VERSION:        2.1. 
%   VERSION NOTE:   Added trajMean as classifier, included failsafes and refinement options, and enabled option to choose classifier
%   DATE:           August 9th, 2017
%   AUTHOR:         Suman Guha


%% set variable defaults
classifier='trajMean';
saveFigForRef='n';
plotDir='/Plots';
numDelta = 2;

% modify base varibles depending on varargins
for varNum=1:2:length(varargin)
    switch varargin{varNum}
        case 'classifier'
            classifier=varargin{varNum+1};
        case 'saveFigForRef'
            saveFigForRef=varargin{varNum+1};
        case 'plotDir'
            plotDir=varargin{varNum+1};
        case 'numDelta'
            numDelta = varargin{varNum+1};
    end
end

%% function core

cd(dataDir);

switch classifier
    case 'trajMean'
        % classifier specific variables
        frameWidth=10;
        x_interval=200;
        % modify base varibles depending on varargins
        for varNum=1:2:length(varargin)
            switch varargin{varNum}
                case 'frameWidth'
                    frameWidth=varargin{varNum+1};
                case 'x_interval'
                    x_interval=varargin{varNum+1};
            end
        end
        cd(dataDir);
        for dayNum=1:size(days, 2)
            
            % STEP 1: extract day and epoch to subset to pos struct
            day=days(1,dayNum); %CS 8/10/17 - fixed typo 
            epochs=epochList{1,dayNum};
            pos=load([dataDir, '/', sprintf('%spos%02d.mat', fileprefix, day)]);
            % epoch specific tasks
            for epochNum=1:length(epochs)
                epoch=epochs(epochNum);
                epochPosStruct=pos.pos{1,day}{1,epoch}.data;
                
                % STEP 2: get trial bounds and interpolate dio times to pos times
                if ~isempty(dir([dataDir, '/', sprintf('%srunTrialBounds%02d.mat', fileprefix, day)]))
                    % get time-bounds for individual trials in an epoch
                    dayTrialBounds=load([dataDir, '/', sprintf('%srunTrialBounds%02d.mat', fileprefix, day)]);
                    epochTrialBounds=dayTrialBounds.runTrialBounds{1,day}{1,epoch}.data;
                    % interpolating epochTrialBounds [time] to pos [time]
                    epochTrialBounds=[ ...
                        epochPosStruct(lookup(epochTrialBounds(:,1), epochPosStruct(:,1)), 1), ...
                        epochPosStruct(lookup(epochTrialBounds(:,2), epochPosStruct(:,1)), 1), ...
                        epochTrialBounds(:,[3 4]), ...
                        epochPosStruct(lookup(epochTrialBounds(:,5), epochPosStruct(:,1)), 1), ...
                        epochPosStruct(lookup(epochTrialBounds(:,6), epochPosStruct(:,1)), 1), ...
                        epochPosStruct(lookup(epochTrialBounds(:,7), epochPosStruct(:,1)), 1), ...
                        epochPosStruct(lookup(epochTrialBounds(:,8), epochPosStruct(:,1)), 1)  ...
                        ];
                else
                    error('Aborting Plot ...\nTrial time-bounds have not been generated\nRun "getTrialBounds"');
                end
                
                % EPOCH SPECIFIC CLASSIFICTION
                %goToNextEpoch='No'; %CS edit
%                 while ~strcmp(goToNextEpoch, 'Proceed')
                    % STEP 3: Group trajectories into left/right and collate left/right x-y coordinates for each of these groups
                    % Left Trials   =   left correct or right incorrect
                    % Right Trials  =   right correct or left incorrect
                    leftTrials=epochTrialBounds((epochTrialBounds(:, 3) == 1 & epochTrialBounds(:, 4) == 1) | (epochTrialBounds(:, 3) == 0 & epochTrialBounds(:, 4) == 0), :);
                    rightTrials=epochTrialBounds((epochTrialBounds(:, 3) == 0 & epochTrialBounds(:, 4) == 1) | (epochTrialBounds(:, 3) == 1 & epochTrialBounds(:, 4) == 0), :);
                    % plot L/R trajectories
                    close all;
                    trajPlot=figure;
                    hold on;
                    title(sprintf('%s-Day%02d-Epoch%02d\nL/R Trajectories', fileprefix, day, epoch));
                    % plot the whole epoch as scaffold
                    plot(epochPosStruct(:,2), epochPosStruct(:,3), 'Color', [0 0 0]+0.85);
                    % plot left trials
                    for trialNum=1:size(leftTrials, 1)
                        % get the current trial when all time is within the starttime and endtime
                        currTrial=epochPosStruct((epochPosStruct(:, 1) >= leftTrials(trialNum,1) & epochPosStruct(:, 1) <= leftTrials(trialNum,2)), :);
                        plot(currTrial(:,2), currTrial(:,3), 'Color', [230 97 1] / 255);
                    end
                    % plot right trials
                    for trialNum=1:size(rightTrials, 1)
                        % get the current trial when all time is within the starttime and endtime
                        currTrial=epochPosStruct((epochPosStruct(:, 1) >= rightTrials(trialNum,1) & epochPosStruct(:, 1) <= rightTrials(trialNum,2)), :);
                        plot(currTrial(:,2), currTrial(:,3), 'Color', [94 60 153] / 255);
                    end
                    % CHECKPOINT to manually select left/right trajectories in case of anomaly
                    goForward1='No';
                    while(strcmp(goForward1, 'No'))
                        confirmClassif=questdlg('L/R traj correctly classified, or manually select individual traj(s)?', 'Confirm', 'Correct', 'Select Individual', 'Select Individual');
                        if (strcmp(confirmClassif, 'Correct'))
                            goForward1='Yes';
                        end
                        while (~strcmp(confirmClassif, 'Correct'))
                            close all;
                            % select left trajectories
                            figure;
                            hold on;
                            title(sprintf('%s-Day%02d-Epoch%02d\nSelect Left Trajectories', fileprefix, day, epoch));
                            % plot the whole epoch as scaffold
                            plot(epochPosStruct(:,2), epochPosStruct(:,3), 'Color', [0 0 0]+0.85);
                            chosenLeftTrials=[];
                            for trialNum=1:size(leftTrials, 1)
                                % get the current trial when all time is within the starttime and endtime
                                currTrial=epochPosStruct((epochPosStruct(:, 1) >= leftTrials(trialNum,1) & epochPosStruct(:, 1) <= leftTrials(trialNum,2)), :);
                                traj=plot(currTrial(:,2), currTrial(:,3), 'Color', [230 97 1] / 255);
                                keepTraj=questdlg('Select this trajectory?', 'Confirm', 'Yes', 'No', 'Cancel', 'No');
                                switch keepTraj
                                    case 'Yes'
                                        chosenLeftTrials=[chosenLeftTrials; leftTrials(trialNum, :)];
                                        delete(traj); %CS added 8/10/2017 - deletes traj plot after selecting it for clarity 
                                    case 'No'
                                        delete(traj);
                                    case 'Cancel'
                                        close all
                                        error('Terminated selection');
                                end
                            end
                            leftTrials=chosenLeftTrials;
                            close all;
                            % select right trajectories
                            figure;
                            hold on;
                            title(sprintf('%s-Day%02d-Epoch%02d\nSelect Right Trajectories', fileprefix, day, epoch));
                            % plot the whole epoch as scaffold
                            plot(epochPosStruct(:,2), epochPosStruct(:,3), 'Color', [0 0 0]+0.85);
                            chosenRightTrials=[];
                            for trialNum=1:size(rightTrials, 1)
                                % get the current trial when all time is within the starttime and endtime
                                currTrial=epochPosStruct((epochPosStruct(:, 1) >= rightTrials(trialNum,1) & epochPosStruct(:, 1) <= rightTrials(trialNum,2)), :);
                                traj=plot(currTrial(:,2), currTrial(:,3), 'Color', [94 60 153] / 255);
                                keepTraj=questdlg('Select this trajectory?', 'Confirm', 'Yes', 'No', 'Cancel', 'No');
                                switch keepTraj
                                    case 'Yes'
                                        chosenRightTrials=[chosenRightTrials; rightTrials(trialNum, :)];
                                        delete(traj); %CS added 8/10/2017 - deletes traj plot after selecting it for clarity 
                                    case 'No'
                                        delete(traj);
                                    case 'Cancel'
                                        close all
                                        error('Terminated selection');
                                end
                            end
                            rightTrials=chosenRightTrials;
                            close all;
                            % confirmatory plot of L/R trajectories
                            trajPlot=figure;
                            hold on;
                            title(sprintf('%s-Day%02d-Epoch%02d\nL/R Trajectories', fileprefix, day, epoch));
                            % plot the whole epoch as scaffold
                            plot(epochPosStruct(:,2), epochPosStruct(:,3), 'Color', [0 0 0]+0.85);
                            % plot left trials
                            for trialNum=1:size(leftTrials, 1)
                                % get the current trial when all time is within the starttime and endtime
                                currTrial=epochPosStruct((epochPosStruct(:, 1) >= leftTrials(trialNum,1) & epochPosStruct(:, 1) <= leftTrials(trialNum,2)), :);
                                plot(currTrial(:,2), currTrial(:,3), 'Color', [230 97 1] / 255);
                            end
                            % plot right trials
                            for trialNum=1:size(rightTrials, 1)
                                % get the current trial when all time is within the starttime and endtime
                                currTrial=epochPosStruct((epochPosStruct(:, 1) >= rightTrials(trialNum,1) & epochPosStruct(:, 1) <= rightTrials(trialNum,2)), :);
                                plot(currTrial(:,2), currTrial(:,3), 'Color', [94 60 153] / 255);
                            end
                            confirmClassif=questdlg('L/R traj correctly classified, or redo?', 'Confirm', 'Correct', 'Redo', 'Redo');
                            if strcmp(confirmClassif, 'Correct')
                                goForward1='Yes';
                            end
                        end
                    end
                    % save (or not) plot for reference
                    
                    if (strcmp(saveFigForRef, 'y'))
                        if exist([dataDir plotDir], 'dir') ~= 7
                            mkdir([dataDir plotDir]);
                        end
                        saveas(trajPlot, [dataDir, '/Plots/', sprintf('%s-%02d-%02d-%s', fileprefix, day, epoch, 'LeftRightTrajs')], 'jpeg');
                    end
                    close all;
                    % Choose bounds and confirm
                    
                    goToNextEpoch='No';
                    while ~strcmp(goToNextEpoch, 'Proceed')
                    goForward='No';
                    while ~strcmp(goForward, 'Yes')
                        
                        % STEP 4.1:   get user generated 'vertical' point(s) when the 'horizontal' positions begin to converge and diverge
                        %           convergence = end of turn-around, divergence = exit decision point
                        figure;
                        hold on
                        title(sprintf('%s-Day%02d-Epoch%02d\nSelect y-coords where L-/R-trajs meet/separate', fileprefix, day, epoch))
                        % plot the whole epoch as scaffold
                        plot(epochPosStruct(:,2), epochPosStruct(:,3), 'Color', [0 0 0]+0.85)
                        % plot left trials
                        for trialNum=1:size(leftTrials, 1)
                            % get the current trial when all time is within the starttime and endtime
                            currTrial=epochPosStruct((epochPosStruct(:, 1) >= leftTrials(trialNum,1) & epochPosStruct(:, 1) <= leftTrials(trialNum,2)), :);
                            plot(currTrial(:,2), currTrial(:,3), 'Color', [230 97 1] / 255)
                        end
                        % plot right trials
                        for trialNum=1:size(rightTrials, 1)
                            % get the current trial when all time is within the starttime and endtime
                            currTrial=epochPosStruct((epochPosStruct(:, 1) >= rightTrials(trialNum,1) & epochPosStruct(:, 1) <= rightTrials(trialNum,2)), :);
                            plot(currTrial(:,2), currTrial(:,3), 'Color', [94 60 153] / 255)
                        end
                        [x, yLimits] = ginput(2);
                        hline(yLimits, 'black:');
                        
                        % STEP 4.2: get user generated 'horizontal' bounds for that excludes the reward wells
                        figure;
                        hold on;
                        title(sprintf('%s-Day%02d-Epoch%02d\nSelect x-bound that exclude reward wells', fileprefix, day, epoch))
                        % plot the whole epoch as scaffold
                        plot(epochPosStruct(:,2), epochPosStruct(:,3), 'Color', [0 0 0]+0.85)
                        % plot left trials
                        for trialNum=1:size(leftTrials, 1)
                            % get the current trial when all time is within the starttime and endtime
                            currTrial=epochPosStruct((epochPosStruct(:, 1) >= leftTrials(trialNum,1) & epochPosStruct(:, 1) <= leftTrials(trialNum,2)), :);
                            plot(currTrial(:,2), currTrial(:,3), 'Color', [230 97 1] / 255)
                        end
                        % plot right trials
                        for trialNum=1:size(rightTrials, 1)
                            % get the current trial when all time is within the starttime and endtime
                            currTrial=epochPosStruct((epochPosStruct(:, 1) >= rightTrials(trialNum,1) & epochPosStruct(:, 1) <= rightTrials(trialNum,2)), :);
                            plot(currTrial(:,2), currTrial(:,3), 'Color', [94 60 153] / 255)
                        end
                        [xLimits, y] = ginput(2);
                        vline(xLimits, 'black:');
                        
                        % STEP 5:   For each trajectory get the time when the animal's y-pos reached these 'vertical' point
                        %   - loop over left trials
                        %   - find time for each trial when animal's pos reached the y-limit for convergence/divergence
                        %   - collate those times in a column matrix
                        %   - repeat these steps for right trials
                        leftConvergeTimes=zeros(size(leftTrials, 1), 1);
                        leftDivergeTimes=zeros(size(leftTrials, 1), 1);
                        for trialNum=1:size(leftTrials, 1)
                            currTrial=epochPosStruct((epochPosStruct(:, 1) >= leftTrials(trialNum,1) & epochPosStruct(:, 1) <= leftTrials(trialNum,2)), :);
                            lookupTable=sortrows(currTrial, 3);
                            yPosTime=lookupTable(lookup(yLimits(1), lookupTable(:,3)), 1);
                            leftConvergeTimes(trialNum)=yPosTime;
                            yPosTime=lookupTable(lookup(yLimits(2), lookupTable(:,3)), 1);
                            leftDivergeTimes(trialNum)=yPosTime;
                        end
                        rightConvergeTimes=zeros(size(rightTrials, 1), 1);
                        rightDivergeTimes=zeros(size(rightTrials, 1), 1);
                        for trialNum=1:size(rightTrials, 1)
                            currTrial=epochPosStruct((epochPosStruct(:, 1) >= rightTrials(trialNum,1) & epochPosStruct(:, 1) <= rightTrials(trialNum,2)), :);
                            lookupTable=sortrows(currTrial, 3);
                            yPosTime=lookupTable(lookup(yLimits(1), lookupTable(:,3)), 1);
                            rightConvergeTimes(trialNum)=yPosTime;
                            yPosTime=lookupTable(lookup(yLimits(2), lookupTable(:,3)), 1);
                            rightDivergeTimes(trialNum)=yPosTime;
                        end
                        
                        % STEP 6:   in each trial, plot -/+ $frameWidth(default = 10) frames from convergence/divergence point
                        % - loop over L/R trials to generate a matrix of time(normalized)-xCoord and plot that ...
                        % 1. converge
                        leftConvergeTrajs=[];
                        normLeftConvergeTrajs=[];
                        figure;
                        hold on;
                        for trialNum=1:size(leftConvergeTimes, 1)
                            rowIndex=find(epochPosStruct(:,1)==leftConvergeTimes(trialNum));
                            trialTraj=epochPosStruct(rowIndex-frameWidth:rowIndex+frameWidth, :);
                            normTrialTraj(:,1)=trialTraj(:,1)-min(trialTraj(:,1));
                            normTrialTraj(:,2:5)=trialTraj(:,2:5);
                            plot(normTrialTraj(:,1), normTrialTraj(:,2), 'Color', [230 97 1] / 255)
                            leftConvergeTrajs=[leftConvergeTrajs, trialTraj];
                            normLeftConvergeTrajs=[normLeftConvergeTrajs, normTrialTraj];
                        end
                        rightConvergeTrajs=[];
                        normRightConvergeTrajs=[];
                        for trialNum=1:size(rightConvergeTimes, 1)
                            rowIndex=find(epochPosStruct(:,1)==rightConvergeTimes(trialNum));
                            trialTraj=epochPosStruct(rowIndex-frameWidth:rowIndex+frameWidth, :);
                            normTrialTraj(:,1)=trialTraj(:,1)-min(trialTraj(:,1));
                            normTrialTraj(:,2:5)=trialTraj(:,2:5);
                            plot(normTrialTraj(:,1), normTrialTraj(:,2), 'Color', [94 60 153] / 255)
                            rightConvergeTrajs=[rightConvergeTrajs, trialTraj];
                            normRightConvergeTrajs=[normRightConvergeTrajs, normTrialTraj];
                        end
                        % 2. diverge
                        leftDivergeTrajs=[];
                        normLeftDivergeTrajs=[];
                        figure;
                        hold on;
                        for trialNum=1:size(leftDivergeTimes, 1)
                            rowIndex=find(epochPosStruct(:,1)==leftDivergeTimes(trialNum));
                            trialTraj=epochPosStruct(rowIndex-frameWidth:rowIndex+frameWidth, :);
                            normTrialTraj(:,1)=trialTraj(:,1)-min(trialTraj(:,1));
                            normTrialTraj(:,2:5)=trialTraj(:,2:5);
                            plot(normTrialTraj(:,1), normTrialTraj(:,2), 'Color', [230 97 1] / 255)
                            leftDivergeTrajs=[leftDivergeTrajs, trialTraj];
                            normLeftDivergeTrajs=[normLeftDivergeTrajs, normTrialTraj];
                        end
                        rightDivergeTrajs=[];
                        normRightDivergeTrajs=[];
                        for trialNum=1:size(rightDivergeTimes, 1)
                            rowIndex=find(epochPosStruct(:,1)==rightDivergeTimes(trialNum));
                            trialTraj=epochPosStruct(rowIndex-frameWidth:rowIndex+frameWidth, :);
                            normTrialTraj(:,1)=trialTraj(:,1)-min(trialTraj(:,1));
                            normTrialTraj(:,2:5)=trialTraj(:,2:5);
                            plot(normTrialTraj(:,1), normTrialTraj(:,2), 'Color', [94 60 153] / 255)
                            rightDivergeTrajs=[rightDivergeTrajs, trialTraj];
                            normRightDivergeTrajs=[normRightDivergeTrajs, normTrialTraj];
                        end
                        % CHECKPOINT: adjust 'vertical point(s)' for converge/diverge point(s)
                        goForward=questdlg('Window spans turn-around point?', 'Confirm', 'Yes', 'No', 'No');
                        close all;
                    end
                    
                    % STEP 7:   use a polynomial plot-fitting to generate mean +/- SEM trajectories
                    % 7.1.    collate all the L/R Conv/Div trajectories data
                    % left::conv
                    leftConvFit=[];
                    for colNum=1:5:size(normLeftConvergeTrajs, 2)
%                         leftConvFit=[leftConvFit; normLeftConvergeTrajs(:, [colNum colNum + 1])];
                            leftConvFit=[leftConvFit; normLeftConvergeTrajs(:, [colNum + 1 colNum + 2])];
                    end
                    leftConvFit=sortrows(leftConvFit, 1);
                    % right::conv
                    rightConvFit=[];
                    for colNum=1:5:size(normRightConvergeTrajs, 2)
                        %rightConvFit=[rightConvFit; normRightConvergeTrajs(:, [colNum colNum + 1])];
                        rightConvFit=[rightConvFit; normRightConvergeTrajs(:, [colNum + 1 colNum + 2])];
                    end
                    rightConvFit=sortrows(rightConvFit, 1);
                    % left::div
                    leftDivFit=[];
                    for colNum=1:5:size(normLeftDivergeTrajs, 2)
                        %leftDivFit=[leftDivFit; normLeftDivergeTrajs(:, [colNum colNum + 1])];
                        leftDivFit=[leftDivFit; normLeftDivergeTrajs(:, [colNum + 1 colNum + 2])];
                    end
                    leftDivFit=sortrows(leftDivFit, 1);
                    % right::div
                    rightDivFit=[];
                    for colNum=1:5:size(normRightDivergeTrajs, 2)
                        %rightDivFit=[rightDivFit; normRightDivergeTrajs(:, [colNum colNum + 1])];
                        rightDivFit=[rightDivFit; normRightDivergeTrajs(:, [colNum + 1 colNum + 2])];
                    end
                    rightDivFit=sortrows(rightDivFit, 1);
                    % 7.2.  fit a polynomial & get x-y bounds
                    [p_leftConv, error_leftConv]    =   polyfit(leftConvFit(:,2), leftConvFit(:,1), 2);
                    [p_rightConv, error_rightConv]  =   polyfit(rightConvFit(:,2), rightConvFit(:,1), 2);
                    
                    % calculate derivative of polynomial
                    derL = polyder(p_leftConv);
                    derR = polyder(p_rightConv);
                    
                    %finds the point on the polynomial where the slope
                    %equals 20 degrees
                    slopeL = -1/3;
                    pointL = (slopeL - derL(2))/derL(1);
                    
                    slopeR = 1/3;
                    pointR = (slopeR - derR(2))/derR(1);
                    
                    
                    convergenceBound = mean([pointL, pointR]);
                    
               
                    
                    %Repeat for divergence point
                  
                    [p_leftDiv, error_leftDiv]    =   polyfit(leftDivFit(:,2), leftDivFit(:,1), 2);
                    [p_rightDiv, error_rightDiv]  =   polyfit(rightDivFit(:,2), rightDivFit(:,1), 2);
                    
                    % calculate derivative of polynomial, find point where 
                    derL = polyder(p_leftDiv);
                    derR = polyder(p_rightDiv);
                    
                    
   
                    slopeL = 1/3;
                    pointL = (slopeL - derL(2))/derL(1);
                    
                    slopeR = -1/3;
                    pointR = (slopeR - derR(2))/derR(1);
                    
                    
                    divergenceBound = mean([pointL, pointR]);
                    
                    
                    
                    %STEP 8.1: use the polynomial to create fitted lines to
                    %plot
                    x_leftConv = unique(leftConvFit(:,2));
                    x_rightConv = unique(rightConvFit(:,2));
                    x_leftDiv = unique(leftDivFit(:,2));
                    x_rightDiv = unique(rightDivFit(:,2));
                    
                    
                    y_leftConv = polyval(p_leftConv, x_leftConv);
                    y_rightConv = polyval(p_rightConv, x_rightConv);
                    y_leftDiv = polyval(p_leftDiv, x_leftDiv);
                    y_rightDiv = polyval(p_rightDiv, x_rightDiv);
                    
                    
                    
                    % STEP 8.2  plot fitted curve with bounds and converge/diverge points
                    % left/right converge
                    figure;
                    hold on;
                    % left converge::raw data
                    for colNum=1:5:size(normLeftConvergeTrajs, 2)
                        plot(normLeftConvergeTrajs(:, colNum+2), normLeftConvergeTrajs(:, colNum+1), ...
                            'o', ...
                            'MarkerFaceColor', [253,184,99]/255, ...
                            'MarkerEdgeColor', 'none' ...
                            );
                    end
                    % right converge::raw data
                    for colNum=1:5:size(normRightConvergeTrajs, 2)
                        plot(normRightConvergeTrajs(:, colNum +2), normRightConvergeTrajs(:, colNum+1), ...
                            'o', ...
                            'MarkerFaceColor', [178,171,210]/255, ...
                            'MarkerEdgeColor', 'none' ...
                            );
                    end
                    % plot fitted curve(s)
                    plot(x_leftConv, y_leftConv, ...
                        '--', ...
                        'LineWidth', 2, ...
                        'Color', [230,97,1] / 255 ...
                        );

                    plot(x_rightConv, y_rightConv, ...
                        '--', ...
                        'LineWidth', 2, ...
                        'Color', [94,60,153] / 255 ...
                        );
%                     
                    vline(convergenceBound, 'black--');
                    % save (or not) plot for reference
                    if (strcmp(saveFigForRef, 'y'))
                        if exist([dataDir plotDir], 'dir') ~= 7
                            mkdir([dataDir plotDir]);
                        end
                        saveas(gcf, [dataDir, '/Plots/', sprintf('%s-%02d-%02d-%s', fileprefix, day, epoch, 'FittedConvergePoint')], 'jpeg');
                    end
                    
                    % left/right diverge
                    figure;
                    hold on;
                    % left diverge
                    for colNum=1:5:size(normLeftDivergeTrajs, 2)
                        plot(normLeftDivergeTrajs(:, colNum +2), normLeftDivergeTrajs(:, colNum+1), ...
                            'o', ...
                            'MarkerFaceColor', [253,184,99]/255, ...
                            'MarkerEdgeColor', 'none' ...
                            );
                    end
                    % right diverge
                    for colNum=1:5:size(normRightDivergeTrajs, 2)
                        plot(normRightDivergeTrajs(:, colNum + 2), normRightDivergeTrajs(:, colNum+1), ...
                            'o', ...
                            'MarkerFaceColor', [178,171,210]/255, ...
                            'MarkerEdgeColor', 'none' ...
                            );
                    end
                    % plot fitted curve(s)
                    plot(x_leftDiv, y_leftDiv, ...
                        '--', ...
                        'LineWidth', 2, ...
                        'Color', [230,97,1] / 255 ...
                        );
                  
                    plot(x_rightDiv, y_rightDiv, ...
                        '--', ...
                        'LineWidth', 2, ...
                        'Color', [94,60,153] / 255 ...
                        );
                  
                    vline(divergenceBound, 'black--');
                    % save (or not) plot for reference
                    if (strcmp(saveFigForRef, 'y'))
                        if exist([dataDir plotDir], 'dir') ~= 7
                            mkdir([dataDir plotDir]);
                        end
                        saveas(gcf, [dataDir, '/Plots/', sprintf('%s-%02d-%02d-%s', fileprefix, day, epoch, 'FittedDivergePoint')], 'jpeg');
                    end
  
                    
                    % STEP 9: interpolate into previous data structures to divide trajectories into subparts
                    % - use converge/divergeCoords(1,1) to get the time
                    % - use that time to match time (lookup) with first normLeftTraj and get that index
                    % - index of normLeftTraj and leftTraj were the same for each trial, so use that to get the (un-normalized) time
                    % - use this time to lookup in epochPosStruct to find the y-values for converge and diverge
                    % -
                    
                    %convergeTime    =   leftConvergeTrajs(lookup(convergenceBound, normLeftConvergeTrajs(:,3)), 1);
                    y_converge      =   convergenceBound;
                    
                    %divergeTime    =   leftDivergeTrajs(lookup(divergenceBound, normLeftDivergeTrajs(:,3)), 1);
                    y_diverge      =   divergenceBound;
                    
                    
                    
                    % STEP 10: confirmation plot and save data
                    updatedTrialBounds=[];
                    updatedEpochTrialBounds=nan(size(epochTrialBounds, 1), size(epochTrialBounds, 2)+2);
                    figure
                    hold on
                    plot(epochPosStruct(:,2), epochPosStruct(:,3), 'Color', [0, 0, 0] + 0.85);
                    for trialNum=1:size(epochTrialBounds, 1)
                        % get the current trial when all time is within the starttime and endtime
                        currTrial       =   epochPosStruct((epochPosStruct(:, 1) >= epochTrialBounds(trialNum,1) & epochPosStruct(:, 1) <= epochTrialBounds(trialNum,2)), :);
                        currTrialSubset =   currTrial(currTrial(:,2) >= xLimits(1) & currTrial(:,2) <= xLimits(2), :);
                        currTrialSubset =   sortrows(currTrialSubset, 3);
                        stem_inTime     =   currTrialSubset(lookup(y_converge, currTrialSubset(:,3)), 1);
                        stem_outTime    =   currTrialSubset(lookup(y_diverge, currTrialSubset(:,3)), 1);
                        updatedTrialBounds=[epochTrialBounds(trialNum, :), stem_inTime, stem_outTime];
                        updatedEpochTrialBounds(trialNum, :)=updatedTrialBounds;
                        updatedTrialBounds=[];
                        zone1   =   currTrial(currTrial(:,1) <= stem_inTime, :);
                        zone2   =   currTrial((currTrial(:,1) > stem_inTime & currTrial(:,1) < stem_outTime), :);
                        zone3   =   currTrial(currTrial(:,1) >= stem_outTime, :);
                        z1 = plot(zone1(:,2), zone1(:,3), 'Color', [27,158,119]/255);
                        z2 = plot(zone2(:,2), zone2(:,3), 'Color', [217,95,2]/255);
                        z3 = plot(zone3(:,2), zone3(:,3), 'Color', [117,112,179]/255);
                        %delete(z1); delete(z2), delete(z3); %CS added
                        %8/10/2017 - clears plot after each traj for
                        %clarity during debugging
                    end
                    % save (or not) plot for reference
                    if (strcmp(saveFigForRef, 'y'))
                        if exist([dataDir plotDir], 'dir') ~= 7
                            mkdir([dataDir plotDir]);
                        end
                        saveas(gcf, [dataDir, '/Plots/', sprintf('%s-%02d-%02d-%s', fileprefix, day, epoch, 'TrajSubparts')], 'jpeg');
                    end
                    
                    % STEP 11: Save data and wait for user signal to proceed
                    runTrajBounds{1,day}{1,epoch}.data=updatedEpochTrialBounds;
                    runTrajBounds{1,day}{1,epoch}.fields='starttime endtime left/right(1/0) Corr/Incorr(1/0) sniffstart sniffend rewardstart rewardend stem_inTime stem_outTime';
                    goToNextEpoch=questdlg('Proceed to next epoch, or redo?', 'Confirm', 'Proceed', 'Redo', 'Redo');
                end
            end
            save(sprintf('%s%srunTrajBounds%02d.mat', [dataDir '/'], fileprefix, day), 'runTrajBounds');
            clear runTrajBounds
        end
        close all;
        clear all;
        
    case 'manual'
        for dayNum=1:size(days, 2)
            % extract day and epoch to subset to pos struct
            day=days{1,dayNum};
            epochs=epochList{1,dayNum};
            pos=load([dataDir, '/', sprintf('%spos%02d.mat', fileprefix, day)]);
            % epoch specific tasks
            for epochNum=1:length(epochs)
                epoch=epochs(epochNum);
                epochPosStruct=pos.pos{1,day}{1,epoch}.data;
                if ~isempty(dir([dataDir, '/', sprintf('%srunTrialBounds%02d.mat', fileprefix, day)]))
                    % get time-bounds for individual trials in an epoch
                    dayTrialBounds=load([dataDir, '/', sprintf('%srunTrialBounds%02d.mat', fileprefix, day)]);
                    epochTrialBounds=dayTrialBounds.runTrialBounds{1,day}{1,epoch}.data;
                    % interpolating epochTrialBounds [time] to pos [time]
                    epochTrialBounds=[ ...
                        epochPosStruct(lookup(epochTrialBounds(:,1), epochPosStruct(:,1)), 1), ...
                        epochPosStruct(lookup(epochTrialBounds(:,2), epochPosStruct(:,1)), 1), ...
                        epochTrialBounds(:,[3 4]), ...
                        epochPosStruct(lookup(epochTrialBounds(:,5), epochPosStruct(:,1)), 1), ...
                        epochPosStruct(lookup(epochTrialBounds(:,6), epochPosStruct(:,1)), 1), ...
                        epochPosStruct(lookup(epochTrialBounds(:,7), epochPosStruct(:,1)), 1), ...
                        epochPosStruct(lookup(epochTrialBounds(:,8), epochPosStruct(:,1)), 1)  ...
                        ];
                else
                    error('Aborting Plot ...\nTrial time-bounds have not been generated\nRun "getTrialBounds"');
                end
                % plot figure and gather bounds: first three y-points, then the x-bounds
                nextEpoch='No';
                while (strcmp(nextEpoch, 'No'))
                    % gather y-bounds
                    nextBound='No';
                    figure
                    hold on
                    title(sprintf('Draw Y-Bounds for %s-Day%02d-Epoch%02d', fileprefix, day, epoch))
                    % plot the whole epoch
                    plot(epochPosStruct(:,2), epochPosStruct(:,3), 'Color', [0 0 0] + 0.75)
                    % plot individual trials
                    for trialNum=1:length(epochTrialBounds)
                        % get the current trial when all time is within the starttime and endtime
                        currTrial=epochPosStruct((epochPosStruct(:, 1) >= epochTrialBounds(trialNum,1) & epochPosStruct(:, 1) <= epochTrialBounds(trialNum,2)), :);
                        plot(currTrial(:,2), currTrial(:,3), 'Color', 'black')
                    end
                    while(strcmp(nextBound, 'No'))
                        % get inputs from user
                        [ x, yLimits ] = ginput(3);
                        % plot lines to give feedback on user-generated bounds
                        line1=plot(x(1:2), yLimits(1:2), 'g', 'LineWidth', 2.5);
                        line2=plot(x(2:3), yLimits(2:3), 'r', 'LineWidth', 2.5);
                        % confirm bounds
                        nextBound=questdlg('Are the Y-Bounds correct?', 'Confirm', 'Yes', 'No', 'No');
                        if strcmp(nextBound, 'No')
                            delete(line1)
                            delete(line2)
                        end
                    end
                    if (strcmp(saveFigForRef, 'y'))
                        if exist([dataDir plotDir], 'dir') ~= 7
                            mkdir([dataDir plotDir]);
                        end
                        saveas(gcf, [dataDir, '/Plots/', sprintf('%s-%02d-%02d-%s', fileprefix, day, epoch, 'YBounds')], 'jpeg');
                    end
                    % gather x-bounds
                    nextBound='No';
                    figure
                    hold on
                    title(sprintf('Draw X-Bounds for %s-Day%02d-Epoch%02d', fileprefix, day, epoch))
                    % plot individual trajectories for the whole epoch
                    plot(epochPosStruct(:,2), epochPosStruct(:,3), 'Color', [0 0 0] + 0.75)
                    for trialNum=1:size(epochTrialBounds, 1)
                        % get the current trial when all time is within the starttime and endtime
                        currTrial=epochPosStruct((epochPosStruct(:, 1) >= epochTrialBounds(trialNum,1) & epochPosStruct(:, 1) <= epochTrialBounds(trialNum,2)), :);
                        plot(currTrial(:,2), currTrial(:,3), 'Color', 'black')
                    end
                    while(strcmp(nextBound, 'No'))
                        [ xLimits, y ] = ginput(2);
                        % plot lines to give feedback on user-generated bounds
                        line1=plot(xLimits, y, 'b', 'LineWidth', 2.5);
                        % confirm bounds
                        nextBound=questdlg('Are the X-bounds correct?', 'Confirm', 'Yes', 'No', 'No');
                        if strcmp(nextBound, 'No')
                            delete(line1, line2)
                        end
                    end
                    if (strcmp(saveFigForRef, 'y'))
                        if exist([dataDir plotDir], 'dir') ~= 7
                            mkdir([dataDir plotDir]);
                        end
                        saveas(gcf, [dataDir, '/Plots/', sprintf('%s-%02d-%02d-%s', fileprefix, day, epoch, 'XBounds')], 'jpeg');
                    end
                    plotTrials=questdlg('Plot to confirm classification?', 'Optional', 'Yes', 'No', 'No');
                    if (strcmp(plotTrials, 'Yes'))
                        % confimation plot
                        figure
                        hold on
                        plot(epochPosStruct(:,2), epochPosStruct(:,3), 'Color', [0, 0, 0] + 0.85)
                        for trialNum=1:size(epochTrialBounds, 1)
                            % get the current trial when all time is within the starttime and endtime
                            currTrial=epochPosStruct((epochPosStruct(:, 1) >= epochTrialBounds(trialNum,1) & epochPosStruct(:, 1) <= epochTrialBounds(trialNum,2)), :);
                            zone1=currTrial((currTrial(:,3) > yLimits(2)), :);
                            zone2=currTrial((currTrial(:,3) > yLimits(3) & currTrial(:,3) < yLimits(2) & currTrial(:,2) > min(xLimits) & currTrial(:,2) < max(xLimits)), :);
                            zone3=currTrial((currTrial(:,3) < min(yLimits)),:);
                            plot(zone1(:,2), zone1(:,3), 'Color', 'g')
                            plot(zone2(:,2), zone2(:,3), 'Color', 'r')
                            plot(zone3(:,2), zone3(:,3), 'Color', 'b')
                        end
                        if (strcmp(saveFigForRef, 'y'))
                            if exist([dataDir plotDir], 'dir') ~= 7
                                mkdir([dataDir plotDir]);
                            end
                            saveas(gcf, [dataDir, '/Plots/', sprintf('%s-%02d-%02d-%s', fileprefix, day, epoch, 'TrajParts')], 'jpeg');
                        end
                        plotEachTraj=questdlg('Plot and **save** individual trajectory for later validation?', 'Optional', 'Yes', 'No', 'No');
                        % plot individual trajectories
                        if (strcmp(plotEachTraj, 'Yes'))
                            for trialNum=1:size(epochTrialBounds, 1)
                                figure
                                hold on
                                title(sprintf('%s-Day%02d-Epoch%02d-Traj%02d', fileprefix, day, epoch, trialNum))
                                % plot the whole epoch
                                plot(epochPosStruct(:,2), epochPosStruct(:,3), 'Color', [0 0 0] + 0.75)
                                % plot individual trials
                                % get the current trial when all time is within the starttime and endtime
                                currTrial=epochPosStruct((epochPosStruct(:, 1) >= epochTrialBounds(trialNum,1) & epochPosStruct(:, 1) <= epochTrialBounds(trialNum,2)), :);
                                zone1=currTrial((currTrial(:,3) > yLimits(2)), :);
                                zone2=currTrial((currTrial(:,3) > yLimits(3) & currTrial(:,3) < yLimits(2) & currTrial(:,2) > min(xLimits) & currTrial(:,2) < max(xLimits)), :);
                                zone3=currTrial((currTrial(:,3) < min(yLimits)),:);
                                plot(zone1(:,2), zone1(:,3), 'Color', 'g')
                                plot(zone2(:,2), zone2(:,3), 'Color', 'r')
                                plot(zone3(:,2), zone3(:,3), 'Color', 'b')
                                if exist([dataDir plotDir], 'dir') ~= 7
                                    mkdir([dataDir plotDir]);
                                end
                                saveas(gcf, [dataDir, plotDir, '/', sprintf('%s-Day%02d-Epoch%02d-Traj%02d', fileprefix, day, epoch, trialNum)], 'jpeg');
                            end
                        end
                    end
                    nextEpoch=questdlg('Proceed to next Epoch', 'Confirm', 'Yes', 'No', 'No');
                    close all
                    pathBounds{1,day}{1,epoch}.xLimits=xLimits;
                    pathBounds{1,day}{1,epoch}.yLimits=yLimits;
                    pathBounds{1,day}{1,epoch}.description='xLimits=bounds of the nose-poke well. yLimits=start of nose-poke, start of stem, end of stem';
                    save(sprintf('%spathBounds%02d-%02d.mat', fileprefix, day, epoch), 'pathBounds');
                end
            end
        end
end