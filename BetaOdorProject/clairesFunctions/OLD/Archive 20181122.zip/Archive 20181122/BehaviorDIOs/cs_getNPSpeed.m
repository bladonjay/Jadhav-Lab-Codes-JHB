function meanSpeed = cs_getNPSpeed(dataDir, animal, win)
%cs_getNPSpeed('E:\CS31Expt\CS31_direct\', 'CS31', [0.5 1])

%gets the mean movement speed around nosepoke triggers, one file for each
%animal. 

%use [1 1] as default

odorTriggerFiles = dir([dataDir,animal,'odorTriggers*']);

velAll = [];
for d = 1:length(odorTriggerFiles);
    daystring = getTwoDigitNumber(d);
    load([dataDir,odorTriggerFiles(d).name])
    load([dataDir,animal,'pos',daystring,'.mat'])
    
    for e = 1:length(odorTriggers{1,d})
         if ~isempty(odorTriggers{1,d}{1,e})
             triggers = odorTriggers{1,d}{1,e}.allTriggers;
             
             vel = pos{1,d}{1,e}.data(:,5);
             time = pos{1,d}{1,e}.data(:,1);
             
             for t = 1:length(triggers)
                 trialwin = [(triggers(t) - win(1)) (triggers(t) + win(2))]; 
                 trialstart = time(lookup(trialwin(1),time));
                 trialend = time(lookup(trialwin(2),time));
                 
                 speedWin = vel(time>=trialstart & time <=trialend);
                 speedWin = speedWin(1:45); %sometimes it gets 46 time points instead? 
                 
                 velAll(t,:) = speedWin';
             end
         end
    end
end

meanSpeed = mean(velAll,1);
save([dataDir,animal,'nosepokeSpeed.mat'],'meanSpeed');

plot(meanSpeed);


             
  