%get average speed of animal across whole trial 

function cs_avgTrialSpeed(animals, topDir, trialLength, figDir)


speedallanimals = [];
for a = 1:length(animals)
    speedalltrials = [];
    animal = animals{a};
    dataDir = [topDir, animal, 'Expt\', animal, '_direct\'];
    trialfiles  = dir([dataDir, animal, 'runTrialBounds*']);
    posfiles = dir([dataDir, animal, 'pos*']);
    
    for f = 1:length(trialfiles)
        load(trialfiles(f).name);
        load(posfiles(f).name);
        runTrialBounds = runTrialBounds{1,f};
        epochs = find(~cellfun(@isempty, runTrialBounds));
        
        
        for ep = 1:length(epochs)
            nosepokestart = runTrialBounds{1,epochs(ep)}.data(:,5);
            trialstart = nosepokestart - 1;
            trialend = nosepokestart + trialLength + 2; %get times from 1 second before nosepoke to 2 seconds after avg trial time
            
            posvelocity = pos{1,f}{1,epochs(ep)}.data(:,5);
            postime = pos{1,f}{1,epochs(ep)}.data(:,1);
            
            for t = 1:length(trialstart)
                trialinds = find(postime > trialstart(t) & postime < trialend(t));
                trialvel = posvelocity(trialinds)';
                speedalltrials = stack(speedalltrials, trialvel);
                
                trialtime = postime(trialinds)' - nosepokestart(t);
            end
        end
        
    end
    animalmeanspeed = mean(speedalltrials);
    speedallanimals = stack(speedallanimals, animalmeanspeed);
end
speedallanimals = speedallanimals(:,1:end-1);

meanSpeed = mean(speedallanimals);
figure('Position', [300, 300, 850, 250]) , hold on
plot(trialtime, speedallanimals', 'k')
plot(trialtime, meanSpeed, 'LineWidth', 3)
vline(0,'r')
text(0.1,45,'Nosepoke Onset','color','r')

vline(trialLength, 'r')
text(trialLength+.1,45,'Average Reward Onset','color','r')

ylabel('Speed (cm/s)')
xlabel('Time after nosepoke onset');

title('Average Speed During Trial'); %allows underscores in fig titles


figfile = [figDir,'1d_AvgSpeedDuringTrial'];

print('-djpeg', figfile);
print('-dpng', figfile);
saveas(gcf,figfile,'fig');