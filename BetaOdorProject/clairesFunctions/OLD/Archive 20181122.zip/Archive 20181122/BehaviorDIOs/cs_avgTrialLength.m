function avgTrialLength = cs_avgTrialLength(animals, topDir)
%calculates average trial time across animals. A full trial is considered
%the time between nosepoke start and reward start. 

allTrials = [];

for a = 1:length(animals)
    animal = animals{a};
    dataDir = [topDir, animal, 'Expt\', animal, '_direct\'];
    files  = dir([dataDir, animal, 'runTrialBounds*']);
    
    for f = 1:length(files)
        load(files(f).name);
        runTrialBounds = runTrialBounds{1,f};
        epochs = find(~cellfun(@isempty, runTrialBounds));
        
        for ep = 1:length(epochs)
            trials = runTrialBounds{1,epochs(ep)}.data(:,7) - runTrialBounds{1,epochs(ep)}.data(:,5);
            allTrials = [allTrials; trials];
        end
    end
end

avgTrialLength = mean(allTrials);