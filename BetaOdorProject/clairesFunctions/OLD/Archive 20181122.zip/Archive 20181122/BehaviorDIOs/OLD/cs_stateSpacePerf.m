% Claire Symanski - March 2 2017
% Takes Binary performance files and combines them for specified days, and
% outputs statespace plot

function cs_stateSpacePerf(prefix, days)
%directoryname = ['E:\',prefix,'Expt\', prefix, '_direct\BinaryPerf\'];
directoryname = ['D:\OdorPlaceAssociation\',prefix,'Expt\', prefix, '_direct\BinaryPerf\'];

cd(directoryname);



PerfAll = [];
for d = 1:length(days)
    day = days(d);
    
    daystring = getTwoDigitNumber(day);
    
    perfiles = dir(['BinaryPerf',daystring,'*.mat']);
    for f = 1:length(perfiles)
        
        file = load(perfiles(f).name);
        
        epochPerf = file.CorrectIncorrectBinary;
        
        PerfAll = [PerfAll; epochPerf];
        clear file
    end
end

getestprobcorrect_niceplot(PerfAll, 0.5, 2); 

%figdir = 'E:\Figures\Behavior\';
figdir = 'D:\Figures\Behavior\';
cd(figdir)

daystring = num2str(days);

figfile = [figdir,prefix,'_StateSpace_Days',daystring];
    print('-dpdf', figfile);
    print('-djpeg', figfile);
     
   saveas(gcf,figfile,'fig');

    
