function cs_calcMeanStemTime(filepath, animals)

%lab comp filepath = 'D:\OdorPlaceAssociation\'

%enter all animals as cell array e.g. {'CS31','CS33','CS34'}
cd(filepath)
all = [];
for a = 1:length(animals)
    animal = animals{a};
    
    cd([animal,'Expt\',animal,'_direct\'])
    stemFiles = dir([animal,'stemTimes*']);
    stemFiles = {stemFiles.name};
    
    for f = 1:length(stemFiles)
        load(stemFiles{f})
        
        %get Day number from filename
        del = {[animal,'stemTimes'],'.mat'};
        daystr = erase(stemFiles{f}, del);
            if daystr(1) == 0
                day = str2num(daystr(2));
            else
                day = str2num(daystr);
            end
        
        runeps = find(~cellfun(@isempty,stemTimes{1,day}));
        
        for e = 1:length(runeps)
            epoch = runeps(e);
            
            times = stemTimes{1,day}{1,epoch}.allTriggers;
            diff = times(:,2)-times(:,1);
            
            all = [all ; diff];
        end
        
    end
    cd(filepath)
end

meanStemTime = mean(all)

save([filepath,'AnalysesAcrossAnimals\meanStemTime.mat'],'meanStemTime');
        