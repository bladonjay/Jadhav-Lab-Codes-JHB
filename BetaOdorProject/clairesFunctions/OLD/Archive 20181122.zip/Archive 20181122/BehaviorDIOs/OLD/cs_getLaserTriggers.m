function  cs_getLaserTriggers(prefix, dataDir, days, runEps)
%'D:\OdorPlaceAssociation\SG7Expt\SG7_direct\' for lab computer

%Assumes laser is on DIO channel 4

cd(dataDir)

for d = 1:length(days)
    day = days(d);
    daystring = getTwoDigitNumber(day);
    
    all_DIOs = load([prefix,'DIO', daystring, '.mat']);
    numEpochs = length(all_DIOs.dio{1,day});
    
    for e = 1:length(runEps)
        ep = runEps(e);
        epstr = getTwoDigitNumber(ep);
        
        if ep <= numEpochs
            
        triggers = all_DIOs.dio{1,day}{1,ep}{1,20}.time;
        
        nosepokes = all_DIOs.dio{1,day}{1,ep}{1,5}.time;
        triggers = triggers >= nosepokes(1,1) & triggers <= nosepokes(end,1); %only take triggers between first and last nosepoke
        
        laserTriggers{1,day}{1,ep}.allTriggers = triggers;
        
        end
        
    end
    
    save([dataDir,prefix, 'laserTriggers', daystring],'laserTriggers');
    clear laserTriggers
end
