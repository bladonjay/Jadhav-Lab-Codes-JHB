function [avgTimeStopped] = cs_getAvgTimeStopped(prefix, days, epochs, behavType, maxSpeed)

dir = ['E:\Data\OdorPlaceAssociation\', prefix, '_direct\'];
cd(dir)

durations = [];
for d = 1:length(days)
    day = days(d);
    if (day<10)
        daystring = ['0',num2str(day)];
    else
        daystring = num2str(day);
    end
    
    posfile = load([prefix, 'pos', daystring, '.mat']);
        pos = posfile.pos;
        
    for ep=1:length(epochs)
        
        epoch = epochs(ep);
        if (epoch<10)
            epstring = ['0',num2str(epoch)];
        else
            epstring = num2str(epoch);
        end
        
        switch behavType
            case 'odor'
                trigfile = load(['OdorTriggers', daystring, '-', epstring, '.mat']);
                triggers = trigfile.OdorTriggers_all;
            case 'reward'
                rewardfile = load(['RewardTimes', daystring, '-', epstring, '.mat']);
                triggers = rewardfile.RewardTimes;
        end
        
        velocity = pos{1,day}{1,epoch}.data(:,5);
        posTime = pos{1,day}{1,epoch}.data(:,1);
        
         for tr = 1:length(triggers)
            trig = triggers(tr);
            
            [~, posIndex] = min(abs(posTime-trig));
            
            indsBefore = 1:posIndex;
            prevMoving = find(velocity(indsBefore) > maxSpeed);
            startTime = posTime(prevMoving(end) + 1);
%          
            indsAfter = posIndex:length(posTime);
            nextMoving = indsAfter(find(velocity(indsAfter) > maxSpeed));
            endTime = posTime(nextMoving(1) - 1);
            
            stopDuration = endTime - startTime;
           
            durations(end+1) = stopDuration;
         end
    end
end

avgTimeStopped = mean(durations);
        
        %look at previous number, if less than maxSpeed, continue to next
        %one, continue until you find one that is greater than maxSpeed,
        %last one is start time. Do for times after trigger, gives end
        %time. Calculate difference between start and end times, store in
        %matrix. 