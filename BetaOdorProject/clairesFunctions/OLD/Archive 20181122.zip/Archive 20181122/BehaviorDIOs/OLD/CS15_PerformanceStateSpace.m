[Day1Perf] = getPerfBinary('CS15_20161031_');
[Day2Perf] = getPerfBinary('CS15_20161101_');
[Day3Perf] = getPerfBinary('CS15_20161102_');
[Day4Perf] = getPerfBinary('CS15_20161103_');
Day4Perf = Day4Perf(1:69,:);

OdorPlacePerf = [Day1Perf; Day2Perf; Day3Perf; Day4Perf];
[OdorPlacePerformance] = getestprobcorrect(OdorPlacePerf, 0.5, 0); 


[Day4PerfNovel] = getPerfBinary('CS15_20161103_');
Day4PerfNovel = Day4PerfNovel(70:96,:);
[Day5PerfNovel] = getPerfBinary('CS15_20161104_');

OdorPlaceNovel = [Day4PerfNovel; Day5PerfNovel];
[OdorPlaceNovelPerformance] = getestprobcorrect(OdorPlaceNovel,0.5,0);


[Day6PerfSwitch] = getPerfBinary('CS15_20161105_');
Day6PerfSwitch= Day6PerfSwitch(45:163,:);
[Day7PerfSwitch] = getPerfBinary('CS15_20161106_');
[Day8PerfSwitch] = getPerfBinary('CS15_20161107_');
[Day9PerfSwitch1] = getPerfBinary_ss('CS15_20161108_RuleSwitchOdorPlace1');
[Day9PerfSwitch3] = getPerfBinary_ss('CS15_20161108_RuleSwitchOdorPlace3');

OdorPlaceSwitch = [Day6PerfSwitch; Day7PerfSwitch; Day8PerfSwitch; Day9PerfSwitch1; Day9PerfSwitch3];
[OdorPlaceSwitchPerformance] = getestprobcorrect(OdorPlaceSwitch,0.5,1);