function cs_getStemTimes(dataDir, animalID, days)

cd(dataDir)

for d = 1:length(days)
    day = days(d);
    daystr = getTwoDigitNumber(day);
    load([animalID, 'runTrajBounds',daystr,'.mat'])
    
    runeps = find(~cellfun(@isempty,runTrajBounds{1,day}));
    
    for e = 1:length(runeps)
        epoch = runeps(e);
        
        epTrajBounds = runTrajBounds{1,day}{1,epoch}.data;
        
        allStem = epTrajBounds(:,[9:10]); 
        leftStem = epTrajBounds((epTrajBounds(:,3) == 1),[9:10]);
        rightStem = epTrajBounds((epTrajBounds(:,3) == 0),[9:10]);
        correctStem = epTrajBounds((epTrajBounds(:,4) == 1),[9:10]);
        incorrectStem = epTrajBounds((epTrajBounds(:,4) == 0),[9:10]);
        
        stemTimes{1,day}{1,epoch}.allTriggers = allStem;
        stemTimes{1,day}{1,epoch}.leftTriggers = leftStem;
        stemTimes{1,day}{1,epoch}.rightTriggers = rightStem;
        stemTimes{1,day}{1,epoch}.correctTriggers = correctStem;
        stemTimes{1,day}{1,epoch}.incorrectTriggers = incorrectStem;
        
    end
    
    save([dataDir, animalID, 'stemTimes', daystr,'.mat'],'stemTimes');
    clear stemTimes
    
end

        
        
    
    