%%% Takes OdorTriggers.mat files and BinaryPerf.mat files produced from cs_getOdorTriggersandBinaryPerf_mat
%%% 
%%% Separates OdorTrigger times into those followed by correct responses
%%% and those followed by incorrect responses, and saves two new files for
%%% each epoch.

function [CorrIncorrTrigs] = cs_getCorrIncorrTrigs_mat(prefix, days, epochs)
switch prefix
    case 'CS15'
        directoryname = '\Data\OdorPlaceAssociation\CS15_direct\Behavior\';
    case 'CS31'
        directoryname = '\Data\OdorPlaceAssociation\CS31_direct\Nehavior\';
end

cd (directoryname)
for d = 1:length(days)
    day = days(d);
    if (day<10)
        daystring = ['0',num2str(day)];
    else
        daystring = num2str(day);
    end
    
    for e = 1:length(epochs)
        epoch = epochs(e);

        if (epoch<10)
            epochstring = ['0',num2str(epoch)];
        else
            epochstring = num2str(epoch);
        end
        
        if exist(['BinaryPerf',daystring,'-',epochstring,'.mat']) == 2
            
        binaryPerf = load(['BinaryPerf',daystring, '-', epochstring, '.mat']);
        odorTriggers = load(['OdorTriggers',daystring, '-', epochstring, '.mat']);

        trialData = [odorTriggers.OdorTriggers_all, binaryPerf.CorrectIncorrectBinary];

        CorrectTrialTriggers = trialData(find(trialData(:,2)));
        IncorrectTrialTriggers = trialData(find(trialData(:,2) == 0));

        
        save(['CorrTrigs',daystring,'-',epochstring],'CorrectTrialTriggers');
        save(['IncorrTrigs',daystring,'-',epochstring],'IncorrectTrialTriggers');
        end
        
    end
end

