function cs_calcMeanRunTime(filepath, animals)

%lab comp filepath = 'D:\OdorPlaceAssociation\'

%enter all animals as cell array e.g. {'CS31','CS33','CS34'}
cd(filepath)
all = [];
for a = 1:length(animals)
    animal = animals{a};
    
    cd([animal,'Expt\',animal,'_direct\'])
    trajFiles = dir([animal,'runTrajBounds*']);
    trajFiles = {trajFiles.name};
    
    for f = 1:length(trajFiles)
        load(trajFiles{f})
        
        %get Day number from filename
        del = {[animal,'runTrajBounds'],'.mat'};
        daystr = erase(trajFiles{f}, del);
            if daystr(1) == 0
                day = str2num(daystr(2));
            else
                day = str2num(daystr);
            end
        
        runeps = find(~cellfun(@isempty,runTrajBounds{1,day}));
        
        for e = 1:length(runeps)
            epoch = runeps(e);
            
            data = runTrajBounds{1,day}{1,epoch}.data;
            runStartTimes = data(:,6);
            runEndTimes = data(:,7);
            
            
            diff = runEndTimes- runStartTimes;
            
            all = [all ; diff];
        end
        
    end
    cd(filepath)
end

meanRunTime = mean(all)

save([filepath,'AnalysesAcrossAnimals\meanRunTime.mat'],'meanRunTime');
        