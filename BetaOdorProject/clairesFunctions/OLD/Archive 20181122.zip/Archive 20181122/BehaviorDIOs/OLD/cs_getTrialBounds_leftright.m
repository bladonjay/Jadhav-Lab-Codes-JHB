function cs_getTrialBounds_leftright( dataDir, prefix, days, runEpochs)
%loads runTrialBounds and splits into left and right trajectories, then
%saves within runTrialBounds

%enter dataDir with trailing '\' 

for d = 1:length(days)
    day = days(d);
    dayString = getTwoDigitNumber(day);
    load([dataDir, prefix, 'runTrialBounds',dayString,'.mat']);
    
    for e = runEpochs
        bounds = runTrialBounds{1,day}{1,e}.data;
  
        
        runTrialBounds{1,day}{1,e}.leftTrials = bounds((bounds(:, 3) == 1 & bounds(:, 4) == 1) | (bounds(:, 3) == 0 & bounds(:, 4) == 0), :); %left odor and correct, or right odor and incorrect
        runTrialBounds{1,day}{1,e}.rightTrials =bounds((bounds(:, 3) == 0 & bounds(:, 4) == 1) | (bounds(:, 3) == 1 & bounds(:, 4) == 0), :); %right odor and correct, or left odor and incorrect
        
        
        
    end
    
    savestring = [dataDir, prefix, 'runTrialBounds',dayString,'.mat'];
    save(savestring, 'runTrialBounds');

end
