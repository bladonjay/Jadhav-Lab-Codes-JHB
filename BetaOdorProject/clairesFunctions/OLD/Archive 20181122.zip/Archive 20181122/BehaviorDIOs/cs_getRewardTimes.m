
function cs_getRewardTimes(dataDir, animalID, days)

%Gets reward times from runTrajBounds

cd(dataDir)

for d = 1:length(days)
    day = days(d);
    daystr = getTwoDigitNumber(day);
    load([animalID, 'runTrajBounds',daystr,'.mat'])
    
    runeps = find(~cellfun(@isempty,runTrajBounds{1,day}));
    
    for e = 1:length(runeps)
        epoch = runeps(e);
        
        epTrajBounds = runTrajBounds{1,day}{1,epoch}.data;
        
        allReward = epTrajBounds(:,7);
        leftReward = epTrajBounds((epTrajBounds(:,3) == 1),7);
        rightReward = epTrajBounds((epTrajBounds(:,3) == 0),7);
        correctReward = epTrajBounds((epTrajBounds(:,4) == 1),7);
        incorrectReward = epTrajBounds((epTrajBounds(:,4) == 0),7);
        
        
        
        rewardTimes{1,day}{1,epoch}.allTriggers = allReward;
        rewardTimes{1,day}{1,epoch}.leftTriggers = leftReward;
        rewardTimes{1,day}{1,epoch}.rightTriggers = rightReward;
        rewardTimes{1,day}{1,epoch}.correctTriggers = correctReward;
        rewardTimes{1,day}{1,epoch}.incorrectTriggers = incorrectReward;
        
    end
    
    save([dataDir, animalID, 'rewardTimes', daystr,'.mat'],'rewardTimes');
    clear rewardTimes
    
end

        
        
    
    