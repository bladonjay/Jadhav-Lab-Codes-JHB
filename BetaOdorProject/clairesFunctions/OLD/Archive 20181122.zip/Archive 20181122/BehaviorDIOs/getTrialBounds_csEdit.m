function getTrialBounds_csEdit( dataDir, prefix, days, runEpochs, varargin )
%GETTRIALBOUNDS generates a datastructure with start and endtimes of trials and annotates it with trial metadata.
%
%   Odor-Place trial data structure
%   -------------------------------
%
%   Outboud:
%   | starttime | endtime | left/right | correct/incorrect | sniffstart | sniffend | rewardstart | rewardend |
%   |     x     |    y    |    1/0     |       1/0         |     x      |    y2    |      x2     |     y     |
%   timeline progression: x<y2<x2<y
%
%   INPUTS
%   ------
%   1. 'dataDir'    -- chr string containing /path/to/animal_direct/folder
%   2. 'prefix'     -- chr string containing animal ID prefixed before processed files. E.g. 'JS11'
%   3. [days]       -- vector of days over which the function needs to run
%   4. [runEpochs]  -- vector of run epochs
%
%   Optional VARiable ARGument INputs
%   ---------------------------------
%   5.  'RigID'             -- chr flag to indicate presence of follow-up chr variable containing Rig information
%   6.  'leftOdorSolenoid'  -- chr flag to indicate presence of follow-up numerical variable indicating portout
%   7.  'rightOdorSolenoid' -- chr flag to indicate presence of follow-up numerical variable indicating portout
%   8.  'buzzer'            -- chr flag to indicate presence of follow-up numerical variable indicating portout
%   9.  'leftWell'          -- chr flag to indicate presence of follow-up numerical variable indicating portin
%   10. 'rightWell'         -- chr flag to indicate presence of follow-up numerical variable indicating portin
%   11. 'odorPort'          -- chr flag to indicate presence of follow-up numerical variable indicating portin
%
%   EXAMPLE
%   -------
%
%   NOTE
%   ----
%   'dataDir' is to be put in MATLAB format **without** a trailing slash
%   chr flag to indicate presence of follow-up numerical variable indicating portin/portout
%   DIO values by default are set for Rig3 (currently for CS31 buzzer is set at port 9)
%
%   VERSION:    1.0
%   DATE:       July 6th, 2017
%   AUTHOR:     Suman Guha

%% setting variable defaults and updating through varargin

% defaults DIO assignments
leftWell=1;
rightWell=2;
odorPort=5;
buzzer=21;
leftOdorSolenoid=22;
rightOdorSolenoid=23;

% overwriting values with varargins
for varNum=1:2:length(varargin)-1
        switch varargin{varNum}
                case 'RigID'
                        if varargin{varNum+1} == 'Rig1' % NOTE: This will be filled in after the Rig is setup
                                leftWell=0;
                                rightWell=0;
                                odorPort=0;
                                buzzer=0;
                                leftOdorSolenoid=0;
                                rightOdorSolenoid=0;
                        end
                case 'leftWell'
                        leftWell=varargin{varNum+1};
                case 'rightWell'
                        rightWell=varargin{varNum+1};
                case 'leftOdorSolenoid'
                        leftOdorSolenoid=varargin{varNum+1};
                case 'rightOdorSolenoid'
                        rightOdorSolenoid=varargin{varNum+1};
                case 'buzzer'
                        buzzer=varargin{varNum+1};
        end
end

%% function core

trialMetaData=[];
epochMetaData=[];
dayMetaData=[];

cd(dataDir);
DIOs=loaddatastruct([dataDir filesep], prefix, 'dio', days);
% iterating over days
for dayNum=1:length(days)
        day=days(dayNum);
        % iterating over run epochs
        for runEpochNum=1:length(runEpochs)
                
		runEpoch=runEpochs(runEpochNum);
                % generating run DIOs
                if length(DIOs{1,day}) >= runEpoch
                epochDIOs=DIOs{1,day}{1,runEpoch};
		
		% STEP 1: get correct trial start, and odor start times
		% generating matrices for left and right odor solenoid that stores
                % the timestamp for everytime its state changed
                % padding these with zeros will help identifying the
                % sequence of events to generate timestamps for correct trials
		% dataframe structure
                % | starttime | left/rightOdorSolenoidStateChange: 1/0 | buzzerStateOn: 1 |
                leftOdorSolenoidStateChanged=[...
                        epochDIOs{1,leftOdorSolenoid}.time, ...
                        ones(length(epochDIOs{1, leftOdorSolenoid}.time), 1), ...
                        zeros(length(epochDIOs{1, leftOdorSolenoid}.time), 1)...
                        ];
                rightOdorSolenoidStateChanged=[...
                        epochDIOs{1,rightOdorSolenoid}.time, ...
                        zeros(length(epochDIOs{1, rightOdorSolenoid}.time), 2),...
                        ];
                buzzerStateOn=epochDIOs{1,buzzer}.time(epochDIOs{1,buzzer}.state==1, 1); % chosing .time for everytime the buzzer was turned on
                buzzerStateOn=[...
                        buzzerStateOn, ...
                        zeros(length(buzzerStateOn), 1),...
                        ones(length(buzzerStateOn), 1)...
                        ];
		% generating a combined matrix with sorted timestamps
		epochOutbound=sortrows([leftOdorSolenoidStateChanged; rightOdorSolenoidStateChanged; buzzerStateOn], 1);
		% finding the timestamps when the buzzer went off and selecting the row just before/after it which has the time when the solenoids went on/off
		% also, col 2 is 1 for every left and 0 for every right; defacto generating the left/right column of output matrix
		startTime=epochOutbound(find(epochOutbound(:, 3))-1, 1:2);
		% generating epochOutbound matrix with | starttime | left/right | odorstart | 
		epochOutbound=[startTime, startTime(:,1)];
		
		% STEP 2: find well triggers following trial start and determine correct/incorrect and duration at reward well
		% tmp structure: 
		% | starttime | 1/0: left/right | 1 indicating tmp structure | nan | nan | 
		tmp=[startTime, ones(length(startTime), 1), nan(length(startTime), 2)];
		% wellstatechange structure:  
		% | starttime | nan | 0 indicating wellstatechange structure | 1/0 left/right | 1/0 right/left |
		leftWellStateChanged=[...
			epochDIOs{1,leftWell}.time,...
			nan(length(epochDIOs{1, leftWell}.time), 1),...
			zeros(length(epochDIOs{1,leftWell}.time), 1)...
			ones(length(epochDIOs{1,leftWell}.time), 1),...
			zeros(length(epochDIOs{1,leftWell}.time), 1)...
			];
		rightWellStateChanged=[...
			epochDIOs{1,rightWell}.time,...
			nan(length(epochDIOs{1,rightWell}.time), 1),...
			zeros(length(epochDIOs{1,rightWell}.time), 2),...
			ones(length(epochDIOs{1,rightWell}.time), 1)...
			];
		
        %CS- added 12/15/17 to deal with nosepoke error cases
        odorPortStateChanged = [...
			epochDIOs{1,odorPort}.time,...
			nan(length(epochDIOs{1,odorPort}.time), 4),...
			ones(length(epochDIOs{1,odorPort}.time), 1)...
			];
        
		wellStateChanged=sortrows([leftWellStateChanged; rightWellStateChanged],1);
		tmp=sortrows([tmp; wellStateChanged], 1);
		% removing the times when the rats return for a second or third sniff
		for row=1:length(tmp)-1
			if tmp(row, 3)==tmp(row+1,3)
				tmp(row, 3)=0;
			end
		end
		% identify the well that was triggered after trial start, when was it engaged, and when was it disengaged from
                tmp=[tmp; zeros(1, size(tmp, 2))]; % padding with a zero row to find well disengagement time for the last trial which will end with '1' otherwise
		trialStartIndex=find((tmp(:, 3)==1)); % identify and list trial start points
		for i =1:length(trialStartIndex)
            row = trialStartIndex(i);
			% determine which well was triggered
			%if trialStartIndex(row) == 1 % trial started here
            if tmp(row+1, 4) == 1 % left well triggered
					if tmp(row, 2) == 1 % if this was a left trial set correct/incorrect accordingly for later debugging
						corrIncorr=1;
					else
						corrIncorr=0;
                    end
                                        wellArr=tmp(row+1,1);
                                        
                                        tmp2 = [tmp,nan(length(tmp),1);odorPortStateChanged]; %CS- added 12/15/17 to deal with nosepoke error cases
                                        tmp2=sortrows(tmp2, 1);
                                        
                                        endIndex = find(tmp2(:,1) == wellArr); 
                                        %endIndex=row+2;
                                        while endIndex <= length(tmp2) && tmp2(endIndex,4)==1
                                                endIndex=endIndex+1;
                                        end
                                        wellDep=tmp2(endIndex-1,1);
            elseif tmp(row+1, 5) == 1 % right well triggered
					if tmp(row, 2) == 0 % if this was a right trial set correct/incorrect accordingly for later debugging
						corrIncorr=1;
					else
						corrIncorr=0;
                    end
                                        wellArr=tmp(row+1,1);
                                        
                                        
                                        tmp2 = [tmp,nan(length(tmp),1);odorPortStateChanged]; %CS- added 12/15/17 to deal with nosepoke error cases
                                        tmp2=sortrows(tmp2, 1);
                                        
                                        endIndex = find(tmp2(:,1) == wellArr); 
                                        
                                        %endIndex=row+2;
                                        
                                            while endIndex <= length(tmp2) && tmp2(endIndex,5)==1 
                                                    endIndex=endIndex+1;
                                            end
                                            wellDep=tmp2(endIndex-1,1);
                                        
                                        
                                            
                                       
            end
                                trialMetaData=[tmp(row,1),corrIncorr,wellArr,wellDep];
                                epochMetaData=[epochMetaData; trialMetaData];
                                trialMetaData=[];
                                % epochMetaData = | starttime | Corr/Incorr | Well Arrival | Well Departure | 
                        %end
        end
                
                % STEP 3: Combine epochOutbound with epochMetaData
                % For situations where the rat returns for a second sniff and might trigger the buzzer again ...
                % Subset epochOutbound to identify the last sniff/buzzer after which the animal ran to the reward well identified
                % epochOutbound = | starttime | left/right | odorstart |
                % epochMetaData = | starttime | Corr/Incorr | Well Arrival | Well Departure |
                % epochTrialBounds = | starttime | endtime | left/right | Corr/Incorr | sniffstart | ~~~sniffend~~~ | rewardstart | rewardend | 
                epochOutboundIndex=ismember(epochOutbound(:,1) ,epochMetaData(:,1) );
                epochOutbound=epochOutbound(epochOutboundIndex, :);
                epochTrialBounds=[ epochMetaData(:, [1 4]), epochOutbound(:, 2), epochMetaData(:, [2 1 3 4]) ];
                
                % STEP 4: Find the time when the animal disengaged from the nose-poke well
                % 1. find the all the relevant indices when the well was engaged
                % 2. add 1 to the indices as that will give the dissociation indices.
                % 3. use that to extract the time and save it as 'sniffend'
                odorPortDIO=[ epochDIOs{1,odorPort}.time, double(epochDIOs{1,odorPort}.state) ];
                odorPortDioIndex=lookup(epochTrialBounds(:,1), odorPortDIO(:,1))+1;
                odorPortDIO=odorPortDIO(odorPortDioIndex,:);
                epochTrialBounds=[ epochTrialBounds(:, [1 2 3 4 5]), odorPortDIO(:,1), epochTrialBounds(:, [6 7]) ];
                runTrialBounds{1,day}{1,runEpoch}.data=epochTrialBounds;
                runTrialBounds{1,day}{1,runEpoch}.fields='starttime endtime left/right(1/0) Corr/Incorr(1/0) sniffstart sniffend rewardstart rewardend';
                epochMetaData=[];
                clear epochTrialBounds;
                end
        end
        %% saving data as .mat file
        save(sprintf('%s%srunTrialBounds%02d.mat', [dataDir '/'], prefix, day), 'runTrialBounds');
        clear runTrialBounds;
end
end

