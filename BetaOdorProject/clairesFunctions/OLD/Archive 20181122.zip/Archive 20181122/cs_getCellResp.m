function cs_getCellResp(dataDir, regions, win)
% win should be in ms
% calculates percent change from baseline FR after stim for all cells that
% spike with minimum FR during window
% step 1: get mean FR before stim
% for each bin after stim, calc percent change from baseline
% put into matrix where each row represents a cell, each column is a bin
% plot color histogram, red = positive change from BL, blue = negative
% change from BL

cd(dataDir)


for r = 1:length(regions)
    region = regions{r};
    
    filename = ['cellSelectivityData_',region,'_-',num2str(win(1)),'-',num2str(win(2)),'ms.mat'];
    
    load(filename)
    bins = cellSelectivity(1).bins;
    binsize = bins(2) - bins(1);
    preTrigBins = find(bins < 0);
    postTrigBins = find(bins >=0);
    postTrigBins = postTrigBins(1:end-1);
    
    for c = 1:length(cellSelectivity)
        allFR = [cellSelectivity(c).psthleftTriggers; cellSelectivity(c).psthleftTriggers]/binsize;
        allFR = allFR(:,1:end-1);
        binnedMeanFR = mean(allFR,1);
        cellMeanFR = mean(binnedMeanFR);
        stdFR = std(binnedMeanFR);
        
        
        zscore = (binnedMeanFR - cellMeanFR)./stdFR;
        zscore = smoothdata(zscore, 'gaussian', 10);
        
        allZscore(c,:) = zscore;
        
        
    end
    
    [mx, mxind] = max(abs(allZscore(:,postTrigBins)),[],2);
    mxind = postTrigBins(mxind)';
    
%     [mn] = min(allZscore,[],2);
%     
%     compare = abs([mx,mn]);
    
    for c = 1:length(mxind)
        order(c,1) = allZscore(c,mxind(c));
        order(c,2) = c;
        
%         if compare(c,1) >= compare(c,2)
%             order(c,1) = mx(c);
%         else
%             order(c,1) = mn(c);
%         end
%         
%         order(c,2) = c;     
    end
    
    order = sortrows(order,1);
    orderedCells = allZscore(order(:,2),:);
    
    figure,
    imagesc(bins, [1:length(orderedCells)], orderedCells)
    colormap(jet);
    set(gca,'YDir','normal')
    colorbar;
    hold on
    plot([0 0],[1 length(orderedCells)], 'k--', 'LineWidth',2)
    
    figtitle = ['OdorResponse_',region];
    title(sprintf('%s%d',figtitle), 'Interpreter', 'none'); %allows underscores in fig titles
    
    %figdir = 'E:\Figures\OdorSelectivity\'; %home comp
    figdir = 'D:\Figures\OdorSelectivity\'; %lab comp
    figfile = [figdir,figtitle];
    
    print('-djpeg', figfile);
    print('-dpng', figfile);
    saveas(gcf,figfile,'fig');
    
   clear order
   clear allZscore
   
end

        