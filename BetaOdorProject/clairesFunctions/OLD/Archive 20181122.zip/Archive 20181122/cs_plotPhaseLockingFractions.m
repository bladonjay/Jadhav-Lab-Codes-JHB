function allFractions = cs_plotPhaseLockingFractions(betaPhaseLockingAll)
datadir = 'E:\AnalysesAcrossAnimals\';
figdir = 'E:\Figures\';
load(betaPhaseLockingAll)

betaregions = {'CA1','PFC','OB'};
cellregions = {'CA1','PFC'};


figure(100), hold on

 numregions = 0;
for c = 1:length(cellregions)
    cellregion = cellregions{c};
    
    load(['cellSelectivityData_',cellregion,'.mat'])
    
    allcells = [];
    for b = 1:length(betaregions)
        betaregion = betaregions{b};
        numregions = numregions +1;


        regionstring = [cellregion,'to',betaregion];
        regiondata = betaPhaseLockingAll.(regionstring).allTriggers;
        fraction = regiondata.fractionSpikingCellsPL;
        
        allFractions.separateRegions(numregions).data = fraction;
        allFractions.separateRegions(numregions).region  = regionstring;
        

        regioncells = vertcat(regiondata.plAll.index);
        regionanimals = {regiondata.plAll.animal};
        uniquean = unique(regionanimals);

        for a = 1:length(regionanimals);
            an = regionanimals{a};
            anindx = find(ismember(uniquean,an));
            allanindx(a,1) = anindx;
        end

        fullindx = [allanindx, regioncells];

        allcells = [allcells; fullindx];    
        clear allanindx;
     
    end
    
    uniquecells = unique(allcells,'rows');
    percentAllCells = length(uniquecells)/length(cellSelectivity);
    
    allFractions.allBetaRegions(c).cells = uniquecells;
    allFractions.allBetaRegions(c).percent = percentAllCells;
    allFractions.allBetaRegions(c).region = cellregion;
    
    
end

figure(100), hold on
%datatoplot = [allFractions.allBetaRegions(1).percent, allFractions.separateRegions(1:3).data; allFractions.allBetaRegions(2).percent,allFractions.separateRegions(4:6).data];
datatoplot = [allFractions.separateRegions(1).data; allFractions.separateRegions(4).data];
h(1) = bar([1],datatoplot(1));
h(2) = bar([2], datatoplot(2));
xticks([1 2])
xticklabels({'Hippocampal cells','PFC cells'})
axis([0.5 2.5 0 .3])
yticks([0:.1:.5])
ylabel('Fraction of Cells');

%legend('All Phase Locked Cells','Phase Locked to CA1 beta', 'Phase Locked to PFC beta', 'Phase Locked to OB beta')
legend('Hippocampal Cells', 'Prefrontal Cellls')
legend('boxoff')

set(h(1),'FaceColor',[0.8594 0.0781 0.2344]);
set(h(2),'FaceColor',[0.1172 0.5625 1]);


% set(h(1),'FaceColor',[1.0000 0.8398 0]);
% set(h(2),'FaceColor',[0.8594 0.0781 0.2344]);
% set(h(3),'FaceColor',[0.1172 0.5625 1]);
% set(h(4),'FaceColor',[0.1328 0.5430 0.1328]);

set(gca,'fontsize',20);

set(gcf, 'Position', [2000 350 900 600]);

figtitle = 'phaseLockedFractions';
figfile = [figdir,'NicePPTFigures\',figtitle];
saveas(gcf,figfile,'fig');
print('-dpng', figfile);


phaseLockingFractions = allFractions;
save([datadir,'phaseLockingFractions.mat'],'phaseLockingFractions');
% 
% figure(200), hold on
% datatoplot = [allFractions.allBetaRegions.percent];
% g = bar(1,datatoplot(1),'FaceColor',[0.8594 0.0781 0.2344]);
% f = bar(2,datatoplot(2),'FaceColor',[0.1172 0.5625 1]);
% xticks([1 2])
% yticks([0:.1:.5])
% xticklabels({'CA1 cells','PFC cells'})
% axis([0.5 2.5 0 .50])

