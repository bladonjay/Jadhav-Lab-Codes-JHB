animals = {'CS31', 'CS33','CS34','CS35'};
topDir = 'D:\OdorPlaceAssociation\';
regions = {'CA1','PFC'};


for r = 1:length(regions)
    region = regions{r};
    
    all_selectivecells = []; all_plcells = [];
    for a = 1:length(animals)
        animal = animals{a};

        load([topDir, animal,'Expt\',animal,'_direct\',animal,'cellinfo.mat']);

        cellfilter1 = ['((strcmp($area, ''',region,''')) && ((strcmp($selectivity, ''leftSelective'')) || (strcmp($selectivity, ''rightSelective''))))'];
        selectivecells = evaluatefilter(cellinfo,cellfilter1);
        noepochs = selectivecells(:,[1,3,4]);
        animvector = repmat(a,size(noepochs,1),1);
        selectivecells = unique((noepochs),'rows');
        all_selectivecells = [all_selectivecells; selectivecells];
        
        %cellfilter2 = ['((strcmp($area, ''',region,''')) && (($betaPhaseLocked_CA1 == 1) || ($betaPhaseLocked_PFC == 1) || ($betaPhaseLocked_OB == 1)))'];
        cellfilter2 = ['((strcmp($area, ''',region,''')) && ((~isempty($betaPhaseLocked_CA1)) || (~isempty($betaPhaseLocked_PFC)) || (~isempty($betaPhaseLocked_OB))))'];        
        plcells = evaluatefilter(cellinfo,cellfilter2);
        noepochs = plcells(:,[1,3,4]);
        animvector = repmat(a,length(noepochs),1);
        plcells = unique((noepochs),'rows');
        all_plcells = [all_plcells; plcells];
    
        
        
    end
    
    both = intersect(all_selectivecells,all_plcells,'rows');
    selectiveonly = setdiff(all_selectivecells,all_plcells,'rows');
    plonly = setdiff(all_plcells,all_selectivecells,'rows');
    
    A = [length(all_selectivecells),length(all_plcells)];
    I = length(both);
    
    venn(A,I);
    
    title(region)
end