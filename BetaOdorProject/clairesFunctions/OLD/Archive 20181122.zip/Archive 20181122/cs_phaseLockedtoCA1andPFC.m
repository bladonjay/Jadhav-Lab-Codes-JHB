function cs_phaseLockedtoCA1andPFC(dataDir)

animals = {'CS31','CS33','CS34'};

load([dataDir,'betaModv2_CA1.mat']);
p = [betaMod_CA1cells.prayl];
CA1_betaMod_CA1cells = betaMod_CA1cells(p < 0.05);

p = [betaMod_PFCcells.prayl];
CA1_betaMod_PFCcells = betaMod_PFCcells(p < 0.05);

load([dataDir,'betaModv2_PFC.mat']);
p = [betaMod_CA1cells.prayl];
PFC_betaMod_CA1cells = betaMod_CA1cells(p < 0.05);

p = [betaMod_PFCcells.prayl];
PFC_betaMod_PFCcells = betaMod_PFCcells(p < 0.05);


%----- CA1 -----%
CA1CA1animals = {CA1_betaMod_CA1cells.animal};
CA1CA1cellinds = vertcat(CA1_betaMod_CA1cells.index);
animalinds = [];
for a = 1:length(animals) %create index that includes animal
    an = animals{a};
    animalinds(find(strcmp(CA1CA1animals,an))) = a;
end
CA1CA1cellinds = [animalinds', CA1CA1cellinds];

PFCCA1animals = {PFC_betaMod_CA1cells.animal};
PFCCA1cellinds = vertcat(PFC_betaMod_CA1cells.index);
animalinds = [];
for a = 1:length(animals) %create index that includes animal
    an = animals{a};
    animalinds(find(strcmp(PFCCA1animals,an))) = a;
end
PFCCA1cellinds = [animalinds', PFCCA1cellinds];


CA1phaseLockedtoBoth = intersect(CA1CA1cellinds, PFCCA1cellinds, 'rows');
CA1allCells = unique(vertcat(CA1CA1cellinds,PFCCA1cellinds),'rows');
CA1fraction = size(CA1phaseLockedtoBoth,1)/size(CA1allCells,1);



%----- PFC ------%
CA1PFCanimals = {CA1_betaMod_PFCcells.animal};
CA1PFCcellinds = vertcat(CA1_betaMod_PFCcells.index);
animalinds = [];
for a = 1:length(animals) %create index that includes animal
    an = animals{a};
    animalinds(find(strcmp(CA1PFCanimals,an))) = a;
end
CA1PFCcellinds = [animalinds', CA1PFCcellinds];

PFCPFCanimals = {PFC_betaMod_PFCcells.animal};
PFCPFCcellinds = vertcat(PFC_betaMod_PFCcells.index);
animalinds = [];
for a = 1:length(animals) %create index that includes animal
    an = animals{a};
    animalinds(find(strcmp(PFCPFCanimals,an))) = a;
end
PFCPFCcellinds = [animalinds', PFCPFCcellinds];


PFCphaseLockedtoBoth = intersect(CA1PFCcellinds, PFCPFCcellinds, 'rows');
PFCallCells = unique(vertcat(CA1PFCcellinds,PFCPFCcellinds),'rows');
PFCfraction = length(PFCphaseLockedtoBoth)/length(PFCallCells);

CA1andPFCcellsFractions = [CA1fraction, PFCfraction];

save([dataDir,'phaseLockedtoCA1andPFC'],'CA1phaseLockedtoBoth','PFCphaseLockedtoBoth','CA1andPFCcellsFractions');
